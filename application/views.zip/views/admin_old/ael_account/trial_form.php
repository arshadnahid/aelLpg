<div class="main-content">
<div class="main-content-inner">
<div class="page-content">



<div class="row">
<div class="col-xs-12">



<div class="page-header center">
							<h1>
						
								<b>Trial Balance</b>
							</h1>


</div>

<div class="center">
<h3>
Date Search
</h3>
<hr>
</div>

<form method="post" action="<?php echo base_url()?>Ael_account/trial_balance">
		<div class="row" style="margin-left: 10%;">


<div class="col-md-3 col-xs-3">

</div>

		<div class="col-md-3 col-xs-3">
		<!-- <h4>Start </h4> -->
		<div class="input-group">

		<input class="form-control date-picker" name="start" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd"dd />
	<span class="input-group-addon">
		<i class="fa fa-calendar bigger-110"></i>
	</span>

		</div>
		</div>


<!-- <div class="col-md-1 col-xs-1">
<h4>TO </h4>

			</div> -->



<!-- 		<div class="col-md-3 col-xs-3">
		
		<div class="input-group">

		<input class="form-control date-picker" name="end" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd"dd />
	<span class="input-group-addon">
		<i class="fa fa-calendar bigger-110"></i>
	</span>

		</div>
		</div>
 -->

    


         <!-- <div class="clearfix form-actions"> -->
				<div class="col-md-2 ">
				<!-- <h4></h4> -->
					<button class="btn btn-info" >
						<i class="ace-icon fa fa-check bigger-110"></i>
						Search
					</button>

				
				</div>
			<!-- </div> -->



<div class="col-md-2 col-xs-2">

</div>




		</div>









</form>



</div>
</div>
</div>
</div>
</div>
