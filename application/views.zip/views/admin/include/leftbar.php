<ul class="nav nav-list">


    <li class="active open  hover">
        <a href="<?php echo site_url('adminDashboard'); ?>">
            <i class="menu-icon fa fa-tachometer"></i>
            <span class="menu-text"> Dashboard </span>
        </a>
        <b class="arrow"></b>
    </li>
    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-desktop"></i>
            <span class="menu-text">
                Distributor
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">


            <li class="hover">
                <a href="<?php echo base_url() ?>distributor_add">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Add New 
                </a>

                <b class="arrow"></b>
            </li>

            <li class="hover">
                <a href="<?php echo base_url() ?>distributor">
                    <i class="menu-icon fa fa-caret-right"></i>
                    View All
                </a>

                <b class="arrow"></b>
            </li>


        </ul>
    </li>

    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-map-marker"></i>
            <span class="menu-text">
                Zone
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">


            <li class="hover">
                <a href="<?php echo base_url() ?>zone_add">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Add New 
                </a>

                <b class="arrow"></b>
            </li>

            <li class="hover">
                <a href="<?php echo base_url() ?>zone">
                    <i class="menu-icon fa fa-caret-right"></i>
                    View All
                </a>

                <b class="arrow"></b>
            </li>


        </ul>
    </li>
    <!--    <li class="hover">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-map-marker"></i>
                <span class="menu-text">
                    District
                </span>
    
                <b class="arrow fa fa-angle-down"></b>
            </a>
    
            <b class="arrow"></b>
    
            <ul class="submenu">
    
    
                <li class="hover">
                    <a href="<?php echo base_url() ?>district_add">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Add New 
                    </a>
    
                    <b class="arrow"></b>
                </li>
    
                <li class="hover">
                    <a href="<?php echo base_url() ?>district_list">
                        <i class="menu-icon fa fa-caret-right"></i>
                        View All
                    </a>
    
                    <b class="arrow"></b>
                </li>
    
    
            </ul>
        </li>-->












    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-gift"></i>
            <span class="menu-text">
                Offer
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">





            <li class="hover">
                <a href="<?php echo base_url() ?>offer_add">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Offer Add
                </a>

                <b class="arrow"></b>
            </li>






            <li class="hover">
                <a href="<?php echo base_url() ?>offer">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Offer All
                </a>

                <b class="arrow"></b>
            </li>







        </ul>
    </li>
    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa-envelope"></i>
            <span class="menu-text">
                Message
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">





            <li class="hover">
                <a href="<?php echo base_url() ?>inbox_add">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Message Add
                </a>

                <b class="arrow"></b>
            </li>






            <li class="hover">
                <a href="<?php echo base_url() ?>inbox">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Message All
                </a>

                <b class="arrow"></b>
            </li>
        </ul>
    </li>


    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa  fa-amazon"></i>
            <span class="menu-text">
                Supplier
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">
            <li class="hover">
                <a href="<?php echo base_url() ?>adminSupAdd">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Supplier Add
                </a>
                <b class="arrow"></b>
            </li>
            <li class="hover">
                <a href="<?php echo base_url() ?>adminSupList">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Supplier All
                </a>
                <b class="arrow"></b>
            </li>
        </ul>
    </li>



    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-shopping-bag"></i>
            <span class="menu-text">
                Product
            </span>
            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">







            <li class="hover">
                <a href="<?php echo base_url() ?>adminProductCatAdd">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Product Category
                </a>

                <b class="arrow"></b>
            </li>
            <li class="hover">
                <a href="<?php echo base_url() ?>adminProuductCatList">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Category List
                </a>

                <b class="arrow"></b>
            </li>

            <li class="hover">
                <a href="<?php echo base_url() ?>adminProductAdd">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Product Add
                </a>

                <b class="arrow"></b>
            </li>
            <li class="hover">
                <a href="<?php echo base_url() ?>adminProuductList">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Product List
                </a>

                <b class="arrow"></b>
            </li>

            <li class="hover">
                <a href="<?php echo base_url() ?>adminUnitAdd">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Unit Add
                </a>

                <b class="arrow"></b>
            </li>
            <li class="hover">
                <a href="<?php echo base_url() ?>adminUnitList">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Unit List
                </a>

                <b class="arrow"></b>
            </li>


            <li class="hover">
                <a href="<?php echo base_url() ?>adminProductImport">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Product Import
                </a>

                <b class="arrow"></b>
            </li>


        </ul>
    </li>













    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-cubes"></i>
            <span class="menu-text">
                Distributors Short Report
            </span>
            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">


            <!-- <li class="hover">
            <a href="<?php echo base_url() ?>distributor_form">
            <i class="menu-icon fa fa-caret-right"></i>
            Distributor
            </a>
            
            <b class="arrow"></b>
            </li> -->

            <li class="hover">
                <a href="<?php echo base_url() ?>disPurchasesReport">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Purchase Report
                </a>

                <b class="arrow"></b>
            </li>
            <li class="hover">
                <a href="<?php echo base_url() ?>disStockReport">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Stock Report
                </a>

                <b class="arrow"></b>

            </li>

            <li class="hover">
                <a href="<?php echo base_url() ?>disSalesReport">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Sales Report
                </a>

                <b class="arrow"></b>
            </li>
        </ul>
    </li>
    <li class="hover">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-cubes"></i>
            <span class="menu-text">
                Distributors Full Report
            </span>
            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">


            <!-- <li class="hover">
            <a href="<?php echo base_url() ?>distributor_form">
            <i class="menu-icon fa fa-caret-right"></i>
            Distributor
            </a>
            
            <b class="arrow"></b>
            </li> -->

            <li class="hover">
                <a href="<?php echo base_url() ?>getDistributorAccess">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Get Access
                </a>

                <b class="arrow"></b>
            </li>   
        </ul>
    </li>
</ul>



</ul><!-- /.nav-list -->
</div>