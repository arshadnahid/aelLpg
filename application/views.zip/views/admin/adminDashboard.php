
<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="col-md-3">
                        <a href="<?php echo base_url() ?>distributor" class="radius-4">
                            <img src="<?php echo base_url() ?>assets/inc/dist.png" class="img-responsive">
                        </a>
                        <h4 class="httext">Distributor <span style="color:red;font-size: 29px;font-style: italic"><?php echo $totalDistri;?></span></h4>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo base_url() ?>inbox" class="radius-4">
                            <img src="<?php echo base_url() ?>assets/inc/message.png" class="img-responsive">
                        </a>
                        <h4 class="httext">Message  <span style="color:red;font-size: 29px;font-style: italic"><?php echo $totalMessage;?></span></h4>

                    </div>
                    <!-- 	<div class="col-md-3">
                                    <a href="#" class="radius-4">
                                                    <img src="<?php echo base_url() ?>assets/inc/sales.jpg" class="img-responsive">
                                            </a>
                                            <h4 class="httext">Sales Statement</h4>
                    </div> -->

<!--                    <div class="col-md-3">
                        <a href="<?php echo base_url() ?>incentive" class="radius-4">
                            <img src="<?php echo base_url() ?>assets/inc/Incentives.png" class="img-responsive">
                        </a>
                        <h4 class="httext">Incentive</h4>

                    </div>		-->
                    <!-- <hr/> -->
                    <!-- <div class="col-md-3">
                                    <a href="#" class="radius-4">
                                            <img src="<?php echo base_url() ?>assets/inc/add.png" class="img-responsive">
                                    </a>
                                    <h4 class="httext">Add</h4>
</div> -->

                    <div class="col-md-3">
                        <a href="<?php echo base_url() ?>offer" class="radius-4">
                            <img src="<?php echo base_url() ?>assets/inc/offer.png" class="img-responsive">
                        </a>
                        <h4 class="httext">Offers  <span style="color:red;font-size: 29px;font-style: italic"><?php echo $totalOffer;?></span></h4>


                    </div>		

                    <div class="col-md-3">
                        <a href="<?php echo base_url() ?>profile" class="radius-4">
                            <img src="<?php echo base_url() ?>assets/inc/pp.png" class="img-responsive">
                        </a>

                        <h4 class="httext">Profile</h4>


                    </div>
                    <!-- 	<div class="col-md-3">
                                            <a href="#" class="radius-4">
                                                    <img src="<?php echo base_url() ?>assets/inc/chart.png" class="img-responsive">
                                                    
                                            </a>

                                            <h4 class="httext">Chart</h4>
                                    

                              </div> -->













                    <!-- PAGE CONTENT ENDS -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->
