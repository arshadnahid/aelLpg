<div>
	<center>
		<img src="<?php echo base_url().'assets/inc/hrm.png'?>" style="width: 100%; height: 380px">
	</center>
</div>