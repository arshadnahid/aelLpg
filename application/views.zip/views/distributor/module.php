<style type="text/css">


    .moduleList {
        height: 270px;
        margin-top: 10px;
        background-color: #438EB9;
        font-family: 'Raleway Dots', sans-serif;
    }
    section #services {
        text-align: center;
        transform: translatez(0);
    }
    section #services h2 {
        margin: 20px 0px 10px;
        color: #fff;
        font-size: 2.4em;
        text-transform: uppercase;
        text-align: center;
    }
    section #services li {
        width: 120px;
        height: 140px;
        display: inline-block;
        margin: 20px;
        list-style: none;
    }
    section #services li div {
        width: 120px;
        height: 120px;
        color: #74d4b3;
        font-size: 3.4em;
        text-align: center;
        line-height: 150px;
        background-color: #fff;
        transition: all 0.5s ease;
    }
    section #services li a {
        color: #77cc6d;
    }
    section #services li div:hover {
        transform: rotate(360deg);
        border-radius: 100px;
    }
    section #services li span {
        width: 120px;
        height: 30px;
        display: block;
        padding: 15px 0px;
        color: #fff;
        text-transform: uppercase;
        font-size: 1.2em;
        text-align: center;
    }
    .credits a {
        display: block;
        text-align: center;
        color: #74d4b3;
        text-decoration: none;
        font-size: 24px;
        margin-top: 50px;
        background: white;
        padding: 20px;
        max-width: 300px;
    }
</style>

<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="page-header">

                <div class="row">
                    <style>
                        .cusTable tbody tr td{
                            margin: 0px;
                            padding: 2px;
                        }
                        .cusTable{
                            background-color: white;
                        }
                    </style>

                </div>


                <div class="row moduleList">



                    <section>
                        <ul id="services">
                            <h2>Welcome To Admin</h2>
                            <li>
                                <div class="facebook">
                                    <a href="http://sflcl.com/baseithr/login">
                                        <i class="menu-icon fa fa-users bigger-200 " aria-hidden="true"></i>
                                    </a>
                                </div>
                                <span>HR</span>
                            </li>
                            <li>
                                <div class="twitter">
                                    <a href="<?php echo site_url('DistributorDashboard/1'); ?>">
                                        <i class="fa fa-bar-chart-o bigger-180" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <span>Accounts</span>
                            </li>
                            <li>
                                <div class="youtube">
                                    <a href="<?php echo site_url('DistributorDashboard/2'); ?>">
                                        <i class=" fa fa-truck bigger-200" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <span>Sales</span>
                            </li>
                            <li>
                                <div class="linkedin">
                                    <a href="<?php echo site_url('DistributorDashboard/3'); ?>">
                                        <i class="menu-icon fa fa-sitemap bigger-200" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <span>Inventory</span>
                            </li>
                            <li>
                                <div class="instagram">
                                    <a href="<?php echo site_url('DistributorDashboard/4'); ?>">
                                        <i class=" fa fa-cog bigger-200" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <span>Settings</span>
                            </li>
                        </ul> 
                    </section>
                </div>
                <hr>
                <div class="row" style="margin-top:-15px!important;padding-bottom: -15px!important">
                    <div class="col-md-6 col-md-offset-3">
                        <table class="table table-bordered cusTable">
                            <thead>
                                <tr>
                                    <th>Account Head</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><a href="<?php echo site_url('generalLedger/58'); ?>">Account Receivable</a></td>
                                    <td align="right"><?php echo number_format(abs($accountReceiable)); ?></td>
                                </tr>
                                <tr>
                                    <td><a  href="<?php echo site_url('generalLedger/50'); ?>">Account Payable</a></td>
                                    <td align="right"><?php echo number_format(abs($accountPayable)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('generalLedger/54'); ?>">Cash In Hand</a></td>
                                    <td align="right"><?php echo number_format(abs($cashInHand)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('bankBook'); ?>">Cash at Bank</a></td>
                                    <td align="right"><?php echo number_format(abs($totalCashAtBank)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('salesReport'); ?>">Total Sales</a></td>
                                    <td align="right"><?php echo number_format(abs($totalSalesAmount)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('stockReport'); ?>">Inventory</a></td>
                                    <td align="right"><?php echo number_format(abs($inventoryAmount)); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>



