<div id="navbar" class="navbar navbar-default    navbar-collapse       h-navbar ace-save-state">
    <div class="navbar-container ace-save-state" id="navbar-container">
        <div class="navbar-header pull-left">
            <a href="<?php echo site_url('DistributorDashboard'); ?>" class="navbar-brand">
                <small>
                    <i class="fa fa-leaf"></i>
                    <?php
                    $dist_id = $this->session->userdata('dis_id');
                    echo $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $dist_id)->companyName;



                    $this->db->select("*");
                    $this->db->from("messageuser");
                    $this->db->join("message", "message.msgId=messageuser.msgid");
                    $this->db->where('messageuser.userid', $dist_id);
                    $this->db->limit(5);
                    $this->db->order_by('message.msgId', 'DESC');
                    $allResult = $this->db->get()->result_array();
                    $allOffer = $this->Common_model->get_data_list('offer', 'offerId', 'DESC');
                    ?>
                </small>
            </a>

            <button class="pull-right navbar-toggle navbar-toggle-img collapsed" type="button" data-toggle="collapse" data-target=".navbar-buttons,.navbar-menu">
                <span class="sr-only">Toggle user menu</span>

                <img src="assets/images/avatars/user.jpg" alt="Jason's Photo" />
            </button>

            <button class="pull-right navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#sidebar">
                <span class="sr-only">Toggle sidebar</span>

                <span class="icon-bar"></span>

                <span class="icon-bar"></span>

                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="navbar-buttons navbar-header pull-right  collapse navbar-collapse" role="navigation">
            <ul class="nav ace-nav">

                
                
                <li>
                            <a  class="pull-left" href="<?php echo site_url('DistributorDashboard'); ?>" style=" text-transform: uppercase;"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp;&nbsp; &nbsp;<span id="clock"><?php echo date("Y-m-d h:i:sa") ?></span></a>
                        </li>
                        
                        
                        <li>
		<div class="col-sm-2" style="line-height: 1.42857143; padding-top: 10px;">
			<div class="col-sm-12" id="google_translate_element"></div>
		</div>
		 <!--<div id="google_translate_element"></div>--> 
	</li>
                
                
                <li class="grey  dropdown-modal">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="ace-icon fa fa-street-view icon-animated-vertical"></i>
                        <span class="badge badge-success"><?php echo count($allOffer); ?></span>
                    </a>

                    <ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
                        <li class="dropdown-header">
                            <i class="ace-icon fa fa-street-view"></i>
                            User Manual
                        </li>

                        <li class="dropdown-content">
                            <ul class="dropdown-menu dropdown-navbar">




                                <li>
                                    <a href="<?php echo base_url() ?>assets/userMenual/distributorUserMenual.pdf" class="clearfix" download>
                                       
                                       <i class="fa fa-cloud-download"></i> &nbsp; Download  User Manual
                                    </a>
                                </li>

                                
                            </ul>
                        </li>

                       
                    </ul>
                </li>
                <li class="purple dropdown-modal">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="ace-icon fa fa-gift icon-animated-vertical"></i>
                        <span class="badge badge-success"><?php echo count($allOffer); ?></span>
                    </a>

                    <ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
                        <li class="dropdown-header">
                            <i class="ace-icon fa fa-gift"></i>
                            <?php echo count($allOffer); ?> Offer
                        </li>

                        <li class="dropdown-content">
                            <ul class="dropdown-menu dropdown-navbar">

                                <?php foreach ($allOffer as $eachInfo): ?>


                                    <li>
                                        <a href="#" class="clearfix">
                                            <img src="<?php echo base_url(); ?>assets/images/avatars/avatar.png" class="msg-photo" alt="Alex's Avatar" />
                                            <span class="msg-body">
                                                <span class="msg-title">
                                                    <span class="blue"><?php echo $eachInfo->offerTitle; ?></span>
                                                    <?php echo substr($eachInfo->offerDescription, 200); ?> ...
                                                </span>

                                                <span class="msg-time">
                                                    <i class="ace-icon fa fa-clock-o"></i>
                                                    <span><?php echo $eachInfo->created_at; ?></span>
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                <?php endforeach; ?>

                            </ul>
                        </li>

                        <li class="dropdown-footer">
                            <a href="#">
                                <a href="<?php echo site_url('userAllOfferList'); ?>">
                                    See all Offer
                                    <i class="ace-icon fa fa-arrow-right"></i>
                                </a>
                        </li>
                    </ul>
                </li>




                <li class="green dropdown-modal">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="ace-icon fa fa-envelope icon-animated-vertical"></i>
                        <span class="badge badge-success"><?php echo count($allResult); ?></span>
                    </a>

                    <ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
                        <li class="dropdown-header">
                            <i class="ace-icon fa fa-envelope-o"></i>
                            <?php echo count($allResult); ?> Messages
                        </li>

                        <li class="dropdown-content">
                            <ul class="dropdown-menu dropdown-navbar">

                                <?php foreach ($allResult as $eachInfo): ?>


                                    <li>
                                        <a href="#" class="clearfix">
                                            <img src="<?php echo base_url(); ?>assets/images/avatars/avatar.png" class="msg-photo" alt="Alex's Avatar" />
                                            <span class="msg-body">
                                                <span class="msg-title">
                                                    <span class="blue"><?php echo $eachInfo['msgSubject']; ?></span>
                                                    <?php echo substr($eachInfo['msgDescrip'], 200); ?> ...
                                                </span>

                                                <span class="msg-time">
                                                    <i class="ace-icon fa fa-clock-o"></i>
                                                    <span><?php echo $eachInfo['created_at']; ?></span>
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                        <li class="dropdown-footer">
                            <!--<a href="#">-->
                            <a href="<?php echo site_url('userMessageList'); ?>">
                                See all messages
                                <i class="ace-icon fa fa-arrow-right"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="purple dropdown-modal user-min">
                    <a href="<?php echo site_url('decision'); ?>">
                        Dicision Tools
                        <i class="fa fa-question"></i>
                    </a></li>
                <?php
                $dist_id = $this->session->userdata('dis_id');
                $admin_id = $this->session->userdata('admin_id');
                $headOffice = strtolower($this->session->userdata('headOffice'));
                $adminInfo = $this->db->get_where('admin', array('distributor_id' => $dist_id, 'admin_id' => $admin_id))->row();
                ?>

                <li class="light-blue dropdown-modal user-min">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        <?php if (!empty($adminInfo->image)): ?>
                            <img class="nav-user-photo" src="<?php echo base_url('uploads/thumb/' . $adminInfo->image); ?>" alt="admin Phone" />
                        <?php else: ?>
                            <img class="nav-user-photo" src="<?php echo base_url('assets/images/default.png'); ?>" alt="Detault Admin Photo" />
                        <?php endif; ?>
                        <span class="user-info">
                            <small>Welcome,</small>
                            <?php echo $adminInfo->name; ?>
                        </span>

                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">


                        <li>
                            <a href="<?php echo site_url('distributor_profile'); ?>">
                                <i class="ace-icon fa fa-user"></i>
                                Profile
                            </a>
                        </li>

                        <li class="divider"></li>

                        <li>
                            <?php if (!empty($headOffice)): ?>
                                <a href="<?php echo site_url('AuthController/signoutHeadoffice'); ?>">
                                <?php else: ?>
                                    <a href="<?php echo site_url('AuthController/signout'); ?>">
                                    <?php endif; ?>
                                    <i class="ace-icon fa fa-power-off"></i>
                                    Logout
                                </a>
                        </li>




                    </ul>
                </li>
            </ul>
        </div>

        <nav role="navigation" class="navbar-menu pull-left collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <!--                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        Overview
                                        &nbsp;
                                        <i class="ace-icon fa fa-angle-down bigger-110"></i>
                                    </a>
                
                                    <ul class="dropdown-menu dropdown-light-blue dropdown-caret">
                                        <li>
                                            <a href="#">
                                                <i class="ace-icon fa fa-eye bigger-110 blue"></i>
                                                Monthly Visitors
                                            </a>
                                        </li>
                
                                        <li>
                                            <a href="#">
                                                <i class="ace-icon fa fa-user bigger-110 blue"></i>
                                                Active Users
                                            </a>
                                        </li>
                
                                        <li>
                                            <a href="#">
                                                <i class="ace-icon fa fa-cog bigger-110 blue"></i>
                                                Settings
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                
                                <li>
                                    <a href="#">
                                        <i class="ace-icon fa fa-envelope"></i>
                                        Messages
                                        <span class="badge badge-warning">5</span>
                                    </a>
                                </li>-->
            </ul>

            <form class="navbar-form navbar-left form-search" role="search">
                <!--                <div class="form-group">
                                    <input type="text" placeholder="search" />
                                </div>
                
                                <button type="button" class="btn btn-mini btn-info2">
                                    <i class="ace-icon fa fa-search icon-only bigger-110"></i>
                                </button>-->
            </form>
        </nav>
    </div><!-- /.navbar-container -->
</div>