<?php
if (isset($_POST['start_date'])):
    $type_id = $this->input->post('type_id');
    $customer_id = $this->input->post('customer_id');
    $supplier_id = $this->input->post('supplier_id');
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');

endif;
?>

<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Cylinder</a>
                </li>
                <li class="active">Cylinder Stock Report</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-12">
                            <div class="table-header">
                                Cylinder Stock Report
                            </div><br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Type</label>
                                        <div class="col-sm-8">
                                            <select  onchange="selectPayType(this.value)"  id="type_id" name="type_id"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Type">
                                                <option <?php
                                                if ($type_id == 'all') {
                                                    echo "selected";
                                                }
                                                ?> value="all">All</option>
                                                <option <?php
                                                if ($type_id == 2) {
                                                    echo "selected";
                                                }
                                                ?> value="2">Customer</option>
                                                <option <?php
                                                if ($type_id == 3) {
                                                    echo "selected";
                                                }
                                                ?>  value="3">Supplier </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div id="searchValue"></div>
                                    <div id="oldValue">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> ID <span style="color:red;">*</span></label>
                                            <div class="col-sm-10">
                                                <select name="firstType" id="productID" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Name">
                                                    <option value="all">All</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From </label>
                                        <div class="col-sm-4">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                            if (!empty($from_date)) {
                                                echo $from_date;
                                            } else {


                                                echo date('d-m-Y');
                                            }
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">

                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"></label>
                                        <div class="col-sm-4">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                            if (!empty($to_date)):
                                                echo $to_date;
                                            else:
                                                echo date('d-m-Y');
                                            endif;
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-3">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-3">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):

                $type_id = $this->input->post('type_id');
                $firstType = $this->input->post('firstType');
                $searchId = $this->input->post('searchId');

                $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
                $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));



                $total_pvsdebit = '';
                $total_pvscredit = '';

                $total_debit = '';
                $total_credit = '';
                $total_balance = '';
                ?>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-header">
                            Cylinder Stock Report Period <span style="color:greenyellow;">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>
                        </div>

                        <table class="table table-responsive">

                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <p><?php echo $companyInfo->dist_address; ?>
                                    </p>
                                    <strong>Phone : </strong><?php echo $companyInfo->dist_phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->dist_email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->dis_website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-bordered">

                            <?php
                            //all supplier all customer
                            if ($type_id == 'all' && $firstType == 'all'):
                                $ftotalOp = 0;
                                $ftotalIn = 0;
                                $ftotalOut = 0;
                                ?>
                                <thead>
                                    <tr>
                                        <td align="center"><strong>SL</strong></td>
                                        <td align="center"><strong>Customer/Supplier</strong></td>
                                        <td align="center"><strong>Opening ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock In ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock Out ( Pcs )</strong></td>
                                        <td align="center"><strong>Balance ( Pcs )</strong></td>
                                    </tr>
                                </thead>
                                <tbody>  


                                    <?php
                                    $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);

                                    $ctotalIn = 0;
                                    $ctotalOut = 0;
                                    $ctotalOpenig = 0;
                                    foreach ($customerList as $key => $value):
                                        $this->db->select("sum(quantity) as totalOpInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOpOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpOut = $this->db->get('stock')->row();


                                        $this->db->select("sum(quantity) as totalInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockOut = $this->db->get('stock')->row();

                                        $copBalance = $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty;
                                        $ctotalOpenig += $copBalance;

                                        if (($copBalance >= 1) || ($cstockIn->totalInQty > 0) || ($cstockOut->totalOutQty > 0)):
                                            ?>                                
                                            <tr>
                                                <td><?php echo $key + 1; ?></td> 
                                                <td>
                                                    <?php
                                                    $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customer_id);
                                                    echo $customerInfo->customerID . '[ ' . $customerInfo->customerName . ']';
                                                    ?>
                                                </td>
                                                <td align="right">
                                                    <?php
                                                    echo $copBalance
                                                    ?>
                                                </td>

                                                <td align="right"><?php
                                                    echo $cstockIn->totalInQty;
                                                    $ctotalIn += $cstockIn->totalInQty;
                                                    ?></td>    

                                                <td align="right"><?php
                                                    echo $cstockOut->totalOutQty;
                                                    $ctotalOut += $cstockOut->totalOutQty;
                                                    ?></td>   

                                                <td align="right"><?php
                                                    $cbalance = ($ctotalIn - $ctotalOut) + $copBalance;
                                                    // $cbalance = ($ctotalIn - $ctotalOut) + $copBalance;
                                                    echo ($cstockIn->totalInQty - $cstockOut->totalOutQty) + $copBalance;

                                                    // echo ($ctotalIn - $ctotalOut) + $copBalance;
                                                    ?></td>                                    
                                            </tr>
                                            <?php
                                        // die;
                                        endif;
                                    endforeach;


                                    $ftotalOp += $ctotalOpenig;
                                    $ftotalIn += $ctotalIn;
                                    $ftotalOut += $ctotalOut;
                                    ?>
                                    <?php
                                    $ctotalOpenig = 0;
                                    $ctotalIn = 0;
                                    $ctotalOut = 0;


                                    $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);
                                    foreach ($supplierList as $key => $value):

                                        $this->db->select("sum(quantity) as totalOpInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date <', $from_date);
                                        $sstockOpIn = $this->db->get('stock')->row();



                                        $this->db->select("sum(quantity) as totalOpOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date <', $from_date);
                                        $sstockOpOut = $this->db->get('stock')->row();


                                        $this->db->select("sum(quantity) as totalInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $sstockIn = $this->db->get('stock')->row();

                                        // echo $this->db->last_query();die;


                                        $this->db->select("sum(quantity) as totalOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $sstockOut = $this->db->get('stock')->row();

                                        $sopBalance = $sstockOpIn->totalOpInQty - $sstockOpOut->totalOpOutQty;

                                        //  echo $sopBalance;die;

                                        $stotalOpenig += $sopBalance;


                                        if (($sopBalance > 0) || ($sstockIn->totalInQty > 0) || ($sstockOut->totalOutQty > 0)):
                                            ?>                                
                                            <tr>
                                                <td><?php echo $key + 1; ?></td> 
                                                <td>
                                                    <?php
                                                    $customerInfo = $this->Common_model->tableRow('supplier', 'sup_id', $value->sup_id);
                                                    echo $customerInfo->supID . '[ ' . $customerInfo->supName . ']';
                                                    ?>
                                                </td>
                                                <td align="right">
                                                    <?php
                                                    echo $sopBalance
                                                    ?>
                                                </td>

                                                <td align="right"><?php
                                                    echo $sstockIn->totalInQty;
                                                    $stotalIn += $sstockIn->totalInQty;
                                                    ?></td>    

                                                <td align="right"><?php
                                                    echo $sstockOut->totalOutQty;
                                                    $stotalOut += $sstockOut->totalOutQty;
                                                    ?></td>   

                                                <td align="right"><?php
                                                    $sbalance = ($stotalIn - $stotalOut) + $sopBalance;
                                                    echo ($sstockIn->totalInQty - $sstockOut->totalOutQty) + $sopBalance;

                                                    // echo ($stotalIn - $stotalOut) + $sopBalance;
                                                    ?></td>                                    
                                            </tr>
                                            <?php
                                        endif;
                                    endforeach;
                                    $ftotalOp += $stotalOpenig;
                                    $ftotalIn += $stotalIn;
                                    $ftotalOut += $stotalOut;
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" align="right"><strong>Total Cylinder  ( Pcs )</strong></td>                             
                                        <td align="right"><strong><?php echo $ftotalOp; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $ftotalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $ftotalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $sbalance11 = ($ftotalIn - $ftotalOut) + $ftotalOp;


                                                echo $sbalance11;
                                                ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>   
                            <?php endif; ?>



                            <?php
                            //only customer all result



                            if ($type_id == '2' && $firstType == 'all' && $searchId == 'all'):
                                ?>
                                <thead>
                                    <tr>
                                        <td align="center"><strong>SL</strong></td>
                                        <td align="center"><strong>Customer</strong></td>
                                        <td align="center"><strong>Opening ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock In ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock Out ( Pcs )</strong></td>
                                        <td align="center"><strong>Balance ( Pcs )</strong></td>
                                    </tr>
                                </thead>
                                <tbody> 


                                    <?php
                                    $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);

                                    $stotalIn = 0;
                                    $stotalOut = 0;
                                    $stotalOpenig = 0;
                                    foreach ($customerList as $key => $value):
                                        $this->db->select("sum(quantity) as totalOpInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOpOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpOut = $this->db->get('stock')->row();


                                        $this->db->select("sum(quantity) as totalInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('customerId', $value->customer_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockOut = $this->db->get('stock')->row();

                                        $copBalance = $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty;
                                        $stotalOpenig += $copBalance;

                                        if (!empty($copBalance) || !empty($cstockIn->totalInQty) || !empty($cstockOut->totalOutQty)):
                                            ?>                                
                                            <tr>
                                                <td><?php echo $key + 1; ?></td> 
                                                <td>
                                                    <?php
                                                    $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customer_id);
                                                    echo $customerInfo->customerID . '[ ' . $customerInfo->customerName . ']';
                                                    ?>
                                                </td>
                                                <td align="right">
                                                    <?php
                                                    echo $copBalance
                                                    ?>
                                                </td>

                                                <td align="right"><?php
                                                    echo $cstockIn->totalInQty;
                                                    $stotalIn += $cstockIn->totalInQty;
                                                    ?></td>    

                                                <td align="right"><?php
                                                    echo $cstockOut->totalOutQty;
                                                    $ctotalOut += $cstockOut->totalOutQty;
                                                    ?></td>   

                                                <td align="right">
                                                    <?php
                                                    $cbalance = ($ctotalIn - $ctotalOut) + $copBalance;
                                                    echo ($cstockIn->totalInQty - $cstockOut->totalOutQty) + $copBalance

                                                    // echo ($ctotalIn - $ctotalOut) + $copBalance;
                                                    ?></td>                                    
                                            </tr>
                                            <?php
                                        endif;
                                    endforeach;
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" align="right"><strong>Total Cylinder  ( Pcs )</strong></td>                             
                                        <td align="right"><strong><?php echo $stotalOpenig; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $stotalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $stotalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $sbalance11 = ($stotalIn - $stotalOut) + $stotalOpenig;


                                                echo $sbalance11;
                                                ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>   
                            <?php endif; ?>



                            <?php
                            //all supplier all customer
                            if ($type_id == '3' && $firstType == 'all' && $searchId == 'all'):
                                ?>
                                <thead>
                                    <tr>
                                        <td align="center"><strong>SL</strong></td>
                                        <td align="center"><strong>Supplier</strong></td>
                                        <td align="center"><strong>Opening ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock In ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock Out ( Pcs )</strong></td>
                                        <td align="center"><strong>Balance ( Pcs )</strong></td>
                                    </tr>
                                </thead>
                                <tbody>  


                                    <?php
                                    $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);


                                    $ftotalIn = 0;
                                    $ftotalOut = 0;


                                    $stotalIn = 0;
                                    $stotalOut = 0;
                                    $stotalOpenig = 0;
                                    foreach ($supplierList as $key => $value):



                                        $this->db->select("sum(quantity) as totalOpInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date <', $from_date);
                                        $sstockOpIn = $this->db->get('stock')->row();




                                        $this->db->select("sum(quantity) as totalOpOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date <', $from_date);
                                        $sstockOpOut = $this->db->get('stock')->row();


                                        $this->db->select("sum(quantity) as totalInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cin');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $sstockIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where('type', 'Cout');
                                        $this->db->where('supplierId', $value->sup_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $sstockOut = $this->db->get('stock')->row();

                                        $sopBalance = $sstockOpIn->totalOpInQty - $sstockOpOut->totalOpOutQty;
                                        $stotalOpenig += $sopBalance;

                                        if (!empty($sopBalance) || !empty($sstockIn->totalInQty) || !empty($sstockOut->totalOutQty)):
                                            ?>                                
                                            <tr>
                                                <td><?php echo $key + 1; ?></td> 
                                                <td>
                                                    <?php
                                                    $customerInfo = $this->Common_model->tableRow('supplier', 'sup_id', $value->sup_id);
                                                    echo $customerInfo->supID . '[ ' . $customerInfo->supName . ']';
                                                    ?>
                                                </td>
                                                <td align="right">
                                                    <?php
                                                    echo $sopBalance
                                                    ?>
                                                </td>

                                                <td align="right"><?php
                                                    echo $sstockIn->totalInQty;
                                                    $stotalIn += $sstockIn->totalInQty;
                                                    ?></td>    

                                                <td align="right"><?php
                                                    echo $sstockOut->totalOutQty;
                                                    $stotalOut += $sstockOut->totalOutQty;
                                                    ?></td>   

                                                <td align="right"><?php
                                                    $sbalance = ($stotalIn - $stotalOut) + $sopBalance;
                                                    echo ($sstockIn->totalInQty - $sstockOut->totalOutQty) + $sopBalance;

                                                    //  echo ($stotalIn - $stotalOut) + $sopBalance;
                                                    ?></td>                                    
                                            </tr>
                                            <?php
                                        endif;
                                    endforeach;
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" align="right"><strong>Total Cylinder  ( Pcs )</strong></td>                             
                                        <td align="right"><strong><?php echo $stotalOpenig; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $stotalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $stotalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $sbalance11 = ($stotalIn - $stotalOut) + $stotalOpenig;


                                                echo $sbalance11;
                                                ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>   
                            <?php endif; ?>









                            <?php
                            if ($type_id == '2' && $searchId != 'all'):
                                ?>

                                <thead>
                                    <tr>

                                        <td align="center"><strong>Date</strong></td>
                                        <td align="center"><strong>Voucher Type</strong></td>
                                        <td align="center"><strong>Customer</strong></td>
                                        <td align="center"><strong>Product Category</strong></td>
                                        <td align="center"><strong>Product</strong></td>
                                        <td align="center"><strong>Stock In ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock Out ( Pcs )</strong></td>
                                        <td align="center"><strong>Balance ( Pcs )</strong></td>
                                    </tr>
                                </thead>
                                <tbody>


                                    <?php
                                    $this->db->select("sum(quantity) as totalOpInQty");
                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('type', 'Cin');
                                    $this->db->where('customerId', $searchId);
                                    $this->db->where('date <', $from_date);
                                    $cstockOpIn = $this->db->get('stock')->row();

                                    $this->db->select("sum(quantity) as totalOpOutQty");
                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('type', 'Cout');
                                    $this->db->where('customerId', $searchId);
                                    $this->db->where('date <', $from_date);
                                    $cstockOpOut = $this->db->get('stock')->row();

                                    $totalOpenig = $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty;


                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('customerId', $searchId);
                                    $this->db->where_in('type', array('Cin', 'Cout'));
                                    $this->db->where('date >=', $from_date);
                                    $this->db->where('date <=', $to_date);
                                    $query = $this->db->get('stock')->result_array();
                                    // echo $this->db->last_query();die;
                                    //dumpVar($data);
                                    $totalIn = 0;
                                    $totalOut = 0;
                                    ?>
                                    <tr>
                                        <td colspan="7" align="right"><strong>Opening Cylinder Stock (PCS)</strong></td>
                                        <td align="right"><?php echo $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty; ?></td>
                                    </tr>

                                    <?php
                                    foreach ($query as $row):
                                        ?>                                
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td> 
                                            <td><?php echo $this->Common_model->tableRow('generals', 'generals_id', $row['generals_id'])->voucher_no; ?></td> 

                                            <td>
                                                <?php
                                                $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $row['customerId']);
                                                echo $customerInfo->customerID . '[ ' . $customerInfo->customerName . ']';
                                                ?>
                                            </td>
                                            <td><?php echo $this->Common_model->tableRow('productcategory', 'category_id', $row['category_id'])->title; ?></td> 
                                            <td><?php echo $this->Common_model->tableRow('product', 'product_id', $row['product_id'])->productName; ?></td> 

                                            <td  align="right"><?php
                                                if ($row['type'] == 'Cin') {
                                                    echo $row['quantity'];
                                                    $totalIn += $row['quantity'];
                                                }
                                                ?></td>    

                                            <td align="right"><?php
                                                if ($row['type'] == 'Cout') {
                                                    echo $row['quantity'];
                                                    $totalOut += $row['quantity'];
                                                }
                                                ?></td>   

                                            <td align="right"><?php
                                                $balance = $totalIn - $totalOut;


                                                echo $totalIn - $totalOut;
                                                ?></td>                                    
                                        </tr>
                                        <?php
                                    endforeach;
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" align="right"><strong>Total Cylinder  ( Pcs )</strong></td>  
                                        <td align="right"><strong><?php echo $totalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $totalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $balance11 = ($totalIn - $totalOut) + $totalOpenig;


                                                echo $balance11;
                                                ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>  
                                <?php
                            endif;
                            ?>


                            <?php
                            if ($type_id == '3' && $searchId != 'all'):
                                ?>
                                <thead>
                                    <tr>

                                        <td align="center"><strong>Date</strong></td>
                                        <td align="center"><strong>Voucher Type</strong></td>
                                        <td align="center"><strong>Suppliery</strong></td>
                                        <td align="center"><strong>Product Category</strong></td>
                                        <td align="center"><strong>Product</strong></td>
                                        <td align="center"><strong>Stock In ( Pcs )</strong></td>
                                        <td align="center"><strong>Stock Out ( Pcs )</strong></td>
                                        <td align="center"><strong>Balance ( Pcs )</strong></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $this->db->select("sum(quantity) as totalOpInQty");
                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('type', 'Cin');
                                    $this->db->where('supplierId', $searchId);
                                    $this->db->where('date <', $from_date);
                                    $cstockOpIn = $this->db->get('stock')->row();

                                    $this->db->select("sum(quantity) as totalOpOutQty");
                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('type', 'Cout');
                                    $this->db->where('supplierId', $searchId);
                                    $this->db->where('date <', $from_date);
                                    $cstockOpOut = $this->db->get('stock')->row();

                                    $totalOpenig = $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty;






                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('supplierId', $searchId);
                                    $this->db->where_in('type', array('Cin', 'Cout'));
                                    $this->db->where('date >=', $from_date);
                                    $this->db->where('date <=', $to_date);
                                    $query = $this->db->get('stock')->result_array();
                                    // echo $this->db->last_query();die;
                                    //dumpVar($data);
                                    $totalIn = 0;
                                    $totalOut = 0;
                                    ?>

                                    <tr>
                                        <td align="right"><strong>Cylinder Opening Stock (PCS)</strong></td>
                                        <td align="right"><?php echo $totalOpenig; ?></td>
                                    </tr>

                                    <?php
                                    foreach ($query as $row):
                                        ?>                                
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td> 
                                            <td><?php echo $this->Common_model->tableRow('generals', 'generals_id', $row['generals_id'])->voucher_no; ?></td> 

                                            <td>
                                                <?php
                                                $customerInfo = $this->Common_model->tableRow('supplier', 'sup_id', $row['supplierId']);
                                                echo $customerInfo->supID . '[ ' . $customerInfo->supName . ']';
                                                ?>
                                            </td>
                                            <td><?php echo $this->Common_model->tableRow('productcategory', 'category_id', $row['category_id'])->title; ?></td> 
                                            <td><?php echo $this->Common_model->tableRow('product', 'product_id', $row['product_id'])->productName; ?></td> 
                                            <td  align="right"><?php
                                                if ($row['type'] == 'Cin') {
                                                    echo $row['quantity'];
                                                    $totalIn += $row['quantity'];
                                                }
                                                ?></td>    

                                            <td align="right"><?php
                                                if ($row['type'] == 'Cout') {
                                                    echo $row['quantity'];
                                                    $totalOut += $row['quantity'];
                                                }
                                                ?></td>   

                                            <td align="right"><?php
                                                $balance = $totalIn - $totalOut;


                                                echo $totalIn - $totalOut;
                                                ?></td>                                    
                                        </tr>
                                        <?php
                                    endforeach;
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" align="right"><strong>Total Cylinder  ( Pcs )</strong></td>  
                                        <td align="right"><strong><?php echo $totalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $totalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $balance11 = ($totalIn - $totalOut) + $totalOpenig;
                                                echo $balance11;
                                                ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>   
                                <?php
                            endif;
                            ?>

                        </table> 
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>

<script>

                                                function selectPayType(payid) {

                                                    var url = '<?php echo site_url("FinaneController/getPayUserList2") ?>';

                                                    if (payid != 'all') {
                                                        $.ajax({
                                                            type: 'POST',
                                                            url: url,
                                                            data: {'payid': payid},
                                                            success: function (data)
                                                            {
                                                                $(".chosenRefesh").trigger("chosen:updated");
                                                                $("#searchValue").show(1000);
                                                                $("#searchValue").html(data);
                                                                $("#oldValue").hide(1000);
                                                                $('.chosenRefesh').chosen();
                                                                $(".chosenRefesh").trigger("chosen:updated");
                                                            }
                                                        });

                                                    } else {

                                                        $("#searchValue").hide(1000);
                                                        $("#oldValue").show(1000);
                                                    }
                                                }

</script>