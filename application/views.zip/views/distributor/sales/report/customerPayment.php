<?php
if (isset($_POST['start_date'])):
    $customerid = $this->input->post('customerid');
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
endif;
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li class="active"> Customer Payment</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <div class="page-content">
            <form id="publicForm" action=""  method="post" class="form-horizontal">
                <div class="row  noPrint">
                    <div class="col-md-12">

                        <div class="col-sm-10 col-md-offset-1">
                            <div class="table-header">
                                Customer Payment Receive
                            </div>
                            <br>

                            <div style="background-color: grey!important;">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Customer<span style="color:red;"> * </span></label>
                                        <div class="col-sm-8">
                                            <select  name="customerid" class="chosen-select form-control customerId" id="form-field-select-3" data-placeholder="Search by Customer"  onchange="check_pretty_cash(this.value)">
                                                <option value=""></option>
                                                <?php foreach ($customerList as $eachInfo): ?>
                                                    <option <?php
                                                if (!empty($customerid) && $customerid == $eachInfo->customer_id) {
                                                    echo "selected";
                                                }
                                                    ?> value="<?php echo $eachInfo->customer_id; ?>"><?php echo $eachInfo->customerName; ?>[<?php echo $eachInfo->customerID; ?>]</option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Receipt ID<span style="color:red;"> * </span></label>
                                        <div class="col-sm-8">
                                            <input readonly type="text"class="form-control"  name="receiptId" value="<?php
                                                    echo $moneyReceitVoucher;
                                                    ?>"  placeholder=""/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Payment Date<span style="color:red;"> * </span></label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker form-control" id="start_date" name="paymentDate" value="<?php
                                                   if (!empty($from_date)) {
                                                       echo $from_date;
                                                   } else {
                                                       echo date('d-m-Y');
                                                   }
                                                    ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy" required/>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Payment Type<span style="color:red;">*</span></label>
                                        <div class="col-sm-8">
                                            <label class="radio-inline"><input checked onclick="getClickValue(this.value)" type="radio" name="payType" class="styled paymentType" checked="checked" value="1">Cash</label>
                                            <label class="radio-inline"><input onclick="getClickValue(this.value)" type="radio" name="payType" class="styled paymentType" value="2" >Bank</label>

                                        </div>
                                    </div>
                                </div>
                                <div  id="bankInfo" style="display: none;" class="col-md-8">

                                    <div class="form-group">
                                        <div class="col-sm-3">
                                            <input type="text" class="form-control required" placeholder="Bank Name" name="bankName" value="" required>
                                        </div>
                                        <div class="col-sm-3">
                                            <input type="text" class="form-control required" placeholder="Branch Name" name="branchName" value="">
                                        </div>

                                        <div class="col-sm-3">
                                            <input type="text" class="form-control  required" placeholder="Check NO" name="checkNo" value="" required>
                                        </div>
                                        <div class="col-sm-3">
                                            <input type="text"class="date-picker form-control" id="start_date" name="date" value="<?php
                                                   if (!empty($from_date)) {
                                                       echo $from_date;
                                                   } else {


                                                       echo date('d-m-Y');
                                                   }
                                                    ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>

                                    </div>

                                </div>

                                <div class="col-md-8" id="cashInfo">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Deposit(DR) <span style="color:red;">*</span></label>
                                            <div class="col-sm-8">
                                                <select  name="accountDr" class="chosen-select form-control checkAccountBalance" id="form-field-select-3" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                    <option value=""></option>
                                                    <?php
                                                    foreach ($accountHeadList as $key => $head) {
                                                        ?>
                                                        <optgroup label="<?php echo $head['parentName']; ?>">
                                                            <?php
                                                            foreach ($head['Accountledger'] as $eachLedger) :
                                                                ?>
                                                                <option paytoAccountCode="<?php echo $eachLedger->code; ?>" paytoAccountName="<?php echo $eachLedger->title; ?>" value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                            <?php endforeach; ?> 
                                                        </optgroup>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <span id="accountBalance"></span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>

                    </div>
                </div><!-- /.col -->

                <div class="row">
                    <div class="col-sm-10 col-md-offset-1">						

                        <div id="voucherheader" class="table-header" style="display: none;">
                            Due Voucher List
                        </div>

                        <span id="customer_result"></span> 
                    </div>
                    <div class="col-sm-10 col-md-offset-1" id="narration" style="display: none;">
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Narration</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <textarea cols="100" rows="2" name="narration" placeholder="Narration" type="text"></textarea>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-10 col-md-offset-1">	
                        <div class="clearfix form-actions" id="submitBtn" style="display: none;">
                            <div class="col-md-offset-3 col-md-9">
                                <button onclick="return isconfirm()" id="subBtn" disabled class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Save
                                </button>
                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" type="reset">
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Reset
                                </button>
                            </div>
                        </div>
                    </div>
                </div> 
            </form>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script type="text/javascript">
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    function checkOverAmount(dynamicId){
        //checkDueAamountOver
        var paymentAmount = parseFloat($("#paymentAmount_" + dynamicId).val());
        if(isNaN(paymentAmount)){
            paymentAmount=0;
        }
        var dueAmount = parseFloat($("#dueAmount_" + dynamicId).val());
        if(isNaN(dueAmount)){
            dueAmount=0;
        }
        
       // alert("payment Amount " + paymentAmount + " DUE AMOUNT " + dueAmount);
        
        if(paymentAmount > dueAmount){
            $("#paymentAmount_" + dynamicId).val('');
           
        }
        
        var totalVoucherPayment = 0;
        $.each($('.amount'), function () {
            voucherAmount = $(this).val();
            if(isNaN(voucherAmount)){
                $(this).val('');
                voucherAmount=0;
            }
            voucherAmount = Number(voucherAmount);
            totalVoucherPayment += voucherAmount;
        });
        if(totalVoucherPayment > 0){
            $("#subBtn").attr('disabled',false);
        }else{
            $("#subBtn").attr('disabled',true);
        }
        
    }

    
    
    
    
    function getClickValue(id) {
        if (id == 1) {
            $("#bankInfo").hide(1000);
            $("#cashInfo").show(1000);
                           
        } else {
            $("#bankInfo").show(1000);
            $("#cashInfo").hide(1000);
        }
    }
    $(document).ready(function () {
        $('.customerId').change(function () {
            var customer = $(this).val();
            $.ajax({
                type: 'POST',
                data: {customer: customer},
                url: '<?php echo site_url('SalesController/customer_ajax'); ?>',
                success: function (result) {
                    $('#customer_result').html(result);
                    $('#voucherheader').show(1000);
                    $('#narration').show(1000);
                    $('#submitBtn').show(1000);
                }
            });
        });
        $('.checkAccountBalance').change(function(){		
            var accountId = $(this).val();		
            $.ajax({
                type: 'POST', 
                data: {account: accountId}, 
                url: '<?php echo site_url('FinaneController/checkBalance'); ?>', 
                success: function(result){ 
                   
                    $('#accountBalance').html(''); 
                    $('#accountBalance').html(result); 
                } 
            });
        });
        
        
        
    });
</script> 
