<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li class="active">Customer Payment</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('customerPaymentAdd'); ?>" class="btn btn-success pull-right">
                    <i class="ace-icon fa fa-plus"></i>
                    Add New
                </a>
            </span>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="table-header">
                    Customer Payment List
                </div>
                <div>
                    <table id="example" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Date</th>
                                <th>PV.No</th>
                                <th>Customer</th>
                                <th>Payment.Type</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($customerPaymentList as $key => $value):
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                    <td><a href="<?php echo site_url('viewMoneryReceipt/' . $value->moneyReceitid); ?>"><?php echo $value->receitID; ?></a></td>

                                    <td>

                                        <a href="<?php echo site_url('customerDashboard/' . $value->customerid); ?>"><?php
                            $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customerid);

                            echo $customerInfo->customerID . ' [ ' . $customerInfo->customerName . ' ] ';
                                ?></a></td>
                                    <td><?php
                                        if ($value->paymentType == 1) {
                                            echo "Cash";
                                        } else {

                                            if ($value->checkStatus == 1):
                                        ?>
                                                <p style="color:red;"> Bank &nbsp; <i class="fa fa-refresh fa-spin fa-fw"></i></p>
                                            <?php else: ?>
                                                <p style="color:green;"> Bank &nbsp;<i class="fa fa-check"></i></p>
                                            <?php
                                            endif;
                                        };
                                        ?></td>
                                    <td><?php echo number_format((float) $value->totalPayment, 2, '.', ','); ?></td>
                                    <td>
                                        <div class="hidden-sm hidden-xs action-buttons">
                                            <a class="blue" href="<?php echo site_url('viewMoneryReceipt/' . $value->moneyReceitid); ?>">
                                                <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                            </a>

                                                                                    <!--                                            <a class="green" href="<?php echo site_url('editPurchases/' . $value->generals_id); ?>">
                                                                                                                                    <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                                                                                                </a>-->



                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>





