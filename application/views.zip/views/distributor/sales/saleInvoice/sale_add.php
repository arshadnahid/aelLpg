<style>
    table tr td{
        margin: 2px!important;
        padding: 2px!important;
    }
</style>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li class="active">Sales Invoice Add</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('salesInvoice'); ?>" class="btn btn-primary pull-right">
                    <i class="ace-icon fa fa-list "></i>
                    List
                </a>
            </span>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Customer ID <span style="color:red;"> *</span></label>
                                <div class="col-sm-6">
                                    <select  id="customerid" name="customer_id"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Customer ID OR Name">
                                        <option></option>
                                        <?php foreach ($customerList as $key => $each_info): ?>
                                            <option value="<?php echo $each_info->customer_id; ?>"><?php echo $each_info->customerID . ' [ ' . $each_info->customerName . ' ] '; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-sm-2" id="newCustomerHide">
                                    <a  data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-success"><i class="fa fa-plus"></i>&nbsp;New Customer</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Invoice No</label>
                                <div class="col-sm-4">
                                    <input type="text" id="form-field-1" name="referenceValue" value="" class="form-control" placeholder="Invoice No"/>
                                </div>
                                <div class="col-sm-3">
                                    <input type="text" id="form-field-1" name="voucherid" readonly value="<?php echo $voucherID; ?>" class="form-control" placeholder="Invoice ID" />
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Reference</label>
                                <div class="col-sm-6">
                                    <select  name="reference"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Reference ID OR Name">
                                        <option></option>
                                        <?php foreach ($referenceList as $key => $each_ref): ?>
                                            <option value="<?php echo $each_ref->reference_id; ?>"><?php echo $each_ref->referenceName; ?></option>
                                        <?php endforeach; ?>
                                    </select>
<!--                                    <input type="text" id="form-field-1" name="reference"  value="" class="form-control" placeholder="Reference" />
                                    -->
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Sales Date  <span style="color:red;"> *</span></label>
                                <div class="col-sm-7">
                                    <div class="input-group">
                                        <input class="form-control date-picker" name="saleDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                        <span class="input-group-addon">
                                            <i class="fa fa-calendar bigger-110"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Payment Type  <span style="color:red;"> *</span></label>
                                <div class="col-sm-6">
                                    <select onchange="showBankinfo(this.value)"  name="paymentType"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Payment Type">
                                        <option></option>
                                        <option value="1" selected >Full Cash</option>
                                        <option value="4">Partial</option>
                                        <option value="2">Credit</option>
                                        <option value="3">Cheque</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Shipping Address</label>
                                <div class="col-sm-7">
                                    <textarea placeholder="Shipping Address" name="shippingAddress" cols="50" rows="1"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div id="showBankInfo" style="display:none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-4">
                                        <input type="text" value="" name="bankName" class="form-control" placeholder="Bank Name"/>
                                    </div> 
                                    <div class="col-sm-3">
                                        <input type="text" value="" name="branchName" class="form-control" placeholder="Branch Name"/>
                                    </div> 
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-4">
                                        <input type="text" value="" class="form-control" name="checkNo" placeholder="Check NO"/>
                                    </div> 
                                    <div class="col-sm-3">
                                        <input class="form-control date-picker" name="checkDate" name="purchasesDate" id="id-date-picker-1" type="text" value="<?php echo date('Y-m-d'); ?>" data-date-format="dd-mm-yyyy" />
                                    </div> 
                                </div>
                            </div>
                        </div>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="table-header">
                                Sales Item
                            </div>
                            <table class="table table-bordered table-hover" id="show_item">
                                <thead>
                                    <tr>
                                        <th nowrap style="width:15%"  align="center"><strong>Product Category <span style="color:red;"> *</span></strong></th>
                                        <th nowrap style="width:27%" align="center"><strong>Product <span style="color:red;"> *</span></strong></th>
                                        <th nowrap style="width:10%" align="center"><strong>Unit <span style="color:red;"> *</span></strong></th>
                                        <th nowrap style="width:10%" align="center"><strong>Quantity <span style="color:red;"> *</span></strong></th>
                                        <th nowrap style="width:7%" align="center"><strong>Returnable(Qty)</strong></th>
                                        <th nowrap style="width:10%" align="center"><strong>Unit Price(BDT)  <span style="color:red;"> *</span></strong></th>
                                        <th nowrap style="width:13%" align="center"><strong>Total Price(BDT) <span style="color:red;"> *</span></strong></th>
                                        <th style="width:8%" align="center"><strong>Action</strong></th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                                <tfoot>
                                    <tr>
                                        <td>
                                            <!--<select data-placeholder="(:-- Select Category --:)"  class="category_product select-search1">-->
                                            <select id="category_product"  onchange="getProductList(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by category">
                                                <option value=""></option>
                                                <?php
                                                foreach ($productCat as $eachCat):
                                                    ?>
                                                    <option catName="<?php echo $eachCat->title; ?>" value="<?php echo $eachCat->category_id; ?>">
                                                        <?php echo $eachCat->title; ?>
                                                    </option>													
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select  id="productID" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product Name">
                                                <option value=""></option>
                                            </select>
                                        </td>
                                        <td>
                                            <select id="productUnit" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Unit">
                                                <option value=""></option>
                                                <?php
                                                foreach ($unitList as $eachUnit):
                                                    ?>
                                                    <option <?php
                                                if ($eachUnit->unit_id == 1) {
                                                    echo "selected";
                                                }
                                                    ?> unitName="<?php echo $eachUnit->unitTtile; ?>" value="<?php echo $eachUnit->unit_id; ?>">
                                                            <?php echo $eachUnit->unitTtile; ?>
                                                    </option>													
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td><input type="hidden" value="" id="stockQty"/><input type="text"  onkeyup="checkStockOverQty(this.value)" class="form-control text-right quantity" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                        <td><input type="hidden" value="" id="returnStockQty"/><input type="text"  onkeyup="checkReturnStockOverQty(this.value)" class="form-control text-right returnQuantity" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                        <td><input type="text" class="form-control text-right rate" placeholder="0.00" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" ></td>
                                        <td><input type="text" class="form-control text-right price" placeholder="0.00" readonly="readonly"></td>
                                        <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Item</a></td>
                                    </tr> 
                                    <tr>
                                        <td align="right" colspan="3"><strong>Total(BDT)</strong></td>
                                        <td align="right"><strong class="total_quantity1"></strong></td>
                                        <td align="right"><strong class="total_return_quantity"></strong></td>
                                        <td align="right"><strong class="total_rate2"></strong></td>
                                        <td align="right"><strong class="total_price"></strong></td>
                                    </tr> 
                                    <tr>
                                        <td colspan="3" rowspan="5">
                                            <textarea style="border:none;" rows="6" class="form-control" name="narration" placeholder="Narration......" type="text"></textarea>
                                        </td>
                                        <td colspan="3"  align="right"><strong>Discount ( - ) </strong></td>
                                        <td><input type="text"  onkeyup="calDiscount()" id="disCount" style="text-align: right" name="discount" value="" class="form-control" placeholder="0.00"   oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                    </tr>
                                    <tr>
                                        <td  colspan="3"   align="right"><strong>Grand Total</strong></td>
                                        <td><input readonly id="grandTotal" type="text" style="text-align: right" name="grandtotal" value="" class="form-control"  placeholder="0.00"/></td>
                                    </tr>
                                    <tr>
                                        <td  colspan="3"   align="right"><strong>VAT(%) ( + )</strong></td>
                                        <td><input type="text" id="vatAmount"  style="text-align: right" name="vat" readonly value="<?php
                                                if (!empty($configInfo->VAT)): echo $configInfo->VAT;
                                                endif;
                                                ?>" class="form-control totalVatAmount"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                    </tr>
                                    <tr>
                                        <td  colspan="3"  align="right"><strong>Net Total</strong></td>
                                        <td><input type="text" id="netAmount"  style="text-align: right" name="netTotal" value="" readonly class="form-control"  placeholder="0.00"/></td>

                                    </tr>

                                    <tr class="partisals" style="display:none;">
                                          <td  colspan="3"  align="right"><strong>Due Amount</strong></td>
                                        <td><input type="text" id="duePayment"  style="text-align: right" name="duePayment" value="" readonly  class="form-control"  placeholder="0.00"/></td>
                                   
                                    </tr>
                                    <tr class="creditDate" style="display:none;">
                                        <td  colspan="3"  align="right"><strong>Due Date</strong></td>
                                        <td>
                                            <div class="input-group">
                                                <input class="form-control date-picker" name="creditDueDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />

                                            </div>

                                        </td>

                                    </tr>
                                    <tr class="partisals">
                                        <td  colspan="3"  align="right"><strong>Add Account <span style="color:red;"> * </span></strong></td>
                                        <td width="100%" colspan="2">
                                            <select   name="accountCrPartial" class="chosen-select   checkAccountBalance" id="partialHead" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                <option value=""></option>
                                                <?php
                                                foreach ($accountHeadList as $key => $head) {
                                                    ?>
                                                    <optgroup label="<?php echo $head['parentName']; ?>">
                                                        <?php
                                                        foreach ($head['Accountledger'] as $eachLedger) :
                                                            ?>
                                                            <option value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                        <?php endforeach; ?>
                                                    </optgroup>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </td>
                                        
                                         <td  align="right"><strong>Partial Payment<span style="color:red;"> * </span></strong></td>
                                        <td><input type="text" id="payment" onkeyup="calculatePartialPayment()" style="text-align: right" name="partialPayment" value=""  class="form-control"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>

                                      </tr>
                                </tfoot> 
                            </table> 

                            <div id="culinderReceive" style="display: none;">
                                <table class="table table-bordered table-hover" id="show_item2">
                                    <thead>
                                        <tr>
                                            <th style="width:18%"  align="center"><strong>Product Category</strong></th>
                                            <th style="width:18%" align="center"><strong>Product</strong></th>
                                            <th style="width:18%" align="center"><strong>Unit</strong></th>
                                            <th style="width:17%" align="center"><strong>Received(Qty)</strong></th>
                                            <th style="width:15%" align="center"><strong>Action</strong></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                    <tfoot>
                                        <tr>
                                            <td>
                                                <!--<select data-placeholder="(:-- Select Category --:)"  class="category_product select-search1">-->
                                                <select id="category_product2"  onchange="getProductList2(this.value)" class=" form-control" id="form-field-select-3" data-placeholder="Search by category">
                                                    <option value="" disabled selected>Select Category</option>
                                                    <?php
                                                    foreach ($productCat as $eachCat):
                                                        ?>
                                                        <option catName="<?php echo $eachCat->title; ?>" value="<?php echo $eachCat->category_id; ?>">
                                                            <?php echo $eachCat->title; ?>
                                                        </option>													
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select  id="productID2" onchange="getProductPrice2(this.value)" class=" form-control" id="form-field-select-3" data-placeholder="Search by product name">
                                                    <option value=""></option>
                                                </select>
                                            </td>
                                            <td>
                                                <select id="productUnit2" class="form-control" id="form-field-select-3" data-placeholder="Search by Unit Name">
                                                    <option value="" selected disabled>Select</option>
                                                    <?php
                                                    foreach ($unitList as $eachUnit):
                                                        ?>
                                                        <option unitName="<?php echo $eachUnit->unitTtile; ?>" <?php
                                                    if ($eachUnit->unit_id == 1) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $eachUnit->unit_id; ?>">
                                                                    <?php echo $eachUnit->unitTtile; ?>
                                                        </option>													
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td><input type="hidden" value="" id="stockQty2"/><input type="text"  onkeyup="checkStockOverQty2(this.value)" class="form-control text-right quantity2" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                            <!--<td><input type="hidden" value="" id="returnStockQty"/><input type="text"  onkeyup="checkReturnStockOverQty(this.value)" class="form-control text-right returnQuantity" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>-->
                                            <td><a id="add_item2" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Item</a></td>
                                        </tr> 
                                        <tr>
                                            <td align="right" colspan="3"><strong>Sub-Total(BDT)</strong></td>
                                            <td align="right"><strong class="total_quantity2"></strong></td>
                                        </tr> 
                                    </tfoot> 
                                </table> 
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="clearfix form-actions" >
                            <div class="col-md-offset-1 col-md-10">
                                <button disabled onclick="return isconfirm()" id="subBtn" class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Save
                                </button>
                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" onclick="showCylinder()" type="button">
                                    <i class="ace-icon fa fa-shopping-cart bigger-110"></i>
                                    Receive Cylinder
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>


<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add New Customer</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="publicForm2" action=""  method="post" class="form-horizontal">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer ID </label>
                                <div class="col-sm-8">
                                    <input type="text" id="customerId" name="customerID" readonly value="<?php echo isset($customerID) ? $customerID : ''; ?>" class="form-control" placeholder="Customer ID" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer Name </label>

                                <div class="col-sm-8">
                                    <input type="text" id="customerName" name="customerName" class="form-control" placeholder="Customer Name" required/>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone</label>
                                <div class="col-sm-8">
                                    <input type="text"  maxlength="11" id="form-field-1 cstPhone" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" onblur="checkDuplicatePhone(this.value)" name="customerPhone" placeholder="Customer Phone" class="form-control" />
                                    <span id="errorMsg"  style="color:red;display: none;"><i class="ace-icon fa fa-spinner fa-spin orange bigger-120"></i> &nbsp;&nbsp;Phone Number already Exits!!</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email</label>
                                <div class="col-sm-8">
                                    <input type="email" id="form-field-1" name="customerEmail" placeholder="Email" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address</label>
                                <div class="col-sm-8">
                                    <!--<textarea id="editor1" cols="10" rows="5" name="comp_add"></textarea>-->
                                    <textarea  cols="6" rows="3" placeholder="Type Address.." class="form-control" name="customerAddress"></textarea>
                                </div>
                            </div>
                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-3 col-md-9">
                                    <button onclick="saveNewCustomer()" id="subBtn2" class="btn btn-info" type="button">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" data-dismiss="modal">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url('assets/saleInvoice.js'); ?>"></script>  