

<style type="text/css">
    #container {
        min-width: 210px;
        max-width: 500px;
        height: 300px;
        margin: 0 auto
    }
    #container2 {
        min-width: 210px;
        max-width: 500px;
        height: 300px;
        margin: 0 auto
    }
    .mystyle{
        height: 78px!important;
    }
</style>

<?php
//dumpVar($inventoryAllStock);
?>


<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="page-header">
                <input type="hidden" id="com_per" value="<?php echo isset($com_per) ? $com_per : 0 ?>">
                <input type="hidden" id="user_per" value="<?php echo isset($user_per) ? $user_per : 0 ?>">
                <input type="hidden" id="emp_per" value="<?php echo isset($emp_per) ? $emp_per : 0 ?>">
                <input type="hidden" id="pro_per" value="<?php echo isset($pro_per) ? $pro_per : 0 ?>">
                <input type="hidden" id="sal_per" value="<?php echo isset($sal_per) ? $sal_per : 0 ?>">
            </div><!-- /.page-header -->
            <div class="row">
                <style>
                    .cusTable tbody tr td{
                        margin: 0px;
                        padding: 2px;
                    }
                </style>
                <div class="row" style="margin-top:-5px!important;">
                    
                    <div class="col-md-6">
                        <div class="table-header">
                                        Company Summary
                                    </div>
                        <table class="table table-bordered cusTable"  style="height:155px;">
                            <thead>
                                <tr>
                                    <th>Account Head</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><a href="<?php echo site_url('generalLedger/58'); ?>">Account Receivable</a></td>
                                    <td align="right"><?php echo number_format(abs($accountReceiable)); ?></td>
                                </tr>
                                <tr>
                                    <td><a  href="<?php echo site_url('generalLedger/50'); ?>">Account Payable</a></td>
                                    <td align="right"><?php echo number_format(abs($accountPayable)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('generalLedger/54'); ?>">Cash In Hand</a></td>
                                    <td align="right"><?php echo number_format(abs($cashInHand)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('bankBook'); ?>">Cash at Bank</a></td>
                                    <td align="right"><?php echo number_format(abs($totalCashAtBank)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('salesReport'); ?>">Total Sales</a></td>
                                    <td align="right"><?php echo number_format(abs($totalSalesAmount)); ?></td>
                                </tr>
                                <tr>
                                    <td><a href="<?php echo site_url('stockReport'); ?>">Inventory</a></td>
                                    <td align="right"><?php echo number_format(abs($inventoryAmount)); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">

<div class="table-header">
                                       Todays Summary
                                    </div>

                        <div class="tabbable"   >
                            <ul class="nav nav-tabs" id="myTab" >
                                <li class="active">
                                    <a data-toggle="tab" href="#supplierInfo">
                                        <i class="green ace-icon fa fa-home bigger-120"></i>
                                        Sales List
                                        <span class="badge badge-danger"><?php echo count($salesList); ?></span>
                                    </a>
                                </li>

                                <li>
                                    <a data-toggle="tab" href="#purchasesList">
                                        Purchases List
                                        <span class="badge badge-danger"><?php echo count($salesList); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#paymentList">
                                        Payment List
                                        <span class="badge badge-danger"><?php echo count($salesPayment); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#voucherList">
                                        Pending Cheque
                                        <span id="totalDue" class="badge badge-danger"></span>
                                    </a>
                                </li>
                            </ul>

                            <div class="tab-content" style="height:120px;">
                                <div id="supplierInfo" class="tab-pane fade in active">
                                    
                                    <div>
                                        <table  class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sl</th>
                                                    <th>Date</th>
                                                    <th>SV.No</th>
                                                    <th>Type</th>
                                                    <th>Customer</th>
                                                    <th>Amount</th>
                                                    <th>Memo</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach ($salesList as $key => $value):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $key + 1; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                                        <td><a title="view invoice" href="<?php echo site_url('salesInvoice_view/' . $value->generals_id); ?>"><?php echo $value->voucher_no; ?></a></td>
                                                        <td><?php echo $this->Common_model->tableRow('form', 'form_id', $value->form_id)->name; ?></td>
                                                        <td><?php
                                                $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customer_id);

                                                echo $customerInfo->customerID . ' [ ' . $customerInfo->customerName . ' ] ';
                                                    ?></td>
                                                        <td><?php echo number_format((float) $value->debit, 2, '.', ','); ?></td>
                                                        <td><?php echo $value->narration; ?></td>
                                                        <td>
                                                            <div class="hidden-sm hidden-xs action-buttons">
                                                                <a class="blue" href="<?php echo site_url('salesInvoice_view/' . $value->generals_id); ?>">
                                                                    <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                                                </a>

                                                                                                                                            <!--                                            <a class="green" href="<?php echo site_url('editPurchases/' . $value->generals_id); ?>">
                                                                                                                                                                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                                                                                                                                                        </a>-->



                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div id="purchasesList" class="tab-pane fade">
                                   
                                    <div>
                                        <table  class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sl</th>
                                                    <th>Date</th>
                                                    <th>SV.No</th>
                                                    <th>Type</th>
                                                    <th>Customer</th>
                                                    <th>Amount</th>
                                                    <th>Memo</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach ($salesList as $key => $value):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $key + 1; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                                        <td><a title="view invoice" href="<?php echo site_url('salesInvoice_view/' . $value->generals_id); ?>"><?php echo $value->voucher_no; ?></a></td>
                                                        <td><?php echo $this->Common_model->tableRow('form', 'form_id', $value->form_id)->name; ?></td>
                                                        <td><?php
                                                $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customer_id);

                                                echo $customerInfo->customerID . ' [ ' . $customerInfo->customerName . ' ] ';
                                                    ?></td>
                                                        <td><?php echo number_format((float) $value->debit, 2, '.', ','); ?></td>
                                                        <td><?php echo $value->narration; ?></td>
                                                        <td>
                                                            <div class="hidden-sm hidden-xs action-buttons">
                                                                <a class="blue" href="<?php echo site_url('salesInvoice_view/' . $value->generals_id); ?>">
                                                                    <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                                                </a>

                                                                                                                                            <!--                                            <a class="green" href="<?php echo site_url('editPurchases/' . $value->generals_id); ?>">
                                                                                                                                                                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                                                                                                                                                        </a>-->



                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="paymentList" class="tab-pane fade">
                                    
                                    <div>
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sl</th>
                                                    <th>Date</th>
                                                    <th>PV.No</th>
                                                    <th>Payment.Type</th>
                                                    <th>Customer</th>
                                                    <th>Amount</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach ($salesPayment as $key => $value):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $key + 1; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                                        <td><a href="<?php echo site_url('viewMoneryReceipt/' . $value->moneyReceitid); ?>"><?php echo $value->receitID; ?></a></td>
                                                        <td><?php
                                                if ($value->paymentType == 1) {
                                                    echo "Cash";
                                                } else {

                                                    if ($value->checkStatus == 1):
                                                            ?>
                                                                    <p style="color:red;"> Cash &nbsp; <i class="fa fa-refresh fa-spin fa-fw"></i></p>
                                                                <?php else: ?>
                                                                    <p style="color:green;"> Bank &nbsp;<i class="fa fa-check"></i></p>
                                                                <?php
                                                                endif;
                                                            };
                                                            ?></td>
                                                        <td><?php
                                                        $customerinfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customerid);
                                                        echo $customerinfo->customerID . ' [ ' . $customerinfo->customerName . ' ] ';
                                                            ?></td>
                                                        <td><?php echo number_format((float) $value->totalPayment, 2, '.', ','); ?></td>
                                                        <td>
                                                            <div class="hidden-sm hidden-xs action-buttons">
                                                                <a class="blue" href="<?php echo site_url('viewMoneryReceipt/' . $value->moneyReceitid); ?>">
                                                                    <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                                                </a>

                                                                                                                                                                <!--                                            <a class="green" href="<?php echo site_url('editPurchases/' . $value->generals_id); ?>">
                                                                                                                                                                                                                <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                                                                                                                                                                            </a>-->



                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="voucherList" class="tab-pane fade">
                                  
                                    <div>
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sl</th>
                                                    <th>PV.No</th>
                                                    <th>Date</th>
                                                    <th>Type</th>
                                                    <th>Amount</th>
                                                    <th>Memo</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $dueVoucherList = '';
                                                $query = $this->Sales_Model->generals_customer($customerDetails->customer_id);
                                                foreach ($query as $row):
                                                    if ($this->Sales_Model->generals_voucher($row['voucher_no']) != 0):
                                                        $dueVoucherList+=1;
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $key + 1; ?></td>
                                                            <td><a href="<?php echo site_url('salesInvoice_view/' . $row['generals_id']); ?>"><?php echo $row['voucher_no'] ?></a></td>
                                                            <td><?php echo date('d.m.Y', strtotime($row['date'])) ?></td>
                                                            <td><?php echo $this->Common_model->tableRow('form', 'form_id', $row['form_id'])->name ?></td>
                                                            <td align="right"><?php echo number_format((float) $this->Sales_Model->generals_voucher($row['voucher_no']), 2, '.', ','); ?></td>
                                                            <td><?php echo $row['narration']; ?></td>
                                                        </tr>
                                                        <?php
                                                    endif;
                                                endforeach;
                                                ?>

                                            <script>
                                                $("#totalDue").text('<?php
                                                if (!empty($dueVoucherList)):
                                                    echo $dueVoucherList;
                                                else: echo "0";
                                                endif;
                                                ?>');  
                           
                                
                                            </script>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="salesOrder" class="tab-pane fade">
                                   
                                    <div>
                                        <table  class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sl</th>
                                                    <th>Date</th>
                                                    <th>SV.No</th>
                                                    <th>Type</th>
                                                    <th>Customer</th>
                                                    <th>Amount</th>
                                                    <th>Memo</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                foreach ($salesOrder as $key => $value):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $key + 1; ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                                        <td><a title="view invoice" href="<?php echo site_url('salesInvoice_view/' . $row['generals_id']); ?>"><?php echo $value->voucher_no; ?></a></td>
                                                        <td><?php echo $this->Common_model->tableRow('form', 'form_id', $value->form_id)->name; ?></td>
                                                        <td><?php
                                                $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $value->customer_id);

                                                echo $customerInfo->customerID . ' [ ' . $customerInfo->customerName . ' ] ';
                                                    ?></td>
                                                        <td><?php echo number_format((float) $value->debit, 2, '.', ','); ?></td>
                                                        <td><?php echo $value->narration; ?></td>
                                                        <td>
                                                            <div class="hidden-sm hidden-xs action-buttons">
                                                                <a class="blue" href="<?php echo site_url('salesInvoice_view/' . $value->generals_id); ?>">
                                                                    <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                                                </a>

                                                                                                                                            <!--                                            <a class="green" href="<?php echo site_url('editPurchases/' . $value->generals_id); ?>">
                                                                                                                                                                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                                                                                                                                                        </a>-->



                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <div id="inventoryStock" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
                    </div>

                    <div class="col-md-6">
                        <div id="container" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
                    </div>
                </div>
                <hr>
                <div class="col-md-6">
                    <div id="container2" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
                </div>

                <div class="col-md-6">
                    <div id="companySummary" style="min-width: 100%; height: 400px; margin: 0 auto"></div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.page-content -->
    </div>
</div>



<script type="text/javascript">

    Highcharts.chart('container2', {

        title: {
            text: 'Daily Sales,Purchases Summary The month of <?php echo date('F Y', strtotime(date('Y-m-d'))); ?>'
        },

        credits: {
            enabled: false
        },
        subtitle: {
            text: ''
        },

        yAxis: {
            title: {
                text: 'Amount'
            }
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle'
        },

        plotOptions: {
            series: {
                label: {
                    connectorAllowed: false
                },
                pointStart: 1
            }
        },

        series: [{
                name: 'Sales',
                data: [
            
<?php
foreach ($fullMonthSalesList as $key => $value) {
    if (!empty($value)) {
        echo $value . ',';
    } else {
        echo 0 . ',';
    }
}
?>
                ]
       
            },{
                name: 'Purchases',
                data: [
<?php
foreach ($fullMonthPurchasesList as $key => $value) {
    if (!empty($value)) {
        echo $value . ',';
    } else {
        echo 0 . ',';
    }
}
?>]}],
                    responsive: {
                        rules: [{
                                condition: {
                                    maxWidth: 1500
                                },
                                chartOptions: {
                                    legend: {
                                        layout: 'horizontal',
                                        align: 'center',
                                        verticalAlign: 'bottom'
                                    }
                                }
                            }]
                    }

                });
</script>


<script type="text/javascript">

                Highcharts.chart('container', {
                    credits: {
                        enabled: false
                    },
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: 'Top Sales Product List'
                    },
                    subtitle: {
                        text: ''
                    },
                    xAxis: {
                        categories: [
                            '1',
                
                        ],
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'TOP Sales Product (Qty)'
                        }
                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} Qty</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },
                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },
                    series: [
            
<?php foreach ($topSalesProduct as $each): ?>
                                                                                                                                                                                        
                            {
                                name: '<?php echo $each->productName; ?>',
                                data: [<?php echo $each->totalQty; ?>]

                            },
<?php endforeach; ?>
            
                    ]
                });
</script>
<script type="text/javascript">

                Highcharts.chart('inventoryStock', {
                    credits: {
                        enabled: false
                    },
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: 'Inventory Product Stock'
                    },
                    subtitle: {
                        text: ''
                    },
                    xAxis: {
                        categories: [
                            '1',
                
                        ],
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Inventory Product Stock (Qty)'
                        }
                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} Qty</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },
                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },
                    series: [
            
<?php
foreach ($inventoryAllStock as $key => $each):
    $productStockInfo = explode("-", $each);
    // dumpVar($productStockInfo);
    ?>
                                                                                                                                                                                        
                                {
                                    name: '<?php echo $productStockInfo[1]; ?>',
                                    data: [<?php echo $productStockInfo[0]; ?>]

                                },
<?php endforeach; ?>
            
                    ]
                });
</script>
<script type="text/javascript">

                Highcharts.chart('companySummary', {
                    credits: {
                        enabled: false
                    },
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: 'Company Summary'
                    },
                    subtitle: {
                        text: ''
                    },
                    xAxis: {
                        categories: [
                            '1',
                
                        ],
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Company Summary by 1k(1000)'
                        }
                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} BDT</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },
                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },
                    series: [
            

                                                                                
                        {
                            name: 'Account Receiable',
                            data: [<?php echo $accountReceiable; ?>]

                        },
                        {
                            name: 'Account Payable',
                            data: [<?php echo abs($accountPayable); ?>]

                        },
                        {
                            name: 'Cash in Hand',
                            data: [<?php echo $cashInHand; ?>]

                        },
                        {
                            name: 'Cash At Bank',
                            data: [<?php echo $totalCashAtBank; ?>]

                        },
                        {
                            name: 'Total Sales',
                            data: [<?php echo $totalSalesAmount; ?>]

                        },

            
                    ]
                });
</script>









