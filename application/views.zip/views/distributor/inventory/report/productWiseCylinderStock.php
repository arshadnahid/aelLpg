<?php
if (isset($_POST['start_date'])):
    $start_date = $this->input->post('start_date');
    $end_date = $this->input->post('end_date');
    $productId = $this->input->post('productId');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales Report</a>
                </li>
                <li class="active">Product Wise Cylinder Stock</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="table-header">
                                Product Wise Cylinder Stock Report
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Product</label>
                                        <div class="col-sm-8">
                                            <select  name="productId" class="chosen-select form-control supplierid" id="form-field-select-3" data-placeholder="Search by Product">

                                                <option <?php
                                                if ($productId == 'all') {
                                                    echo "selected";
                                                }
                                                ?> value="all">All</option>

                                                <?php
                                                foreach ($productList as $eachInfo):
                                                    $brandInfo = $this->Common_model->tableRow('brand', 'brandId', $eachInfo->brand_id)->brandName;
                                                    ?>
                                                    <option <?php
                                                    if (!empty($productId) && $productId == $eachInfo->product_id) {
                                                        echo "selected";
                                                    }
                                                    ?> value="<?php echo $eachInfo->product_id; ?>"><?php echo $eachInfo->productName . ' [ ' . $brandInfo . ' ] '; ?></option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                            if (!empty($start_date)) {
                                                echo $start_date;
                                            } else {
                                                echo date('d-m-Y');
                                            }
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                            if (!empty($end_date)) {
                                                echo $end_date;
                                            } else {
                                                echo date('d-m-Y');
                                            }
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1"></label>
                                        <div class="col-sm-5">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-5">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):
                $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
                $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));
                $productId11 = $this->input->post('productId');
                ?>
                <div class="row">
                    <div class="col-xs-10 col-xs-offset-1">

                        <div class="table-header">
                            Product Wise Cylinder Stock Report <span style="color:greenyellow;">From <?php echo $start_date; ?> To <?php echo $end_date; ?></span>
                        </div>


                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <p><?php echo $companyInfo->dist_address; ?>
                                    </p>
                                    <strong>Phone : </strong><?php echo $companyInfo->dist_phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->dist_email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->dis_website; ?><br>
                                    <strong><?php echo "Product Wise Cylinder Stock Report"; ?></strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-striped table-bordered table-hover table-responsive">

                            <?php if ($productId11 == 'all'):
                               
                                ?>


                                <thead>
                                    <tr>
                                        <td align="center"><strong>SL</strong></td>
                                        <td align="center"><strong>Product</strong></td>
                                        <td align="center"><strong>Opening (Pcs)</strong></td>
                                        <td align="center"><strong>Stock In (Pcs)</strong></td>
                                        <td align="center"><strong>Stock Out (Pcs)</strong></td>
                                        <td align="center"><strong>Balance (Pcs)</strong></td>
                                    </tr>
                                </thead>
                                <tbody>            

                                    <?php
                                    $fstockIn = 0;
                                    $fstockOut = 0;
                                    $ctotalOpenig=0;
                                    $fstockOpen = 0;
                                    $sl = 1;
                                    
                                    
                                    foreach ($productList2 as $key => $eachProduct):

                                        $inArray=array('Cin','In');
                                        $outArray=array('Cout','Out');
                                        
                                        $this->db->select("sum(quantity) as totalOpInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where_in('type', $inArray);
                                        $this->db->where('product_id', $eachProduct->product_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOpOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where_in('type', $outArray);
                                        $this->db->where('product_id', $eachProduct->product_id);
                                        $this->db->where('date <', $from_date);
                                        $cstockOpOut = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalInQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where_in('type', $inArray);
                                        $this->db->where('product_id', $eachProduct->product_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockIn = $this->db->get('stock')->row();

                                        $this->db->select("sum(quantity) as totalOutQty");
                                        $this->db->where('dist_id', $dist_id);
                                        $this->db->where_in('type', $outArray);
                                        $this->db->where('product_id', $eachProduct->product_id);
                                        $this->db->where('date >=', $from_date);
                                        $this->db->where('date <=', $to_date);
                                        $cstockOut = $this->db->get('stock')->row();
                                        $copBalance = $cstockOpIn->totalOpInQty - $cstockOpOut->totalOpOutQty;
                                        $ctotalOpenig += $copBalance;
                                        if (!empty($copBalance) || !empty($cstockIn->totalInQty) || !empty($cstockOut->totalOutQty)):

                                            $fstockOpen += $copBalance;
                                            $fstockIn += $cstockIn->totalInQty;
                                            $fstockOut += $cstockOut->totalOutQty;
                                            ?>                                
                                            <tr>
                                                <td><?php
                                                    echo $sl;
                                                    $sl++;
                                                    ?></td>
                                                <td>
                                                    <?php
                                                    $brandName = $this->Common_model->tableRow('brand', 'brandId', $eachProduct->brand_id)->brandName;
                                                    echo $eachProduct->productName . ' [ ' . $brandName . ' ] ';
                                                    ?>
                                                </td>
                                                <td align="right"><?php
                                                    echo $copBalance;
                                                    ?></td>

                                                <td align="right"><?php echo $cstockIn->totalInQty; ?></td>
                                                <td align="right"><?php echo $cstockOut->totalOutQty; ?></td>
                                                <td align="right"><?php
                                                    $balanceCurrent = ($cstockIn->totalInQty - $cstockOut->totalOutQty) + $copBalance;
                                                    $cbalance = ($fstockIn - $fstockOut) + $fstockOpen;
                                                    echo $balanceCurrent;
                                                    ?></td>
                                            </tr>

                                            <?php
                                        endif;
                                    endforeach;
                                    ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" align="right"><strong>Total Closing Cylinder Stock ( Pcs )</strong></td>                             
                                        <td align="right"><strong><?php echo $fstockOpen; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $fstockIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $fstockOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
                                                $bal = ($fstockIn - $fstockOut) + $fstockOpen;
//                            if ($bal > 0) {
//                                echo "Payable = ";
//                            } else {
//                                echo "Receiable = ";
//                            }
                                                echo ($fstockIn - $fstockOut) + $fstockOpen;
                                                ?>&nbsp;</strong></td>

                                    </tr>
                                </tfoot> 
                            <?php else: ?>  
                                <thead>
                                    <tr>
                                        <td align="center"><strong>SL</strong></td>
                                        <td align="center"><strong>Date</strong></td>
                                        <td align="center"><strong>Voucher</strong></td>
                                        <td align="center"><strong>Customer/Supplier</strong></td>
                                        <td align="center"><strong>Product</strong></td>
                                        <td align="center"><strong>Stock In</strong></td>
                                        <td align="center"><strong>Stock Out</strong></td>
                                        <td align="center"><strong>Balance</strong></td>
                                    </tr>
                                </thead>
                                <tbody>            

                                    <?php
                                    $totalIn = 0;
                                    $totalOut = 0;
                                    $totalOpenig = 0;
                                    $this->db->select("*");
                                    $this->db->from("stock");
                                    $this->db->where('stock.product_id', $productId11);
                                    $this->db->where('stock.dist_id', $dist_id);
                                    // $this->db->where('stock.type', 'Cin');
                                    $this->db->where('stock.date >=', $from_date);
                                    $this->db->where('stock.date <=', $to_date);
                                    $this->db->where_in('stock.type', array('Cin', 'Cout'));
                                    $ledgerReport = $this->db->get()->result();
                                    $totalIn = 0;
                                    $totalOut = 0;
                                    foreach ($ledgerReport as $key => $eachInfo):

                                        $ttotalIn = 0;
                                        $ttotalOut = 0;
                                        ?>                                
                                        <tr>
                                            <td><?php echo $key + 1; ?></td> 
                                            <td><?php echo $eachInfo->date; ?></td> 
                                            <td><?php echo $eachInfo->voucher_no; ?></td> 
                                            <td>
                                                <?php
                                                $customerInfo = $this->Common_model->tableRow('customer', 'customer_id', $eachInfo->customerId);
                                                if (!empty($customerInfo)) {
                                                    echo $customerInfo->customerID . '[ ' . $customerInfo->customerName . ']';
                                                }

                                                $suplierInfo = $this->Common_model->tableRow('supplier', 'sup_id', $eachInfo->supplierId);
                                                if (!empty($suplierInfo)) {
                                                    echo $suplierInfo->supID . '[ ' . $suplierInfo->supName . ']';
                                                }

                                                if (empty($customerInfo) && empty($suplierInfo)) {
                                                    echo "Opening Clinder";
                                                }
                                                ?>


                                            </td>
                                            <td>
                                                <?php
                                                $productinfo = $this->Common_model->tableRow('product', 'product_id', $eachInfo->product_id);
                                                $brandInfo = $this->Common_model->tableRow('brand', 'brandId', $productinfo->brand_id)->brandName;
                                                echo $productinfo->productName . ' [ ' . $brandInfo . ' ]';
                                                ?>
                                            </td>
                                            <td align="right">
                                                <?php
                                                if ($eachInfo->type == 'Cin') {
                                                    echo $eachInfo->quantity;
                                                    $ttotalIn = $eachInfo->quantity;
                                                    $totalIn += $eachInfo->quantity;
                                                }
                                                ?>
                                            </td>
                                            <td align="right">
                                                <?php
                                                if ($eachInfo->type == 'Cout') {
                                                    echo $eachInfo->quantity;
                                                    $ttotalOut = $eachInfo->quantity;
                                                    $totalOut += $eachInfo->quantity;
                                                }
                                                ?>
                                            </td>
                                            <td align="right">
                                                <?php
//                                                $bal = $totalIn - $totalOut;
//                                                if ($bal > $bal) {
//                                                    echo "Payable = ";
//                                                } else {
//                                                    echo "Receiable = ";
//                                                }



                                                echo $ttotalIn - $ttotalOut;
                                                // echo $totalIn - $totalOut;
                                                ?>
                                            </td>


                                        </tr>
                                    <?php endforeach; ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" align="right"><strong>Total Closing Cylinder Stock (PCS)</strong></td>                             
                                        <td align="right"><strong><?php echo $totalIn; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php echo $totalOut; ?>&nbsp;</strong></td>
                                        <td align="right"><strong><?php
//                            $bal = $totalIn - $totalOut;
//                            if ($bal > $bal) {
//                                echo "Payable = ";
//                            } else {
//                                echo "Receiable = ";
//                            }
                                                echo $totalIn - $totalOut;
                                                ?>&nbsp;</strong></td>

                                    </tr>
                                </tfoot> 
                            <?php endif; ?>
                        </table> 
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
