<?php
if (isset($_POST['start_date'])):

    $supplierId = $this->input->post('supplierId');
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
endif;
?>

<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li class="active">Supplier Wise Purchases Report</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="table-header">
                                Supplier Wise Purchases Report
                            </div><br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Supplier ID</label>
                                        <div class="col-sm-9">
                                            <select  id="customerid" name="supplierId"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Supplier ID or Name">

                                                <option <?php
                                                if ($supplierId == 'all') {
                                                    echo "selected";
                                                }
                                                ?> value="all">All</option>
                                                    <?php foreach ($supplierList as $key => $each_info): ?>
                                                    <option <?php
                                                    if (!empty($supplierId) && $supplierId == $each_info->sup_id) {
                                                        echo "selected";
                                                    }
                                                    ?> value="<?php echo $each_info->sup_id; ?>"><?php echo $each_info->supID . ' [ ' . $each_info->supName . ' ] '; ?></option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                            if (!empty($from_date)) {
                                                echo $from_date;
                                            } else {


                                                echo date('d-m-Y');
                                            }
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                            if (!empty($to_date)):
                                                echo $to_date;
                                            else:
                                                echo date('d-m-Y');
                                            endif;
                                            ?>" data-date-format='dd-mm-yyyy' placeholder="End Date:dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">

                                        <div class="col-sm-6">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-6">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):

                $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
                $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));
                $supplierId = $this->input->post('supplierId');

                if ($supplierId != 'all'):


                    unset($_SESSION["supplierId"]);
                    unset($_SESSION["start_date"]);
                    unset($_SESSION["end_date"]);


                    $_SESSION["supplierId"] = $supplierId;
                    $_SESSION["start_date"] = $from_date;
                    $_SESSION["end_date"] = $to_date;
                    $dist_id = $this->dist_id;


                    $total_pvsdebit = '';
                    $total_pvscredit = '';

                    $total_debit = '';
                    $total_credit = '';
                    $total_balance = '';
                    ?>
                    <div class="row">
                        <div class="col-xs-10 col-xs-offset-1">
                            <div class="table-header">
                                Purchases Report Period from <?php echo $from_date; ?> To <?php echo $to_date; ?>
                            </div>

                            <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('InventoryController/supplierPurchasesReport_export_excel/') ?>" class="btn btn-success pull-right noPrint">
                                <i class="ace-icon fa fa-download"></i>
                                Excel 
                            </a>
                            <table class="table table-responsive">

                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <p><?php echo $companyInfo->dist_address; ?>
                                        </p>

                                        <strong>Phone : </strong><?php echo $companyInfo->dist_phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->dist_email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->dis_website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td align="center"><strong>Date</strong></td>
                                        <td align="center"><strong>Voucher No.</strong></td>
                                        <td align="center"><strong>Payment Type</strong></td>
                                        <td align="center"><strong>Memo</strong></td>
                                        <td align="center"><strong>Amount</strong></td>
                                    </tr>
                                </thead>
                                <tbody>                             

                                    <?php
                                    $this->db->where('dist_id', $dist_id);
                                    $this->db->where('form_id', 11);
                                    $this->db->where('supplier_id', $supplierId);
                                    $this->db->where('date >=', $from_date);
                                    $this->db->where('date <=', $to_date);
                                    $query = $this->db->get('generals')->result_array();

                                    $total_debit = 0;
                                    foreach ($query as $row):
                                        ?>                                
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td> 
                                            <td><a href="<?php echo site_url('viewPurchases/' . $row['generals_id']); ?>"><?php echo $row['voucher_no']; ?></a></td> 
                                            <td><?php
                                                if ($row['payType'] == 1) {
                                                    echo "Cash";
                                                } elseif ($row['payType'] == 2) {
                                                    echo "Credit";
                                                } else {
                                                    echo "Bank";
                                                }
                                                ?></td> 
                                            <td><?php echo $row['memo']; ?></td>                                
                                            <td align="right"><?php
                                                echo number_format((float) abs($row['debit']), 2, '.', ',');
                                                $total_debit += $row['debit'];
                                                ?></td>                                    

                                        </tr>
                                    <?php endforeach; ?>
                                    <!-- /Search Balance -->                            
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" align="right"><strong>Total Purchases Amount</strong></td>                             
                                        <td align="right"><strong><?php echo number_format((float) abs($total_debit), 2, '.', ','); ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>                            
                            </table> 
                        </div>
                    </div>

                    <?php
                else:


                    unset($_SESSION["supplierId"]);
                    unset($_SESSION["start_date"]);
                    unset($_SESSION["end_date"]);


                    $_SESSION["supplierId"] = $supplierId;
                    $_SESSION["start_date"] = $from_date;
                    $_SESSION["end_date"] = $to_date;
                    $dist_id = $this->dist_id;


                    $total_pvsdebit = '';
                    $total_pvscredit = '';

                    $total_debit = '';
                    $total_credit = '';
                    $total_balance = '';
                    ?>
                    <div class="row">
                        <div class="col-xs-10 col-xs-offset-1">
                            <div class="table-header">
                                Purchases Report Period from <?php echo $from_date; ?> To <?php echo $to_date; ?>
                            </div>

                            <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('InventoryController/supplierPurchasesReport_export_excel/') ?>" class="btn btn-success pull-right noPrint">
                                <i class="ace-icon fa fa-download"></i>
                                Excel 
                            </a>
                            <table class="table table-responsive">

                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <p><?php echo $companyInfo->dist_address; ?>
                                        </p>

                                        <strong>Phone : </strong><?php echo $companyInfo->dist_phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->dist_email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->dis_website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td align="center"><strong>Sl</strong></td>
                                        <td align="center"><strong>Supplier</strong></td>
                                        <td align="center"><strong>Amount</strong></td>
                                    </tr>
                                </thead>
                                <tbody>                             
                                    <?php
                                    $total_debit = 0;
                                    $sl = 1;

                                    foreach ($supplierList as $key => $value) :

                                        $this->db->select("sum(generals.debit) as totalAmount,supplier.supID,supplier.sup_id,supplier.supName,");
                                        $this->db->join('supplier', 'supplier.sup_id=generals.supplier_id');
                                        $this->db->where('generals.dist_id', $dist_id);
                                        $this->db->where('generals.form_id', 11);
                                        $this->db->where('supplier_id', $value->sup_id);
                                        $this->db->where('generals.date >=', $from_date);
                                        $this->db->where('generals.date <=', $to_date);
                                        $purchasesInfo = $this->db->get('generals')->row();
                                        if (!empty($purchasesInfo->totalAmount)):
                                            $total_debit += $purchasesInfo->totalAmount;
                                            ?>                                
                                            <tr>
                                                <td><?php echo $sl++; ?></td> 
                                                <td><a href="<?php echo site_url('supplierDashboard/' . $purchasesInfo->sup_id); ?>"><?php echo $purchasesInfo->supID . ' [ ' . $purchasesInfo->supName . ' ] '; ?></a></td> 
                                                <td align='right'><?php echo number_format($purchasesInfo->totalAmount); ?></td> 
                                            </tr>

                                            <?php
                                        endif;
                                    endforeach;
                                    ?>
                                    <!-- /Search Balance -->                            
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" align="right"><strong>Total Purchases Amount</strong></td>                             
                                        <td align="right"><strong><?php echo number_format((float) abs($total_debit), 2, '.', ','); ?>&nbsp;</strong></td>
                                    </tr>
                                </tfoot>                            
                            </table> 
                        </div>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

