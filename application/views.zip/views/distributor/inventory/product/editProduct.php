<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Setup</a>
                </li>
                <li class="active">Update Product</li>
            </ul>

            <span style="padding-top: 5px!important;">
                <a  style="border-radius:100px 0 100px 0;" href="<?php echo site_url('productList'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>

        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">

                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product Code</label>
                            <div class="col-sm-6">
                                <input type="text" id="form-field-1" name="product_code" readonly value="<?php echo $productEdit->product_code; ?>" class="form-control" placeholder="Product Code" />

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Product Category</label>
                            <div class="col-sm-6">
                                <select  name="category_id" onchange="get_menu_list()"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search Product Category">
                                    <option></option>
                                    <?php foreach ($productCat as $each_info): ?>
                                        <option <?php
                                    if ($productEdit->category_id == $each_info->category_id) {
                                        echo "selected";
                                    }
                                        ?> value="<?php echo $each_info->category_id; ?>"><?php echo $each_info->title; ?></option>
                                        <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Brand</label>
                            <div class="col-sm-6">
                                <select  name="brand"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search Brand">
                                    <option>--- Select Brand ---</option>
                                    <?php foreach ($brandList as $each_info): ?>
                                        <option <?php
                                    if ($productEdit->brand_id == $each_info->brandId) {
                                        echo "selected";
                                    }
                                        ?> value="<?php echo $each_info->brandId; ?>"><?php echo $each_info->brandName; ?></option>
                                        <?php endforeach; ?>
                                </select>
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Model Name</label>
                            <div class="col-sm-6">
                                <input type="text" id="form-field-1" name="productName"   value="<?php echo $productEdit->productName; ?>"  class="form-control" placeholder="Product Model Name" />

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Purchases Price</label>
                            <div class="col-sm-6">
                                <input type="text" id="form-field-1" name="purchases_price"  value="<?php echo $productEdit->purchases_price; ?>"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" value="" class="form-control" placeholder="Purchases Price" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Retail Price (MRP)</label>
                            <div class="col-sm-6">
                                <input type="text" id="form-field-1" name="salesPrice"   value="<?php echo $productEdit->salesPrice; ?>"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" value="" class="form-control" placeholder="Sales Price" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Wholesale Price</label>
                            <div class="col-sm-6">
                                <input type="text" id="form-field-1" name="retailPrice"  value="<?php echo $productEdit->retailPrice; ?>"   oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  value="" class="form-control" placeholder="Wholesale Price" />

                            </div>
                        </div>


                        <div class="clearfix form-actions" >
                            <div class="col-md-offset-3 col-md-9">
                                <button onclick="return isconfirm()" id="subBtn" class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Update
                                </button>
                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" type="reset">
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Reset
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>
<script>
    function checkDuplicateCategory(catName){
        var url = '<?php echo site_url("SetupController/checkDuplicateCategory") ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data:{ 'catName': catName},
            success: function (data)
            {
                if(data == 1){
                    $("#subBtn").attr('disabled',true);
                    $("#errorMsg").show();
                }else{
                    $("#subBtn").attr('disabled',false);
                    $("#errorMsg").hide();
                }
            }
        });
        
    }
    
    $('#colorpicker1').colorpicker();
</script>