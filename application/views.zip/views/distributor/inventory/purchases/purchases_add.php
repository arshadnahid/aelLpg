<div class="main-content" >
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Purchases</a>
                </li>
                <li class="active">Purchases Add</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('purchases_list'); ?>" class="btn btn-primary pull-right">
                    <i class="ace-icon fa fa-list "></i>
                    List
                </a>
            </span>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Supplier ID<span style="color:red;"> *</span></label>
                                <div class="col-sm-6">
                                    <select  id="supplierid" name="supplierID" onchange="get_menu_list()" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Supplier ID or Name" required>
                                        <option></option>
                                        <?php foreach ($supplierList as $key => $each_info): ?>
                                            <option value="<?php echo $each_info->sup_id; ?>"><?php echo $each_info->supID . ' [ ' . $each_info->supName . ' ] '; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-sm-2" id="hideNewSup">
                                    <a  data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-success"><i class="fa fa-plus"></i>&nbsp;New Supplier</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Voucher ID<span style="color:red;"> *</span></label>
                                <div class="col-sm-7">
                                    <input type="text" id="form-field-1" name="voucherid" readonly value="<?php echo $voucherID; ?>" class="form-control" placeholder="Product Code" required/>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Reference</label>
                                <div class="col-sm-6">
                                    <input type="text" id="form-field-1" name="reference"  value="" class="form-control" placeholder="Reference" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Purchases Date<span style="color:red;"> *</span></label>
                                <div class="col-sm-7">
                                    <div class="input-group">
                                        <input class="form-control date-picker" name="purchasesDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" required/>
                                        <span class="input-group-addon">
                                            <i class="fa fa-calendar bigger-110"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Payment Type<span style="color:red;"> *</span></label>
                                <div class="col-sm-6">
                                    <select onchange="showBankinfo(this.value)"  name="paymentType"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Payment Type" required>
                                        <option></option>
                                        <option value="1" selected >Full Cash</option>
                                        <option value="4">Partial</option>
                                        <option value="2">Credit</option>
                                        <option value="3">Cheque</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" id="hideAccount">                    
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Pay. From( CR ) <span style="color:red;">*</span></label>
                                <div class="col-sm-7">
                                    <select  name="accountCr" class="chosen-select form-control  checkAccountBalance" id="form-field-select-3" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                        <option value=""></option>
                                        <?php
                                        foreach ($accountHeadList as $key => $head) {
                                            ?>
                                            <optgroup label="<?php echo $head['parentName']; ?>">
                                                <?php
                                                foreach ($head['Accountledger'] as $eachLedger) :
                                                    ?>
                                                    <option value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-sm-2">
                                    <input type="text" id="accountBalance" readonly name="balance"  value="" class="form-control" placeholder="Balance" />
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6" id="showAccount" style="display: none;">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Due Date</label>
                                <div class="col-sm-7">

                                    <div class="input-group">
                                        <input class="form-control date-picker" name="dueDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                        <span class="input-group-addon">
                                            <i class="fa fa-calendar bigger-110"></i>
                                        </span>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <div class="clearfix"></div>

                        <div id="showBankInfo" style="display:none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <input type="text" value="" name="bankName" class="form-control" placeholder="Bank Name"/>
                                    </div> 
                                    <div class="col-sm-4">
                                        <input type="text" value="" name="branchName" class="form-control" placeholder="Branch Name"/>
                                    </div> 
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-4">
                                        <input type="text" value="" class="form-control" name="checkNo" placeholder="Check NO"/>
                                    </div> 
                                    <div class="col-sm-3">
                                        <input class="form-control date-picker" name="checkDate" name="purchasesDate" id="id-date-picker-1" type="text" value="<?php echo date('Y-m-d'); ?>" data-date-format="yyyy-mm-dd" />
                                    </div> 
                                </div>
                            </div>
                        </div>

                        <div class="col-md-10 col-md-offset-1">
                            <div class="table-header">
                                Purchases Item
                            </div>


                            <table class="table table-bordered table-hover" id="show_item">
                                <thead>
                                    <tr>
                                        <td style="width:20%"  align="center"><strong>Product Category<span style="color:red;"> *</span></strong></td>
                                        <td style="width:25%" align="center"><strong>Product<span style="color:red;"> *</span></strong></td>
                                        <td style="width:15%" align="center"><strong>Unit<span style="color:red;"> *</span></strong></td>
                                        <td style="width:15%" align="center"><strong>Quantity<span style="color:red;"> *</span></strong></td>
                                        <td style="width:15%" align="center"><strong>Returnable(Qty)</strong></td>
                                        <td nowrap style="width:15%" align="center"><strong>Unit Price(BDT)<span style="color:red;"> *</span> </strong></td>
                                        <td nowrap style="width:15%" align="center"><strong>Total Price(BDT)</strong></td>
                                        <td style="width:15%" align="center"><strong>Action</strong></td>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                                <?php
                                //QQQ $productCat = $this->db->get("productcategory")->result();
                                ?>
                                <tfoot>
                                    <tr>
                                        <td>
                                            <!--<select data-placeholder="(:-- Select Category --:)"  class="category_product select-search1">-->
                                            <select id="category_product"  onchange="getProductList(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Category">
                                                <option value=""></option>
                                                <?php
                                                foreach ($productCat as $eachCat):
                                                    ?>
                                                    <option catName="<?php echo $eachCat->title; ?>" value="<?php echo $eachCat->category_id; ?>">
                                                        <?php echo $eachCat->title; ?>
                                                    </option>													
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select  id="productID" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by product">
                                                <option value=""></option>
                                            </select>
                                        </td>
                                        <td>
                                            <select id="productUnit" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Unit ">
                                                <option value=""></option>
                                                <?php
                                                foreach ($unitList as $eachUnit):
                                                    ?>
                                                    <option unitName="<?php echo $eachUnit->unitTtile; ?>" <?php
                                                if ($eachUnit->unit_id == 1) {
                                                    echo "selected";
                                                }
                                                    ?> value="<?php echo $eachUnit->unit_id; ?>">
                                                                <?php echo $eachUnit->unitTtile; ?>
                                                    </option>													
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td><input type="text" class="form-control text-right quantity" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                        <td><input type="text" class="form-control text-right returnAble" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                        <td><input type="text" class="form-control text-right rate" placeholder="0.00" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" ></td>
                                        <td><input type="text" class="form-control text-right price" placeholder="0.00" readonly="readonly"></td>
                                        <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Item</a></td>
                                    </tr> 
                                    <tr>
                                        <td align="right" colspan="3"><strong>Total(BDT)</strong></td>
                                        <td align="right"><strong class="total_quantity"></strong></td>
                                        <td align="right"><strong class="totalReturnQty"></strong></td>
                                        <td align="right"><strong class="total_rate"></strong></td>
                                        <td align="right"><strong class="total_price"></strong></td>
                                        <td></td>
                                    </tr> 

                                </tfoot> 
                            </table>
                            <table id="partialPayment" class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <td align="right"  width="48%">Add Account</td>
                                        <td width="30%">
                                            <select style="width:100%!important"  name="accountCrPartial" class="chosen-select  checkAccountBalance" id="partialHead" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                <option value=""></option>
                                                <?php
                                                foreach ($accountHeadList as $key => $head) {
                                                    ?>
                                                    <optgroup label="<?php echo $head['parentName']; ?>">
                                                        <?php
                                                        foreach ($head['Accountledger'] as $eachLedger) :
                                                            ?>
                                                            <option value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                        <?php endforeach; ?>
                                                    </optgroup>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </td>
                                        <td width="12%" align="right"><input name="thisAllotment" type="text" onkeyup="calculateDueAmount(this.value)" class="form-control text-right thisAllotment" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                        <td><input type="text" name="dueAllotment" class="form-control text-right dueAmount" placeholder="0.00" readonly="readonly"></td>
                                    </tr>
                                </tbody>
                            </table>

                            <div id="culinderReceive" style="display: none;">
                                <table class="table table-bordered table-hover" id="show_item2">
                                    <thead>
                                        <tr>
                                            <th style="width:18%"  align="center"><strong>Product Category</strong></th>
                                            <th style="width:18%" align="center"><strong>Product</strong></th>
                                            <th style="width:18%" align="center"><strong>Unit</strong></th>
                                            <th style="width:17%" align="center"><strong>Returned (Qty)</strong></th>
                                            <th style="width:15%" align="center"><strong>Action</strong></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                    <tfoot>
                                        <tr>
                                            <td>
                                                <!--<select data-placeholder="(:-- Select Category --:)"  class="category_product select-search1">-->
                                                <select id="category_product2"  onchange="getProductList2(this.value)" class=" form-control" id="form-field-select-3" data-placeholder="Search by category">
                                                    <option value="" disabled selected>Select Category</option>
                                                    <?php
                                                    foreach ($productCat as $eachCat):
                                                        ?>
                                                        <option catName="<?php echo $eachCat->title; ?>" value="<?php echo $eachCat->category_id; ?>">
                                                            <?php echo $eachCat->title; ?>
                                                        </option>													
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select  id="productID2" onchange="getProductPrice2(this.value)" class=" form-control" id="form-field-select-3" data-placeholder="Search by product name">
                                                    <option value=""></option>
                                                </select>
                                            </td>
                                            <td>
                                                <select id="productUnit2" class="form-control" id="form-field-select-3" data-placeholder="Search by Unit Name">
                                                    <option value="" selected disabled>Select</option>
                                                    <?php
                                                    foreach ($unitList as $eachUnit):
                                                        ?>
                                                        <option unitName="<?php echo $eachUnit->unitTtile; ?>" value="<?php echo $eachUnit->unit_id; ?>">
                                                            <?php echo $eachUnit->unitTtile; ?>
                                                        </option>													
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td><input type="hidden" value="" id="stockQty2"/><input type="text"  onkeyup="checkStockOverQty2(this.value)" class="form-control text-right quantity2" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>
                                            <!--<td><input type="hidden" value="" id="returnStockQty"/><input type="text"  onkeyup="checkReturnStockOverQty(this.value)" class="form-control text-right returnQuantity" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  placeholder="0"></td>-->
                                            <td><a id="add_item2" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Item</a></td>
                                        </tr> 
                                        <tr>
                                            <td align="right" colspan="3"><strong>Sub-Total(BDT)</strong></td>
                                            <td align="right"><strong class="total_quantity2"></strong></td>
                                        </tr> 
                                    </tfoot> 
                                </table> 
                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Narration</label>
                                <div class="col-sm-9">
                                    <div class="input-group">
                                        <textarea cols="100" rows="2" name="narration" placeholder="Narration" type="text"></textarea>

                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="clearfix"></div>
                        <div class="clearfix form-actions" >
                            <div class="col-md-offset-3 col-md-9">
                                <button onclick="return isconfirm()" id="subBtn" class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Save
                                </button>
                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" onclick="showCylinder()" type="button">
                                    <i class="ace-icon fa fa-shopping-cart bigger-110"></i>
                                    Returned Cylinder
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add New Supplier</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="publicForm2" action=""  method="post" class="form-horizontal">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Supplier ID </label>
                                <div class="col-sm-6">
                                    <input type="text" id="form-field-1" name="supplierId" readonly value="<?php echo isset($supplierID) ? $supplierID : ''; ?>" class="form-control supplierId" placeholder="SupplierID" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Supplier Name </label>

                                <div class="col-sm-6">
                                    <input type="text" id="form-field-1" name="supName" class="form-control required supName" placeholder="Name" required/>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone</label>
                                <div class="col-sm-6">
                                    <input type="text" maxlength="11" id="form-field-1" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" onblur="checkDuplicatePhone(this.value)" name="supPhone" placeholder="Phone" class="form-control" />
                                    <span id="errorMsg"  style="color:red;display: none;"><i class="ace-icon fa fa-spinner fa-spin orange bigger-120"></i> &nbsp;&nbsp;Phone Number already Exits!!</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email</label>
                                <div class="col-sm-6">
                                    <input type="email" id="form-field-1" name="supEmail" placeholder="Email" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address</label>
                                <div class="col-sm-6">
                                    <!--<textarea id="editor1" cols="10" rows="5" name="comp_add"></textarea>-->
                                    <textarea  cols="6" rows="3" placeholder="Type Address.." class="form-control" name="supAddress"></textarea>
                                </div>
                            </div>



                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-3 col-md-9">
                                    <button onclick="saveNewSupplier()" id="subBtn2" class="btn btn-info" type="button" >
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" data-dismiss="modal">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">

            </div>
        </div>

    </div>
</div>



<script>


    setTimeout(function () {
        $('#partialPayment').fadeOut('fast');
    }, 1000);


    function calculateDueAmount(thisAmount) {
        var thisAllotment = parseFloat($(".thisAllotment").val());

        if (isNaN(thisAllotment)) {
            thisAllotment = 0;
        }

        var invoicePrice = parseFloat($(".total_price").text());
        if (isNaN(invoicePrice)) {
            invoicePrice = 0;
        }
        var dueInvoice = invoicePrice - thisAllotment;
        $(".dueAmount").val(dueInvoice);

    }



    function getProductPrice2(product_id) {

        $("#stockQty2").val('');
        $(".quantity2").val('');

        var total_quantity2 = 0;
        $.each($('.add_quantity2'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity2 += quantity;
        });

        if (isNaN(total_quantity2)) {
            total_quantity2 = 0;
        }


        $.ajax({
            type: "POST",
            url: "<?php echo site_url('FinaneController/getProductPriceForSale'); ?>",
            data: 'product_id=' + product_id,
            success: function (data) {
                $('.rate2').val(data);
            }
        });
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('FinaneController/getProductStock'); ?>",
            data: 'product_id=' + product_id,
            success: function (data) {
                var mainStock = parseFloat(data) - parseFloat(total_quantity);
                if (data != '') {
                    $("#stockQty2").val(data);
                    $(".quantity2").attr("disabled", false);

                    if (mainStock <= 0) {
                        $(".quantity2").attr("disabled", true);
                        $(".quantity2").attr("placeholder", "Stock is =0 ");
                    } else {
                        $(".quantity2").attr("disabled", false);
                        $(".quantity2").attr("placeholder", "Stock is = " + mainStock);
                    }
                } else {
                    $("#stockQty2").val('');
                    $(".quantity2").attr("disabled", true);
                    $(".quantity2").attr("placeholder", "Stock is = 0");
                }


            }
        });




    }


    function getProductList2(cat_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo site_url('InventoryController/getProductList'); ?>",
            data: 'cat_id=' + cat_id,
            success: function (data) {

                $('#productID2').chosen();
                $('#productID2 option').remove();
                $('#productID2').append($(data));
                $("#productID2").trigger("chosen:updated");

            }
        });
    }



    function showCylinder() {
        $("#culinderReceive").toggle(1000);
        //$('#productID2').trigger('chosen:updated');
        //$('#category_product2').trigger('chosen:updated');
    }

    $(document).ready(function () {

        var j = 0;
        $("#add_item2").click(function () {
            var productCatID = $('#category_product2').val();
            var productCatName = $("#category_product2").find('option:selected').attr('catName');

            var productID = $('#productID2').val();
            var productName = $('#productID2').find('option:selected').attr('productName');

            var productUnit = $('#productUnit2').val();
            var unitName = $('#productUnit2').find('option:selected').attr('unitName');



            var quantity = $('.quantity2').val();
            var rate = $('.rate2').val();
            var price = $('.price2').val();
            var returnQuantity = $('.returnQuantity2').val();

            if (productCatID == '') {
                productItemValidation("Product Category can't be empty.");

                return false;
            } else if (productID == '') {
                productItemValidation("Product Name can't be empty.");
                return false;
            } else if (productUnit == '') {
                productItemValidation("Product Unit can't be empty.");
                return false;

            } else if (quantity == '') {
                productItemValidation("Quantity Can't be empty.");
                return false;
            } else if (rate == '') {
                productItemValidation("Unit Price Can't be empty.");
                return false;
            } else {

                $("#show_item2 tbody").append('<tr class="new_item2' + productCatID + productID + '"><td style="padding-left:15px;">' + productCatName + '<input type="hidden" name="category_id2[]" value="' + productCatID + '"></td><td style="padding-left:15px;">' + productName + '<input type="hidden"  name="product_id2[]" value="' + productID + '"></td><td style="padding-left:15px;">' + unitName + '<input type="hidden" name="unit_id2[]" value="' + productUnit + '"></td><td align="right">' + quantity + '<input type="hidden" class="add_quantity2" name="quantity2[]" value="' + quantity + '"></td><td><a del_id2="' + productCatID + productID + '" class="delete_item2 btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
            }

            $("#subBtn").attr('disabled', false);

            $('.quantity2').val('');
            $('.rate2').val('');
            $('.price2').val('');
            $('.returnQuantity2').val('');

            $(".quantity2").attr("placeholder", "0");
            $('#productID2').val('').trigger('chosen:updated');
            $('#category_product2').val('').trigger('chosen:updated');
            findTotalCal2();

        });
        $(document).on('click', '.delete_item2', function () {
            if (confirm("Are you sure?")) {
                var id = $(this).attr("del_id2");
                $('.new_item2' + id).remove();
                findTotalCal2();
            }
        });
    });



    $('#accountBalance').hide();
    $(document).ready(function () {
        $('.checkAccountBalance').change(function () {
            var accountId = $(this).val();
            $.ajax({
                type: 'POST',
                data: {account: accountId},
                url: '<?php echo site_url('FinaneController/checkOnlyBalanceForPayment'); ?>',
                success: function (result) {
                    $('#accountBalance').show();
                    $('#accountBalance').val('');
                    $('#accountBalance').val(result);
                }
            });
        });
    });
    function showBankinfo(id) {

        $('#accountBalance').hide();





        if (id == 4) {
            $("#hideAccount").hide(1000);
            $("#showAccount").hide(1000);
            $("#showBankInfo").hide(1000);
            $("#partialPayment").show(1000);
            //$("#partialHead").css({"width":"30%!important"});
            $(".chosen-select").chosen();
            $(".chosen-select").css({width: "100%!important"});
            $('#partialHead').val('').trigger('chosen:updated');
        } else {
            $("#hideAccount").hide(1000);
            $("#showAccount").hide(1000);
            $("#showBankInfo").hide(1000);
            $("#partialPayment").hide(1000);
        }
        if (id == 3) {
            $("#hideAccount").hide(1000);
            $("#showAccount").hide(1000);
            $("#showBankInfo").show(1000);
        } else {
            $("#hideAccount").hide(1000);
            $("#showAccount").hide(1000);
            $("#showBankInfo").hide(1000);
            // $("#partialPayment").hide(1000); 
        }

        if (id == 1) {
            $("#hideAccount").show(1000);
            $("#showAccount").hide(1000);
        } else if (id == 2) {
            $("#hideAccount").hide(1000);
            $("#showAccount").show(1000);
        }


    }



    function saveNewSupplier() {

        var supplierId = $(".supplierId").val();
        var supName = $(".supName").val();
        if (supplierId != '' && supName != '') {

            var url = '<?php echo site_url("SetupController/saveNewSupplier") ?>';
            $.ajax({
                type: 'POST',
                url: url,
                data: $("#publicForm2").serializeArray(),
                success: function (data)
                {
                    $('#myModal').modal('toggle');
                    $('#hideNewSup').hide();
                    $('#supplierid').chosen();
                    $('#supplierid').append($(data));
                    $("#supplierid").trigger("chosen:updated");
                }
            });
        } else {
            alert("Supplier ID AND supplier name can't be empty.");
            return false;
            //$('#myModal').modal('hide');


        }
    }


    function checkDuplicatePhone(phone) {
        var url = '<?php echo site_url("SetupController/checkDuplicateEmail") ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: {'phone': phone},
            success: function (data)
            {
                if (data == 1) {
                    $("#subBtn2").attr('disabled', true);
                    $("#errorMsg").show();
                } else {
                    $("#subBtn2").attr('disabled', false);
                    $("#errorMsg").hide();
                }
            }
        });

    }


</script>


<script type="text/javascript">

    $(document).ready(function () {
        $('.quantity').keyup(function () {
            $(this).val(parseFloat($(this).val()));
            priceCal();
        });
        $('.rate').keyup(function () {
            var rate = parseFloat($(this).val());
            if (isNaN(rate)) {
                rate = '';
            }
            $(this).val(rate);
            priceCal();
        });
    });
    function priceCal() {
        var quantity = $('.quantity').val();

        if (isNaN(quantity)) {
            quantity = 0;
        }

        var rate = $('.rate').val();
        if (isNaN(rate)) {
            rate = 0;
        }

        $('.price').val(parseFloat(rate * quantity).toFixed(2));
    }


    var findTotalQty = function () {
        var total_quantity = 0;
        $.each($('.add_quantity'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity += quantity;
        });
        $('.total_quantity').html(parseFloat(total_quantity));
    };


    var findTotalRate = function () {
        var total_rate = 0;
        $.each($('.add_rate'), function () {
            rate = $(this).val();
            rate = Number(rate);
            total_rate += rate;
        });
        $('.total_rate').html(parseFloat(total_rate).toFixed(2));
    };
    var findTotalPrice = function () {
        var total_price = 0;
        $.each($('.add_price'), function () {
            price = $(this).val();
            price = Number(price);
            total_price += price;
        });
        $('.total_price').html(parseFloat(total_price).toFixed(2));

    };
    var returnQty = function () {
        var returnqty = 0;
        $.each($('.add_return'), function () {
            returnq = $(this).val();
            returnq = Number(returnq);
            returnqty += returnq;
        });
        $('.totalReturnQty').html(parseFloat(returnqty).toFixed(2));

    };
    var findTotalCal = function () {
        findTotalQty();
        findTotalRate();
        findTotalPrice();
        returnQty();
        calculateDueAmount();
    };



    $(document).ready(function () {

        var j = 0;
        $("#add_item").click(function () {
            var productCatID = $('#category_product').val();
            var productCatName = $("#category_product").find('option:selected').attr('catName');

            var productID = $('#productID').val();
            var productName = $('#productID').find('option:selected').attr('productName');
            var quantity = $('.quantity').val();
            var returnAble = $('.returnAble').val();
            var rate = $('.rate').val();
            var price = $('.price').val();
            var productUnit = $('#productUnit').val();
            var unitName = $('#productUnit').find('option:selected').attr('unitName');
            if (quantity == '') {
                productItemValidation("Qty can't be empty.");
                return false;
            } else if (price == '' || price =='0.00') {
                productItemValidation("Price can't be empty.");
                return false;

            } else if (productID == '') {
                productItemValidation("Product id can't be empty.");
                return false;
            } else {

                $("#show_item tbody").append('<tr class="new_item' + productCatID + productID + '"><td style="padding-left:15px;">' + productCatName + '<input type="hidden" name="category_id[]" value="' + productCatID + '"></td><td style="padding-left:15px;">' + productName + '<input type="hidden"  name="product_id[]" value="' + productID + '"></td><td style="padding-left:15px;">' + unitName + '<input type="hidden" name="unit_id[]" value="' + productUnit + '"></td><td align="right">' + quantity + '<input type="hidden" class="add_quantity" name="quantity[]" value="' + quantity + '"></td><td align="right">' + returnAble + '<input type="hidden" class="add_return" name="add_returnAble[]" value="' + returnAble + '"></td><td align="right">' + rate + '<input type="hidden" class="add_rate" name="rate[]" value="' + rate + '"></td><td align="right">' + price + '<input type="hidden" class="add_price" name="price[]" value="' + price + '"></td><td><a del_id="' + productCatID + productID + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
            }
            $('.quantity').val('');
            $('.rate').val('');
            $('.price').val('');
            $('.returnAble').val('');

            $('#productID').val('').trigger('chosen:updated');
            $('#category_product').val('').trigger('chosen:updated');
            //$('#productUnit').val('').trigger('chosen:updated');
            findTotalCal();

        });
        $(document).on('click', '.delete_item', function () {
            if (confirm("Are you sure?")) {
                var id = $(this).attr("del_id");
                $('.new_item' + id).remove();
                findTotalCal();
            }
        });
    });
    //get product purchases price
    function getProductPrice(product_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo site_url('FinaneController/getProductPrice'); ?>",
            data: 'product_id=' + product_id,
            success: function (data) {

                if (data != '0.00') {
                    $('.rate').val(data);
                } else {
                    $('.rate').val('');
                }


            }
        });
    }
    function getProductList(cat_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo site_url('InventoryController/getProductList'); ?>",
            data: 'cat_id=' + cat_id,
            success: function (data) {

                $('#productID').chosen();
                $('#productID option').remove();
                $('#productID').append($(data));
                $("#productID").trigger("chosen:updated");

            }
        });
    }

</script>  



<script>
    function checkDuplicateCategory(catName) {
        var url = '<?php echo site_url("SetupController/checkDuplicateCategory") ?>';
        $.ajax({
            type: 'POST',
            url: url,
            data: {'catName': catName},
            success: function (data)
            {
                if (data == 1) {
                    $("#subBtn").attr('disabled', true);
                    $("#errorMsg").show();
                } else {
                    $("#subBtn").attr('disabled', false);
                    $("#errorMsg").hide();
                }
            }
        });

    }


</script>