<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li class="active">Inventory Adjustment</li>
            </ul>


            <?php if (empty($inventoryAdjustmentList)): ?>
                <span style="padding-top: 5px!important;">
                    <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('inventoryAdjustmentAdd'); ?>" class="btn btn-success pull-right">
                        <i class="ace-icon fa fa-plus"></i>
                        Add New
                    </a>
                </span>
            <?php endif; ?>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="table-header">
                    Inventory Adjustment
                </div>
                <div>
                    <table id="example" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Date</th>
                                <th>PV.No</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Narration</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($inventoryAdjustmentList as $key => $value):
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($value->date)); ?></td>
                                    <td><?php echo $value->voucher_no; ?></td>
                                    <td><?php echo $this->Common_model->tableRow('form', 'form_id', $value->form_id)->name; ?></td>

                                    <td><?php echo number_format((float) $value->debit, 2, '.', ','); ?></td>
                                    <td><?php echo $value->narration; ?></td>
                                    <td>
                                        <div class="hidden-sm hidden-xs action-buttons">
                                            <a class="blue" href="<?php echo site_url('viewAdjustment/' . $value->generals_id); ?>">
                                                <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

