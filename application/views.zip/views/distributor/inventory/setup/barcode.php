<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory </a>
                </li>
                <li class="active">Product Barcode</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('unit'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <?php
        if (isset($_POST['barcode'])) {

            $productId = $_POST['productId'];
            $quantity = $_POST['quantity'];



            $productInfo = $this->Common_model->get_single_data_by_single_column('product', 'product_id', $productId);
        }
        ?>


        <div class="page-content">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 noPrint">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="table-header">
                                Generate Product Barcode
                            </div><br>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product</label>
                                <div class="col-sm-9">
                                    <select  id="productId" name="productId"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search Product">
                                        <option></option>
                                        <?php foreach ($productList as $each_info): ?>
                                            <option <?php
                                        if (!empty($productId)): echo "selected";
                                        endif;
                                            ?> value="<?php echo $each_info->product_id; ?>"><?php echo $each_info->productName; ?></option>
                                            <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Quantity</label>
                                <div class="col-sm-9">
                                    <input type="text" name="quantity" value="<?php
                                            if (!empty($quantity)) {
                                                echo $quantity;
                                            }
                                            ?>" class="form-control" placeholder="0.00"  id="amount" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">

                                <div class="col-sm-6">
                                    <button onclick="return isconfirm()" id="subBtn" class="btn btn-success btn-xs" name="barcode" type="submit">
                                        <i class="ace-icon fa fa-barcode bigger-110"></i>
                                        Generate
                                    </button>
                                </div>
                                <div class="col-sm-6">
                                    <button  onclick="window.print();" style="cursor:pointer;" id="subBtn" class="btn btn-info btn-xs" >
                                        <i class="ace-icon fa fa-print bigger-110"></i>
                                        Print
                                    </button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>



                <?php
                if (!empty($productId)):
                    ?>

                    <div class="col-md-8 col-md-offset-2">

                        <?php
                        for ($q = 1; $q <= $quantity; $q++) {
                            ?>
                            <div style="padding:10px; border:1px solid gray;min-width:100px; float:left; font-size:12px;text-align:center;margin:10px;">
                                <b style="font-size:14px;" ><span ><?php echo $productInfo->productName; ?></b></br>

                                <b style="font-size:12px;"><span >Price: <?php echo $productInfo->salesPrice; ?>TK</span><b></br>
                                        <img  src="<?php echo base_url(); ?>/barcode/html/image.php?filetype=PNG&dpi=72&scale=1&rotation=0&font_family=Arial.ttf&font_size=12&text=<?php echo $productInfo->product_code; ?>&thickness=25&checksum=&code=BCGcode39" />
                                        </div>
                                        <?php
                                    }
                                    ?>

                                    </div>
                                <?php endif; ?>
                                </div><!-- /.col -->
                                </div><!-- /.row -->
                                </div><!-- /.page-content -->
                                </div>