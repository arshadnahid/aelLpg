<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Setup</a>
                </li>

                <li class="active">System Config</li>
            </ul><!-- /.breadcrumb -->
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>


        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <div class="page-content">
            <div class="row">
                <form action="" method="POST" class="form-horizontal" role="form">
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Distributor Name</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" value="<?php echo $configInfo->companyName; ?>" placeholder="Name" name="dist_name"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Phone</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control"  value="<?php echo $configInfo->dist_phone; ?>" placeholder="Phone" name="dist_phone"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Email</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control"  value="<?php echo $configInfo->dist_email; ?>" placeholder="Email" name="dist_email"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Address</label>
                            <div class="col-sm-6">
                                <textarea type="text" class="form-control" value="" placeholder="Address" name="dist_address"/><?php echo $configInfo->dist_address; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Website</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" value="<?php echo $configInfo->dis_website; ?>" placeholder="Website" name="dis_website"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">VAT(%)</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" value="<?php echo $configInfo->VAT; ?>" placeholder="0.00" name="VAT"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  />
                            </div>
                        </div>
                        <div class="form-group">
                            <script> var fileindex = 1;
                                var inc = 0;
                                var maxImg = 10;
                            </script>

                            <?php require_once 'application/views/upload-api.php'; ?>
                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Logo</label>
                            <div class="col-sm-6">
                                <div class="img_uBtn">
                                    <div  id="upload"  class="upload2"><span> <i class='glyphicon glyphicon-file'></i> Browse</span></div><span id="status" style="display:none"> <img src="<?php echo base_url() ?>scripts/upload_js/loading.gif" /> </span> 
                                </div>
                                <div class="" style="clear: both;"></div><br>
                                <div class="image_content_area">
                                    <img class="img-thumbnail" width="90" height="100" src="<?php echo base_url('uploads/thumb/' . $configInfo->dist_picture); ?>" border="0">
                                </div>

                            </div>
                        </div>
                        <div class="clearfix form-actions">
                            <div class="col-md-offset-3 col-md-9">
                                <button onclick="return isconfirm()" class="btn btn-info" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Update
                                </button>

                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" type="reset">
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Reset
                                </button>
                            </div>
                        </div>


                    </div>

                </form>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>