<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sup Opneing</a>
                </li>
                <li class="active">Supplier Opening List</li>
            </ul>
            <?php if (empty($allBalance)): ?>
                <span style="padding-top: 5px!important;">
                    <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('supplierOpeningAdd'); ?>" class="btn btn-success pull-right">
                        <i class="ace-icon fa fa-plus"></i>
                        Add New
                    </a>
                </span>
            <?php endif; ?>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="table-header">
                    Supplier Opening Payable List
                </div>
                <div>
                    <table id="example" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Supplier Name</th>
                                <th>Payable</th>
                                <!--<th>Credit</th>-->

                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $totalPayable=0;
                            foreach ($allBalance as $key => $value):
                                $totalPayable+=$value->dr;
                                $supName = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $value->client_vendor_id)->supName;
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $supName; ?></td>
                                    <td><?php echo number_format($value->dr); ?></td>
                                    <!--<td><?php echo $value->cr; ?></td>-->


                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                        <td colspan="2" align="right"><strong>Total Payable</strong></td>
                        <td><?php echo number_format($totalPayable);?></td>
                        </tfoot>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div><script src="<?php echo base_url('assets/setup.js'); ?>"></script>




