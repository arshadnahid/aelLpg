
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Setup</a>
                </li>
                <li>You can entry opening balance only one time.<span style="color:red!important;">Be Careful!!</span></li>
            </ul>
            <span style="padding-top: 3px!important;">
                <a style="border-radius:30px 0 30px 0;" href="<?php echo site_url('listChartOfAccount'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="table-header">
                        Add Account Head Opening Balance
                    </div>
                    <div>
                        <form action="" method="post">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td align="center"><strong>Account Name</strong></td>
                                        <td align="center"><strong>Debit (In BDT.)</strong></td>
                                        <td align="center"><strong>Credit (In BDT.)</strong></td>
                                    </tr>
                                </thead>
                                <tbody> 
                                    <!-- chart_class -->
                                    <?php
                                    $total_debit = 0;
                                    $total_credit = 0;
                                    foreach ($accountHeadList as $key => $eachValue):
                                        ?> 

                                        <tr>
                                            <td style="text-align: center;font-weight: bold;font-size: 18px;" colspan="3"><?php echo $eachValue['parentName']; ?></td>
                                        </tr>

                                        <?php
                                        foreach ($eachValue['Accountledger'] as $eachParent):
                                            $condition = array(
                                                'dist_id' => $this->dist_id,
                                                'account' => $eachParent->chartId,
                                            );
                                            $exitsopening = $this->Common_model->get_single_data_by_many_columns('opening_balance', $condition);
                                            $total_debit+=isset($exitsopening->debit) ? $exitsopening->debit : '0';
                                            $total_credit+=isset($exitsopening->credit) ? $exitsopening->credit : '0';
                                            ?>
                                            <tr>
                                                <td><b>&nbsp;<?php echo $eachParent->title; ?></b></td>
                                        <input type="hidden" name="accountid[]" value="<?php echo $eachParent->chartId; ?>"/>
                                        <td><input style="text-align: right" type="text"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  class="form-control debit" value="<?php echo isset($exitsopening) && $exitsopening->debit > 0 ? $exitsopening->debit : ''; ?>" name="headDebit[]"  placeholder="0.00"/></td>
                                        <td><input style="text-align: right" type="text"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  class="form-control credit" value="<?php echo isset($exitsopening) && $exitsopening->credit > 0 ? $exitsopening->credit : ''; ?>" name="headCredit[]"  placeholder="0.00"/></td>
                                        </tr>
                                        <?php
                                    endforeach;
                                endforeach;
                                $returnEarnig = $this->Common_model->get_single_data_by_single_column('retainearning', 'dist_id', $this->dist_id);
                                ?>
                                <tr>
                                    <td><b>&nbsp;Retain earnings</b></td>
                                    <td><input style="text-align: right" type="text"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  class="form-control debit" value="<?php echo isset($returnEarnig) && $returnEarnig->dr > 0 ? $returnEarnig->dr : ''; ?>" name="retainEarningDR"  placeholder="0.00"/></td>
                                    <td><input style="text-align: right" type="text"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"  class="form-control credit" value="<?php echo isset($returnEarnig) && $returnEarnig->cr > 0 ? $returnEarnig->cr : ''; ?>" name="retainEarningCR"  placeholder="0.00"/></td>
                                </tr>
                                <!--End parent query--->
                                </tbody> 
                                <tfoot>
                                    <tr>
                                        <td align="right"><strong>Total Balance (In BDT.)</strong></td>
                                        <td align="right"><strong> <span class="ttl_dr_del"><?php echo number_format((float) $total_debit, 2, '.', ''); ?></span><span class="ttl_dr"></span></strong></td>
                                        <td align="right"><strong> <span class="ttl_cr_del"><?php echo number_format((float) $total_credit, 2, '.', ''); ?></span><span class="ttl_cr"></span></strong></td>
                                    </tr>
                                </tfoot> 
                            </table> 
                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-5 col-md-7">
                                    <?php if (empty($total_debit)): ?>

                                        <button  id="btnDisabled" onclick="return isconfirm()" id="subBtn" class="btn btn-info" type="submit">
                                            <i class="ace-icon fa fa-check bigger-110"></i>
                                            Save
                                        </button>

                                    <?php else: ?>
                                        <button  id="" disabled  id="subBtn" class="btn btn-info" type="button">
                                            <i class="ace-icon fa fa-check bigger-110"></i>
                                            Save
                                        </button>
                                    <?php endif; ?>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script type="text/javascript">
    $(document).ready(function(){                         
        $('.debit').change(function(){ 
            $('.ttl_dr_del').remove();
            ttl_dr=0; 
            $.each($('.debit'), function(){
                dr = $(this).val();
                dr = Number(dr);
                ttl_dr += dr;
            }); 
            $(this).val(parseFloat($(this).val()).toFixed(2));
            $('.ttl_dr').html(parseFloat(ttl_dr).toFixed(2)); 
        });     
        $('.credit').change(function(){
            $('.ttl_cr_del').remove();
            ttl_cr=0;
            $.each($('.credit'), function(){
                cr = $(this).val();
                cr = Number(cr);
                ttl_cr += cr;
            });
            $(this).val(parseFloat($(this).val()).toFixed(2));
            $('.ttl_cr').html(parseFloat(ttl_cr).toFixed(2));
        });
    }); 
</script>







