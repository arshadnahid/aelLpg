<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Customer Opening</a>
                </li>
                <l
                    <li class="active">Customer Opening List</li>
            </ul>
            <?php if (empty($allBalance)): ?>

                <span style="padding-top: 5px!important;">
                    <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('customerOpneingAdd'); ?>" class="btn btn-success pull-right">
                        <i class="ace-icon fa fa-plus"></i>
                        Add New
                    </a>
                </span>
            <?php endif; ?>

        </div>
        <div class="page-content">
            <div class="row">
                <div class="table-header">
                    Customer Opening List
                </div>
                <div>
                    <table id="example" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Customer Name</th>
                                <th>Receivable</th>
                                <!--<th>Credit</th>-->

                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $totalReceive = 0;
                            foreach ($allBalance as $key => $value):
                                $totalReceive+=$value->dr;
                                $CustomerName = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $value->client_vendor_id);
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $CustomerName->customerName . '[' . $CustomerName->customerID . ']'; ?></td>
                                    <td><?php echo $value->dr; ?></td>
                                    <!--<td><?php echo $value->cr; ?></td>-->


                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                        <td colspan="2" align="right"><strong>Total Receivable</strong></td>
                        <td><?php echo number_format($totalReceive); ?></td>
                        </tfoot>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div><script src="<?php echo base_url('assets/setup.js'); ?>"></script>
