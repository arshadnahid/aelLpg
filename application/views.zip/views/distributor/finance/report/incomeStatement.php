<?php
if (isset($_POST['start_date'])):
    $account = $this->input->post('accountHead');
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
//echo $account;die;
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Finance</a>
                </li>
                <li class="active">Income Statement</li>
            </ul>
            <span style="padding-top: 5px!important;">
                <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('DistributorDashboard'); ?>" class="btn btn-danger pull-right">
                    <i class="ace-icon fa fa-times "></i>
                    Cancel
                </a>
            </span>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-10 col-sm-offset-1">
                            <div class="table-header">
                                Income Statement
                            </div>
                            <br>
                            <div style="background-color: grey!important;">

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker form-control" id="start_date" name="start_date" value="<?php
if (!empty($from_date)) {
    echo $from_date;
} else {


    echo date('Y-m-d');
}
?>" data-date-format='yyyy-mm-dd' placeholder="Start Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker form-control" id="end_date" name="end_date" value="<?php
                                                   if (!empty($to_date)):
                                                       echo $to_date;
                                                   else:
                                                       echo date('Y-m-d');
                                                   endif;
?>" data-date-format='yyyy-mm-dd' placeholder="End Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-2"></div>
                                        <div class="col-sm-5">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-5">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date']) && isset($_POST['end_date'])):
                //  dumpVar($_POST);

                $from_date = $this->input->post('start_date');
                $to_date = $this->input->post('end_date');
                $account = $this->input->post('accountHead');
                $dist_id = $this->dist_id;

                unset($_SESSION["account"]);
                unset($_SESSION["start_date"]);
                unset($_SESSION["end_date"]);


                $_SESSION["account"] = $account;
                $_SESSION["start_date"] = $from_date;
                $_SESSION["end_date"] = $to_date;
                $dist_id = $this->dist_id;

                $total_pvsdebit = '';
                $total_pvscredit = '';

                $total_debit = '';
                $total_credit = '';
                $total_balance = '';
                ?>
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1">
                        <div class="table-header">
                            Income Statement (Profit & Loss) <span style="color:yellowgreen">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>

                        </div>
                        <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url('FinaneController/incomeStatement_export_excel/') ?>" class="btn btn-success pull-right">
                            <i class="ace-icon fa fa-download"></i>
                            Excel 
                        </a>
                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <p><?php echo $companyInfo->dist_address; ?>
                                    </p>
                                    <strong>Phone : </strong><?php echo $companyInfo->dist_phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->dist_email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->dis_website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td align="center"><strong>Particulars</strong></td>
                                    <td align="center"><strong>Total Balance (In BDT.)</strong></td>
                                </tr>
                            </thead>
                            <tbody>                   
                                <!-- Code: 9000 (chart_type_id: 37) --> 
                                <tr>
                                    <td colspan="2" align="left"><strong>Sales ( A )</strong></td>
                                </tr>
                                <tr class="item-row">
                                    <td style="padding-left:30px;"><a href="<?php echo site_url('generalLedger/' . 49); ?>">Sales Revenue</a></td> 
                                    <!-- chart_master --> 
                                    <?php
                                    $total_opendebit = $this->Finane_Model->opening_balance_dr($this->dist_id, 49);
                                    $total_opencredit = $this->Finane_Model->opening_balance_cr($this->dist_id, 49);
                                    $openingBalance11 = $total_opencredit - $total_opendebit;
                                    $totalVat = 0;
                                    $totalsale = 0;
                                    $this->db->select('sum(generals.debit) as totalProductSales,sum(generals.vatAmount) as totalVat');
                                    $this->db->from('generals');
                                    $this->db->where('generals.form_id', '5');
                                    $this->db->where('generals.date >=', $from_date);
                                    $this->db->where('generals.date <=', $to_date);
                                    $this->db->where('generals.dist_id', $this->dist_id);
                                    $ttProductSale = $this->db->get()->row_array();
                                    $saleWithoutVat = $ttProductSale['totalProductSales'] - $ttProductSale['totalVat'];
                                    $totalVat += $ttProductSale['totalVat'];
                                    $totalsale += $saleWithoutVat + $openingBalance11;
                                    ?>                   
                                    <!-- /chart_master --> 
                                    <td align="right"><?php echo number_format((float) $saleWithoutVat + $openingBalance11, 2, '.', ','); ?></td>                                  
                                </tr> 
                                <tr>
                                    <td colspan="2" align="left"><strong>Less Cost of goods sold ( B )</strong></td>
                                </tr>

                                <?php
                                $twoa = 1;
                                $costofGoodsProduct = 0;
                                foreach ($expense as $row_cta):
                                    ?>                         
                                    <!-- chart_master --> 
                                    <?php
                                    foreach ($row_cta['Accountledger'] as $row_cma):
                                        //deduct only product purchases price
                                        if ($row_cma->parentId == 61):
                                            ?>                       
                                            <tr>

                                                <!-- PVS Balance -->
                                                <?php
                                                // Opening Balance
//                                                $total_opendebit = $this->Finane_Model->opening_balance_dr($this->dist_id, $row_cma->chartId);
//                                                $total_opencredit = $this->Finane_Model->opening_balance_cr($this->dist_id, $row_cma->chartId);
//
                                                $total_pvsdebit = '';
                                          $total_pvscredit = '';
//                                                $this->db->where('dist_id', $this->dist_id);
//                                                $this->db->where('account', $row_cma->chartId);
//                                                $this->db->where('date <', $from_date);
//                                                $query_pvs = $this->db->get('generalledger')->result_array();
//                                                foreach ($query_pvs as $row_pvs):
//                                                    $total_pvsdebit += $row_pvs['debit'];
//                                                    $total_pvscredit += $row_pvs['credit'];
//                                                endforeach;
//                                                $total_pvsdebit += $total_opendebit;
//                                                $total_pvscredit += $total_opencredit;
                                                ?>     

                                                <?php
                                                $total_debit = '';
                                                $total_credit = '';
                                                $this->db->select("*");
                                                $this->db->from("generalledger");
                                                $this->db->where('dist_id', $this->dist_id);
                                                $this->db->where('account', $row_cma->chartId);
                                                $this->db->where('date >=', $from_date);
                                                $this->db->where('date <=', $to_date);
                                                $query = $this->db->get()->result_array();
                                                foreach ($query as $row):
                                                    $total_debit += $row['debit'];
                                                    $total_credit += $row['credit'];
                                                endforeach;
                                                ?> 

                                                <?php
                                                $total_pvsdebit += $total_debit;
                                                $total_pvscredit += $total_credit;
                                                $amount = $total_pvsdebit - $total_pvscredit;
                                                if (!empty($amount)) {
                                                    ?>

                                                    <td><a href="<?php echo site_url('generalLedger/' . $row_cma->chartId); ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row_cma->title; ?></a></td> 
                                                    <td align="right"><?php
                                echo number_format($total_pvsdebit - $total_pvscredit);
                                $costofGoodsProduct+=$total_pvsdebit - $total_pvscredit;
                                                    ?>
                                                    </td> 
                                                <?php } ?>
                                                <!-- /This Period -->  
                                            </tr>
                                            <?php
                                        endif;
                                    endforeach;
                                    ?>                     
                                    <!-- /chart_master --> 
                                    <?php
                                endforeach;
                                ?>
                                <tr>
                                    <td align="left"><strong>Sub-Total</strong></td>
                                    <td align="right"><?php echo number_format($costofGoodsProduct); ?></td>
                                </tr>
                                <?php
                                $grossProfit = $totalsale - $costofGoodsProduct;
                                ?>
                                <tr>
                                    <td  align="right"><strong> Gross Profit / (Loss) ( C = A - B )</strong></td>
                                    <td  align="right"><strong><?php echo number_format((float) $grossProfit, 2, '.', ','); ?></strong></td>
                                </tr>
                                <tr>
                                    <td  align="left"  colspan="2"><strong> Administrative Cost ( D )</strong></td>
                                </tr>

                                <?php
                                $twoa = 1;
                                $grossExpense = 0;
                                foreach ($expense as $row_cta):
                                    foreach ($row_cta['Accountledger'] as $row_cma):
                                        ?>                         
                                        <tr>
                                            <?php
                                            if ($row_cma->parentId != 61):
                                                ?>

                                                <!-- PVS Balance -->
                                                <?php
                                                // Opening Balance
//                                                $total_opendebit = $this->Finane_Model->opening_balance_dr($this->dist_id, $row_cma->chartId);
//                                                $total_opencredit = $this->Finane_Model->opening_balance_cr($this->dist_id, $row_cma->chartId);
//
                                                $total_pvsdebit = '';
                                                $total_pvscredit = '';
//                                                $this->db->where('dist_id', $this->dist_id);
//                                                $this->db->where('account', $row_cma->chartId);
//                                                //$this->db->where('account', 140);
//                                                $this->db->where('date <', $from_date);
//                                                $query_pvs = $this->db->get('generalledger')->result_array();
//                                                foreach ($query_pvs as $row_pvs):
//                                                    $total_pvsdebit += $row_pvs['debit'];
//                                                    $total_pvscredit += $row_pvs['credit'];
//                                                endforeach;
//                                                $total_pvsdebit += $total_opendebit;
//                                                $total_pvscredit += $total_opencredit;

                                                $total_debit = '';
                                                $total_credit = '';

                                                $this->db->where('dist_id', $this->dist_id);
                                                $this->db->where('account', $row_cma->chartId);
                                                $this->db->where('date >=', $from_date);
                                                $this->db->where('date <=', $to_date);
                                                $query = $this->db->get('generalledger')->result_array();
                                                foreach ($query as $row):
                                                    $total_debit += $row['debit'];
                                                    $total_credit += $row['credit'];
                                                endforeach;


                                                $total_pvsdebit += $total_debit;
                                                $total_pvscredit += $total_credit;
                                                $amount = $total_pvsdebit - $total_pvscredit;
                                                if (!empty($amount)):
                                                    ?>
                                                    <td><a href="<?php echo site_url('generalLedger/' . $row_cma->chartId); ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row_cma->title; ?></a></td>                                 

                                                    <td align="right"><?php
                                echo number_format($total_pvsdebit - $total_pvscredit);
                                                    ?>
                                                    </td> 
                                                    <!-- /This Period -->  
                                                </tr>
                                                <?php
                                            endif;
                                            $grossExpense+=$total_pvsdebit - $total_pvscredit;
                                        endif;
                                    endforeach;
                                    ?>                     
                                    <!-- /chart_master --> 
                                    <?php
                                endforeach;
                                ?>
                                <tr class = "item-row">
                                    <td align="left">
                                        <strong> Sub-Total</strong>
                                    </td>
                                    <!--chart_master-->
                                    <!-- /chart_master -->                        
                                    <td align="right"><?php echo number_format((float) $grossExpense, 2, '.', ','); ?></td> 
                                </tr>
                                <tr class="item-row"> 
                                    <td align="right">
                                        <strong>
                                            Operating Profit / (Loss) ( C - D )
                                        </strong>
                                    </td>
                                    <td align="right"><strong><?php echo number_format((float) $grossProfit - $grossExpense, 2, '.', ','); ?></strong></td> 
                                </tr>
                                <tr class="item-row"> 
                                    <td align="right">
                                        <strong>
                                            Total forwarded to balance sheet
                                        </strong>
                                    </td>
                                    <td align="right"><strong><?php echo number_format((float) $grossProfit - $grossExpense, 2, '.', ','); ?></strong></td> 

                                </tr>


                            </tbody>    
                        </table> 
                    </div>
                </div>
            <?php else:
                ?>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>









