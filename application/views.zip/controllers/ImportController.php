<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ImportController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;

    public function __construct() {
        parent::__construct();
        //$this->load->model('Common_model', 'Finane_Model', 'Inventory_Model', 'Sales_Model');
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');
    }

    public function setupImport() {
        if (isPostBack()) {

            if (!empty($_FILES['supplierImport']['name']))://supplier list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('supplierImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['supplierImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'supID' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('supplier', $condition);
                        if (empty($exitsID)):
                            $data['supID'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        else:
                            $supID = $this->Common_model->getSupplierID($this->dist_id);
                            $data['supID'] = $this->Common_model->checkDuplicateSupID($supID, $this->dist_id);
                        endif;
                        /* check duplicate supplier id end */
                        $data['supName'] = isset($readRowData[1]) ? $readRowData[1] : '';
                        $data['supEmail'] = isset($readRowData[2]) ? $readRowData[2] : '';
                        $data['supPhone'] = isset($readRowData[3]) ? $readRowData[3] : '';
                        $data['supAddress'] = isset($readRowData[4]) ? $readRowData[4] : '';
                        $data['dist_id'] = $this->dist_id;
                        $data['updated_by'] = $this->admin_id;
                        if (!empty($data['supID']) && !empty($data['supName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('supplier', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;



            elseif (!empty($_FILES['customerImport']['name']))://supplier list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('customerImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['customerImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'customer_id' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('customer', $condition);
                        if (empty($exitsID)):
                            $data['customer_id'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        else:
                            $supID = $this->Common_model->getCustomerID($this->dist_id);
                            $data['customer_id'] = $this->Common_model->checkDuplicateCstID($supID, $this->dist_id);
                        endif;
                        /* check duplicate supplier id end */
                        $data['customerID'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        $data['customerName'] = isset($readRowData[1]) ? $readRowData[1] : '';
                        $data['customerPhone'] = isset($readRowData[2]) ? $readRowData[2] : '';
                        $data['customerEmail'] = isset($readRowData[3]) ? $readRowData[3] : '';
                        $data['customerAddress'] = isset($readRowData[4]) ? $readRowData[4] : '';

                        $data['dist_id'] = $this->dist_id;
                        $data['updated_by'] = $this->admin_id;
                        if (!empty($data['customerName']) && !empty($data['customerID'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('customer', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;



            elseif (!empty($_FILES['proCatImport']['name']))://product cat list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('proCatImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['proCatImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    //dumpVar($readRowData);
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */

                        $condition = array(
                            'title' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('productcategory', $condition);
                        if (empty($exitsID)):
                            $data['title'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            $data['dist_id'] = $this->dist_id;
                            $data['updated_by'] = $this->admin_id;
                        endif;

                        /* check duplicate supplier id end */

                        if (!empty($data['title'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('productcategory', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;


            elseif (!empty($_FILES['proImport']['name']))://product list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('proImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['proImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'product_code' => $readRowData[3],
                            'dist_id' => $this->dist_id
                        );


                        $exitsID = $this->Common_model->get_single_data_by_many_columns('product', $condition);

                        if (empty($exitsID)):
                            $data['product_code'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        else:
                            $proID = $this->Common_model->getProID($this->dist_id);
                            $data['product_code'] = $this->Common_model->checkDuplicateProID($proID, $this->dist_id);
                        endif;
                        /* check duplicate supplier id end */
                        $data['brand_id'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        $data['category_id'] = isset($readRowData[1]) ? $readRowData[1] : '';
                        $data['productName'] = isset($readRowData[2]) ? $readRowData[2] : '';
                        $data['product_code'] = isset($readRowData[3]) ? $readRowData[3] : '';
                        $data['purchases_price'] = isset($readRowData[4]) ? $readRowData[4] : '';
                        $data['salesPrice'] = isset($readRowData[5]) ? $readRowData[5] : '';
                        $data['retailPrice'] = isset($readRowData[6]) ? $readRowData[6] : '';
                        $data['dist_id'] = $this->dist_id;
                        $data['updated_by'] = $this->admin_id;

                        if (!empty($data['product_code']) && !empty($data['productName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('product', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;


            elseif (!empty($_FILES['BrandImport']['name']))://product cat list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('BrandImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['BrandImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    //dumpVar($readRowData);
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */

                        $condition = array(
                            'brandName' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('brand', $condition);
                        if (empty($exitsID)):
                            $data['brandName'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            $data['dist_id'] = $this->dist_id;
                            $data['updated_by'] = $this->admin_id;
                        endif;

                        /* check duplicate supplier id end */

                        if (!empty($data['brandName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('brand', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;

            elseif (!empty($_FILES['UnitImport']['name']))://product cat list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('UnitImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['UnitImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    //dumpVar($readRowData);
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */

                        $condition = array(
                            'unitTtile' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('unit', $condition);
                        if (empty($exitsID)):
                            $data['unitTtile'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            $data['dist_id'] = $this->dist_id;
                            $data['updated_by'] = $this->admin_id;
                        endif;

                        /* check duplicate supplier id end */

                        if (!empty($data['unitTtile'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('unit', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;





            elseif (!empty($_FILES['referenceImport']['name']))://supplier list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('referenceImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['referenceImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'referencePhone' => $readRowData[1],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('reference', $condition);
                        if (empty($exitsID)):
                            $data['referenceName'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            /* check duplicate supplier id end */
                            $data['referencePhone'] = isset($readRowData[1]) ? $readRowData[1] : '';
                            $data['referenceEmail'] = isset($readRowData[2]) ? $readRowData[2] : '';
                            $data['referenceAddress'] = isset($readRowData[3]) ? $readRowData[3] : '';
                          
                            $data['dist_id'] = $this->dist_id;
                            $data['updated_by'] = $this->admin_id;
                        endif;

                        if (!empty($data['referenceName']) && !empty($data['referencePhone'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('reference', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('setupImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('setupImport'));
                endif;




            endif;
        }
        $data['title'] = 'Import-Setup';
        $data['mainContent'] = $this->load->view('distributor/inventory/import/setup', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function upload_data($param1 = '') {
        if ($param1 == 'do_upload') {
            $config['upload_path'] = './uploads/attendance_file/';
            $config['allowed_types'] = 'xl|txt|csv|mdb';
            $config['file_name'] = date("Y-m-d");
            $this->load->library('upload');
            $this->upload->initialize($config);
            $upload = $this->upload->do_upload('attendance_file');
            $data = $this->upload->data();
            $this->load->helper('file');
            $file = fopen($data['full_path'], "r");
            $file_date = $data['client_name'];
            $file_date = substr($file_date, 3, 8);
            $line = FALSE;
            $att_data = array();
            $file = $_FILES['attendance_file']['tmp_name'];
            $handle = fopen($file, "r");
            $c = 0;
            while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {
//                
//                echo "<pre>";
//                print_r($filesop);


                $count_value = count($filesop);
                if ($count_value == '42') {
                    $punch_card = str_replace("'", "", trim($filesop[25]));
                    $date = substr($filesop[37], 1, 10);
                    $time = str_replace("'", "", substr($filesop[22], 0, 6));
                    //$time = date('h:m', strtotime($time2));
//                    echo $time;
//                    echo "<br>";
                    if ($time and $punch_card) {
                        $att_data[] = array('date' => $date, 'time' => $time, 'punch_card' => $punch_card);
                    }
                }
            }


            $this->db->where('date', $date);
            $already_exit = $this->db->get('punch_info2')->row_array();


//            
//          die;
//            echo "<pre>";
//            print_r($att_data);
//            die;

            if (empty($already_exit)) {
                $this->db->insert_batch('punch_info2', $att_data);
            }
            //$this->session->set_flashdata('success', 'File uploaded.');
            $query = $this->db->get('punch_info2');
            $all_punch_info = $query->result_array();
            if (!empty($all_punch_info)) {
                foreach ($all_punch_info as $each_punch_info):
                    $this->db->select_min('time');
                    $this->db->where('date', $each_punch_info['date']);
                    $this->db->where('punch_card', $each_punch_info['punch_card	']);
                    $intime = $this->db->get('punch_info')->row_array();
                    $this->db->select_max('time');
                    $this->db->where('date', $each_punch_info['date']);
                    $this->db->where('punch_card', $each_punch_info['punch_card	']);
                    $outtime = $this->db->get('punch_info')->row_array();
                    $date2 = $date = $each_punch_info['date'];
                    $punch_card2 = $each_punch_info['punch_card	'];
                    $intime2 = $intime['time'];
                    $outtime2 = $outtime['time'];
                    $query = $this->db->get_where('punch_info', array('punch_card' => $each_punch_info['punch_card'], 'date' => $each_punch_info['date']));
                    $already_insert = $query->result_array();

                    if (empty($already_insert)) {
                        if ($intime2 and $punch_card)
                            $att_data[] = array('date' => $date2, 'time' => $intime2, 'punch_card' => $punch_card2);
                        if ($outtime2 and $punch_card)
                            $att_data[] = array('date' => $date2, 'time' => $outtime2, 'punch_card' => $punch_card2);
                        $this->db->insert_batch('punch_info', $att_data);
                    }
                endforeach;
            }

            $this->session->set_flashdata('success', 'File uploaded.');
        }
        $this->defaults['page_title'] = translate('upload_data');
        $this->defaults['page_name'] = 'upload_data';
        $this->load->view('index', $this->defaults);
    }



}
