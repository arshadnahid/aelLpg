<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SetupController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    private $dist_id;

    public function __construct() {
        parent::__construct();

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');

        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');

        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url());
        }
    }

//     public function decision_tools() {
//       
//    }



    function userMessageList() {
        $this->db->select("*");
        $this->db->from("messageuser");
        $this->db->join("message", "message.msgId=messageuser.msgid");
        $this->db->where('messageuser.userid', $this->dist_id);
        $this->db->order_by('message.msgId', 'DESC');
        $data['allMessage'] = $this->db->get()->result();

        $data['title'] = 'Message List';
        $data['mainContent'] = $this->load->view('distributor/message/messageList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function userAllOfferList() {
        $this->db->select("*");
        $this->db->from("offer");
        $this->db->order_by('offerId', 'DESC');
        $data['allOffer'] = $this->db->get()->result();
        $data['title'] = 'Offer List';
        $data['mainContent'] = $this->load->view('distributor/offer/offerList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function newDecision() {

        if (isPostBack()) {
            $insertId = $this->Common_model->insert_data('newDecision', $_POST);
            if (!empty($insertId)) {
                message("Your data successfully inserted into database.");
                redirect(site_url('newDecisionList'));
            }
        }


        $data = array();
        $data['title'] = 'Decision Tools';
        $dist_id = $this->session->userdata('dist_id');
        $data['login'] = $this->session->userdata('login');

        $data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        $data['mainContent'] = $this->load->view('distributor/setup/decision/newDecision', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function newDecisionList() {
        $data['newDecisionList'] = $this->Common_model->get_data_list('newDecision', 'percentage', 'DESC');
        $data['title'] = 'Decision Compare';
        $data['mainContent'] = $this->load->view('distributor/setup/decision/newDecisionList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function password($dist_id) {
        $data = array();
        $data['title'] = 'Change Password';
        $data['dist_id'] = $this->dist_id;
        $data['login'] = $this->session->userdata('login');
        $data['dist_name'] = $this->session->userdata('dist_name');
        //$dist_id = $this->session->userdata('dist_id');
        $data['dist_info'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/profile/chng_pass', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function change_password() {
        $data = array();
        $dist_id = $this->input->post('dist_id', true);
        $admin_password1 = md5($this->input->post('admin_password1'));
        $admin_password2 = md5($this->input->post('admin_password2'));
        if ($admin_password1 != $admin_password2) {
            exception("Given password does't match with confirm password.");
            redirect('password/' . $dist_id);
        } else {
            $data['dist_password'] = md5($this->input->post('admin_password1'));
            $this->Common_model->update_data('tbl_distributor', $data, 'dist_id', $this->dist_id);
            message("Password successfully change.");
            redirect('distributor_profile');
        }
    }

    public function distributor_profile() {
        $data = array();
        $data['title'] = 'Profile';
        $data['dist_id'] = $this->dist_id;
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['login'] = $this->session->userdata('login');
        $dist_id = $this->dist_id;
        $data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['dist_info'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/profile/dist_profile', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function decision_tools() {
        $data = array();
        $data['title'] = 'Decision Tools';
        $dist_id = $this->session->userdata('dist_id');
        $data['login'] = $this->session->userdata('login');

        $data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        $data['mainContent'] = $this->load->view('distributor/setup/decision/decision_form', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    //new
    public function save_decision_tools() {

        $data['dec_title'] = $this->input->post('dec_title', TRUE);
        $data['asset_amount'] = $this->input->post('asset_amount', TRUE);
        $data['invest_type'] = $this->input->post('invest_type', TRUE);
        $data['note'] = $this->input->post('note', TRUE);
        $data['dist_id'] = $this->dist_id;
        $data['bank_saving_type'] = $this->input->post('bank_saving_type', TRUE);
        $data['amount_of_saving'] = $this->input->post('amount_of_saving', TRUE);
        $data['period_time'] = $this->input->post('period_time', TRUE);
        $data['interest_per_month'] = $this->input->post('interest_per_month', TRUE);
        $data['per_month_interest_amount'] = $this->input->post('per_month_interest_amount', TRUE);
        $data['company_name'] = $this->input->post('company_name', TRUE);
        $data['invest_amount'] = $this->input->post('invest_amount', TRUE);
        $data['per_month_profit_amount'] = $this->input->post('per_month_profit_amount', TRUE);
        $data['return_of_invest_time'] = $this->input->post('return_of_invest_time', TRUE);
        $this->Common_model->insert_data('tbl_decision', $data);
        redirect(site_url('compare_decision'));
    }

    //new
    public function compare_decision() {
        $data = array();
        $data['title'] = 'Compare Decision';
        $dist_id = $this->dist_id;
        $data['login'] = $this->session->userdata('login');



        $data['offer_info'] = $this->Common_model->compare_decision_info($this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        $data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);

        $data['mainContent'] = $this->load->view('distributor/setup/decision/compare_decision', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function SystemConfig() {
        if (isPostBack()) {
            $data['dist_name'] = $this->input->post('dist_name');
            $data['dist_phone'] = $this->input->post('dist_phone');
            $data['dist_email'] = $this->input->post('dist_email');
            $data['dist_address'] = $this->input->post('dist_address');
            $data['dis_website'] = $this->input->post('dis_website');
            $data['VAT'] = $this->input->post('VAT');
            if (!empty($this->input->post('image')[0])):
                $data['dist_picture'] = $this->input->post('image')[0];
            endif;
            $data['updated_at'] = $this->timestamp;
            $data['updated_by'] = $this->admin_id;
            $inserted_id = $this->Common_model->update_data('tbl_distributor', $data, 'dist_id', $this->dist_id);
            message("Your System Configuration successfully updated into database.");
            redirect(site_url('SystemConfig'));
        }
        $data['title'] = 'System || Config';
        $data['configInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/systemConfg', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function getAllMessage() {

        $this->db->select("*");
        $this->db->from("messageuser");
        $this->db->join("message", "message.msgId=messageuser.msgid");
        $this->db->where("messageuser.userid", $this->dist_id);
        $data['allMessage'] = $this->db->get()->result();
        // echo $this->db->last_query();die;
        $data['title'] = 'All Message';
        $data['mainContent'] = $this->load->view('distributor/message/messageList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function saveNewSupplier() {
        $data['supID'] = $this->input->post('supplierId');
        $data['supName'] = $this->input->post('supName');
        $data['supEmail'] = $this->input->post('supEmail');
        $data['supPhone'] = $this->input->post('supPhone');
        $data['supAddress'] = $this->input->post('supAddress');
        $data['dist_id'] = $this->dist_id;
        $data['updated_by'] = $this->admin_id;
        $insertID = $this->Common_model->insert_data('supplier', $data);
        if (!empty($insertID)):
            echo '<option value="' . $insertID . '" selected="selected">' . $data['supID'] . ' [ ' . $data['supName'] . ' ] ' . '</option>';

        endif;
    }

    function userStatusChange() {
        $userId = $this->input->post('userId');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('admin', $data, 'admin_id', $userId);
        message("User Status successfully change");
        echo 1;
    }

    function userList() {

        $data['title'] = 'User List';
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/userList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function addUser() {
        if (isPostBack()) {

            $data['name'] = $this->input->post('name');
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $data['password'] = md5($this->input->post('password'));
            $data['distributor_id'] = $this->dist_id;
            $data['accessType'] = 2;
            $data['type'] = 'Master';
            $data['status'] = '1';
            $data['updated_by'] = $this->admin_id;
            $insertId = $this->Common_model->insert_data('admin', $data);
            if (!empty($insertId)) {
                message("New User Created successfully.");
                redirect(site_url('userList'));
            }
        }
        $data['title'] = 'User List';
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/addUser', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function editUser($editId) {
        if (isPostBack()) {
            $data['name'] = $this->input->post('name');
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $password = $this->input->post('password');
            if (!empty($password)):
                $data['password'] = md5($this->input->post('password'));
            endif;
            $data['distributor_id'] = $this->dist_id;
            $data['updated_by'] = $this->admin_id;
            $this->Common_model->update_data('admin', $data, 'admin_id', $editId);
            message("User update successfully.");
            redirect(site_url('userList'));
        }
        $data['title'] = 'User List';
        $data['editInfo'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $editId);
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/editUser', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function suplierStatusChange() {
        $supid = $this->input->post('supID');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('supplier', $data, 'sup_id', $supid);
        message("Supplier status successfully Change.");
        return 1;
    }

    function deletedata() {
        $table = $this->input->post('table');
        $column = $this->input->post('column');
        $id = $this->input->post('id');
        $this->Common_model->delete_data($table, $column, $id);
        message("Your data successfully deleted from database.");
        echo 1;
    }

    function checkDuplicateEmail() {
        $phone = $this->input->post('phone');
        if (!empty($phone)):
            $array = array(
                'supPhone' => $phone,
                'dist_id' => $this->dist_id,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('supplier', $array);

            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateBrand() {
        $brandName = $this->input->post('brandName');
        if (!empty($brandName)):
            $duplicateBrandCondition = array(
                'brandName' => $brandName,
                'dist_id' => $this->dist_id,
            );
            $exitsBrandName = $this->Common_model->get_single_data_by_many_columns('brand', $duplicateBrandCondition);

            if (!empty($exitsBrandName)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateUnit() {
        $unitName = $this->input->post('unitName');
        if (!empty($unitName)):
            $exitsUnitName = $this->Common_model->cehckDuplicateUnit($unitName, $this->dist_id);
            if (!empty($exitsUnitName)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateEmailForUser() {



        $email = $this->input->post('email');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateEmailForUserEdit() {



        $email = $this->input->post('email');
        $adminId = $this->input->post('adminId');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
                'admin_id !=' => $adminId,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);

            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function productStatusChange() {
        $product = $this->input->post('productid');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('product', $data, 'product_id', $product);
        message("Product Status successfully change.");
        echo 1;
    }

    function checkDuplicateCategory() {
        $catName = $this->input->post('catName');
        $condition = array(
            'dist_id' => $this->dist_id,
            'title' => $catName
        );
        $exitsData = $this->Common_model->checkPublicProductCat($catName);
        if (!empty($exitsData)) {
            echo 1;
        } else {
            echo 2;
        }
    }

    function checkDuplicateCategoryforUpdate() {
        $catName = $this->input->post('catName');
        $updatedID = $this->input->post('updatedID');
        $condition = array(
            'dist_id' => $this->dist_id,
            'title' => $catName,
            'category_id !=' => $updatedID
        );
        $exitsData = $this->Common_model->get_single_data_by_many_columns('productcategory', $condition);
        if (!empty($exitsData)) {
            echo 1;
        } else {
            echo 2;
        }
    }

}
