<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AuthController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //$this->load->model('Common_model', 'Finane_Model', 'Inventory_Model', 'Sales_Model');
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
    }

    public function index() {
        $thisdis = $this->session->userdata('dis_id');
        $admin_id = $this->session->userdata('admin_id');
        if (!empty($thisdis) || !empty($admin_id)) {
            redirect(site_url('DistributorDashboard'));
        }
        $this->load->view('auth/login');
    }

    public function checkLogin() {
        $data['email'] = $this->input->post('dist_email');
        $data['password'] = md5($this->input->post('dist_password'));
        $data['accessType'] = 2;
        $userInfo = $this->Common_model->get_single_data_by_many_columns('admin', $data);
        if (empty($userInfo)) {
            $this->session->set_flashdata('msg', 'Undefined Username OR Password!');
            redirect(site_url());
        } elseif (!empty($userInfo) && $userInfo->status == 2) {
            $this->session->set_flashdata('msg', 'Your Are inactive Distributor.Please Contact with admin to active your account.');
            redirect(site_url());
        } else {
            $this->session->set_userdata('dis_id', $userInfo->distributor_id);
            $this->session->set_userdata('admin_id', $userInfo->admin_id);
            $this->session->set_userdata('username', $userInfo->name);
            $this->session->set_userdata('type', $userInfo->type);
            $this->session->set_userdata('loginTime', time());
            unset($userInfo);
            redirect(site_url('moduleDashboard'));
        }
    }

    public function signout() {
        $this->session->unset_userdata('dis_id');
        $this->session->unset_userdata('admin_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('type');
        $this->session->unset_userdata('loginTime');
        $this->session->sess_destroy();
        session_destroy();
        redirect(site_url('AuthController'));
    }

    public function signoutHeadoffice() {
        $this->session->unset_userdata('dis_id');
        $this->session->unset_userdata('admin_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('type');
        $this->session->unset_userdata('loginTime');
        $this->session->unset_userdata('headOffice');
        redirect(site_url('adminDashboard'));
    }

}
