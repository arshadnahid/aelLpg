<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminReportController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;

    public function __construct() {
        parent::__construct();

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_admin_id');
        $this->dist_id = $this->session->userdata('admin_dis_id');
         
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url('adminlogin'));
        }
        
    }

    function disPurchasesReport() {
        $data['allDistributor'] = $this->Common_model->get_data_list('tbl_distributor', 'dist_name', 'ASC');
        $data['title'] = 'Purchases Report';
        $data['mainContent'] = $this->load->view('admin/report/purchasesReport', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function disStockReport() {

        $data['categoryList'] = $this->Common_model->get_data_list('productcategory', 'title', 'ASC');
        $data['allDistributor'] = $this->Common_model->get_data_list('tbl_distributor', 'dist_name', 'ASC');
        $data['title'] = 'Stock Report';
        $data['mainContent'] = $this->load->view('admin/report/stockReport', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function disSalesReport() {

        $data['categoryList'] = $this->Common_model->get_data_list('productcategory', 'title', 'ASC');
        $data['allDistributor'] = $this->Common_model->get_data_list('tbl_distributor', 'dist_name', 'ASC');
        $data['title'] = 'Sales Report';
        $data['mainContent'] = $this->load->view('admin/report/salesReport', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function getDistributorAccess() {

        if (isPostBack()) {
            $distributorid = $this->input->post('distributor');
            $condition = array(
                'distributor_id' => $distributorid,
                'type' => 'Super',
                'accessType' => '2',
            );
            $userInfo = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            $this->session->set_userdata('dis_id', $userInfo->distributor_id);
            $this->session->set_userdata('admin_id', $userInfo->admin_id);
            $this->session->set_userdata('username', $userInfo->name);
            $this->session->set_userdata('type', $userInfo->type);
            $this->session->set_userdata('loginTime', time());
            $this->session->set_userdata('headOffice', 222);
            unset($userInfo);
            message("Your are successfully get Distributor access!!");
            redirect(site_url('DistributorDashboard'));
        }

        $data['allDistributor'] = $this->Common_model->get_data_list('tbl_distributor', 'dist_name', 'ASC');
        $data['title'] = 'Get Distributor Access';
        $data['mainContent'] = $this->load->view('admin/getAccess', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function disSalesReportView($salesId) {

        $data['title'] = 'Distributor Sales View';
        $data['saleslist'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $salesId);
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['customerInfo'] = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $data['saleslist']->customer_id);
        $data['stockList'] = $this->Common_model->get_data_list_by_single_column('stock', 'generals_id', $salesId);
        $data['mainContent'] = $this->load->view('admin/report/salesView', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminViewPurchases($purchases_id = NULL) {
        $data['title'] = 'Purchases View';
        $data['purchasesList'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $purchases_id);
        $data['stockList'] = $this->Common_model->get_data_list_by_single_column('stock', 'generals_id', $purchases_id);

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['supplierInfo'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $data['purchasesList']->supplier_id);
        $data['mainContent'] = $this->load->view('admin/report/purchasesView', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

}
