<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminAuthController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //$this->load->model('Common_model', 'Finane_Model', 'Inventory_Model', 'Sales_Model');
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_admin_id');
        $this->dist_id = $this->session->userdata('admin_dis_id');
//        if (!empty($this->admin_id) && !empty($this->dist_id)) {
//            redirect(site_url('adminDashboard'));
//        }
        
        
    }

    public function index() {

        if (isPostBack()) {

            
            //dumpVar($_POST);
            
            $data['email'] = $this->input->post('admin_email');
            $data['password'] = md5($this->input->post('admin_password'));
            $data['accessType'] = 1;
            $userInfo = $this->Common_model->get_single_data_by_many_columns('admin', $data);
           // echo $this->db->last_query();die;
           
            
//echo $this->db->last_query();die;
            // dumpVar(json_encode($userInfo));
            if (empty($userInfo)) {
                
               
                
                $this->session->set_flashdata('message', 'Undefined Username OR Password!');
                redirect(site_url('adminlogin'));
            } elseif (!empty($userInfo) && $userInfo->status == 2) {
                
                $this->session->set_flashdata('message', 'Your Are inactive Distributor.Please Contact with admin to active your account.');
                redirect(site_url('adminlogin'));
            } elseif (!empty($userInfo) && $userInfo->accessType != 1) {
              
                $this->session->set_flashdata('message', 'Access permition not allowed!');
                redirect(site_url('adminlogin'));
            } else {
               
                $this->session->set_userdata('admin_dis_id', $userInfo->distributor_id);
                $this->session->set_userdata('admin_admin_id', $userInfo->admin_id);
                $this->session->set_userdata('admin_username', $userInfo->name);
                $this->session->set_userdata('admin_type', $userInfo->type);
                $this->session->set_userdata('admin_loginTime', time());
                unset($userInfo);
                redirect(site_url('adminDashboard'));
            }
        }



        $thisdis = $this->session->userdata('dis_id');
        $admin_id = $this->session->userdata('admin_id');
        if (!empty($thisdis) || !empty($admin_id)) {
            redirect(site_url('DistributorDashboard'));
        }
        $this->load->view('admin/auth/login');
    }

    public function adminSignout() {
        
        
        
        $this->session->unset_userdata('admin_dis_id');
        $this->session->unset_userdata('admin_admin_id');
        $this->session->unset_userdata('admin_username');
        $this->session->unset_userdata('admin_type');
        $this->session->unset_userdata('admin_loginTime');
        $this->session->sess_destroy();
        session_destroy();
        redirect(site_url('adminlogin'));
    }

}
