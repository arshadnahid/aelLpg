<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminDashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //$this->load->model('Common_model', 'Finane_Model', 'Inventory_Model', 'Sales_Model');
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');

        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_admin_id');
        $this->dist_id = $this->session->userdata('admin_dis_id');
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url('adminlogin'));
        }
    }

    function adminDashboard() {
        $data['totalDistri']=$this->Common_model->count_all_data('tbl_distributor');
      
        $data['totalMessage']=$this->Common_model->count_all_data('message');
        $data['totalOffer']=$this->Common_model->count_all_data('offer');
        $data['title'] = 'Admin Dashboard';
        $data['mainContent'] = $this->load->view('admin/adminDashboard', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

}
