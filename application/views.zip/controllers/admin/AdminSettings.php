<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminSettings extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;

    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_admin_id');
        $this->dist_id = $this->session->userdata('admin_dis_id');
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url('adminlogin'));
        }
    }

    function adminProductImport() {

        if (isPostBack()) {

            if (!empty($_FILES['supplierImport']['name']))://supplier list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('supplierImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['supplierImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'supID' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('supplier', $condition);
                        if (empty($exitsID)):
                            $data['supID'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        else:
                            $supID = $this->Common_model->getSupplierID($this->dist_id);
                            $data['supID'] = $this->Common_model->checkDuplicateSupID($supID, $this->dist_id);
                        endif;
                        /* check duplicate supplier id end */
                        $data['supName'] = isset($readRowData[1]) ? $readRowData[1] : '';
                        $data['supEmail'] = isset($readRowData[2]) ? $readRowData[2] : '';
                        $data['supPhone'] = isset($readRowData[3]) ? $readRowData[3] : '';
                        $data['supAddress'] = isset($readRowData[4]) ? $readRowData[4] : '';
                        $data['dist_id'] = 1;
                        $data['updated_by'] = $this->admin_id;
                        if (!empty($data['supID']) && !empty($data['supName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('supplier', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('adminProductImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('adminProductImport'));
                endif;



            elseif (!empty($_FILES['proCatImport']['name']))://product cat list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('proCatImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['proCatImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    //dumpVar($readRowData);
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'title' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('productcategory', $condition);
                        if (empty($exitsID)):
                            $data['title'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            $data['dist_id'] = 1;
                            $data['updated_by'] = $this->admin_id;
                        endif;
                        /* check duplicate supplier id end */
                        if (!empty($data['title'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('productcategory', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('adminProductImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('adminProductImport'));
                endif;
            elseif (!empty($_FILES['proImport']['name']))://product list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('proImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['proImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'product_code' => $readRowData[3],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('product', $condition);
                        if (empty($exitsID)):
                            $data['product_code'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        else:
                            $proID = $this->Common_model->getProID($this->dist_id);

                            $data['product_code'] = $this->Common_model->checkDuplicateProID($proID, $this->dist_id);
                        endif;
                        /* check duplicate supplier id end */
                        $data['brand_id'] = isset($readRowData[0]) ? $readRowData[0] : '';
                        $data['category_id'] = isset($readRowData[1]) ? $readRowData[1] : '';
                        $data['productName'] = isset($readRowData[2]) ? $readRowData[2] : '';
                        $data['product_code'] = isset($readRowData[3]) ? $readRowData[3] : '';
                        $data['purchases_price'] = isset($readRowData[4]) ? $readRowData[4] : '';
                        $data['salesPrice'] = isset($readRowData[5]) ? $readRowData[5] : '';
                        $data['retailPrice'] = isset($readRowData[6]) ? $readRowData[6] : '';
                        $data['dist_id'] = 1;
                        $data['updated_by'] = $this->admin_id;

                        if (!empty($data['product_code']) && !empty($data['productName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('product', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('adminProductImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('adminProductImport'));
                endif;
            elseif (!empty($_FILES['BrandImport']['name']))://product cat list import operation start this block
                $config['upload_path'] = './uploads/import/setup/';
                $config['allowed_types'] = 'xl|txt|csv|mdb';
                $config['file_name'] = date("Y-m-d");
                $this->load->library('upload');
                $this->upload->initialize($config);
                $upload = $this->upload->do_upload('BrandImport');
                $data = $this->upload->data();
                $this->load->helper('file');
                $file = $_FILES['BrandImport']['tmp_name'];
                $importFile = fopen($file, "r");
                $row = 0;
                $storeData = array();
                while (($readRowData = fgetcsv($importFile, 1000, ",")) !== false) {
                    //dumpVar($readRowData);
                    if ($row != 0):
                        unset($data); //empty array;
                        /* check duplicate supplier id  start */
                        $condition = array(
                            'brandName' => $readRowData[0],
                            'dist_id' => $this->dist_id
                        );
                        $exitsID = $this->Common_model->get_single_data_by_many_columns('brand', $condition);
                        if (empty($exitsID)):
                            $data['brandName'] = isset($readRowData[0]) ? $readRowData[0] : '';
                            $data['dist_id'] = 1;
                            $data['updated_by'] = $this->admin_id;
                        endif;
                        /* check duplicate supplier id end */
                        if (!empty($data['brandName'])):
                            $storeData[] = $data; //store each single row;
                        endif;
                    endif;
                    $row++;
                }
                if (!empty($storeData)):
                    $this->db->insert_batch('brand', $storeData);
                endif;
                if ($this->db->affected_rows() > 0):
                    message("Your csv file successfully inserted into database.");
                    redirect(site_url('adminProductImport'));
                else:
                    notification("Your csv file not inserted.please check csv file format properly.");
                    redirect(site_url('adminProductImport'));
                endif;


            endif;
        }
        $data['title'] = 'Import';
        $data['mainContent'] = $this->load->view('admin/product/productImport', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminSupEdit($updateid = null) {

        if (isPostBack()) {
            $data['supID'] = $this->input->post('supplierId');
            $data['supName'] = $this->input->post('supName');
            $data['supEmail'] = $this->input->post('supEmail');
            $data['supPhone'] = $this->input->post('supPhone');
            $data['supAddress'] = $this->input->post('supAddress');
            $data['colorCode'] = $this->input->post('colorCode');
            if (!empty($this->input->post('image')[0])) {
                $data['supLogo'] = $this->input->post('image')[0];
            }
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $this->Common_model->update_data('supplier', $data, 'sup_id', $updateid);
            if (!empty($updateid)) {
                unset($_POST);
                message(" Supplier updated successfully.");
                redirect(site_url('adminSupList'));
            }
        }
        $data['title'] = 'Supplier || Edit';
        $data['supplierEdit'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $updateid);
        $data['mainContent'] = $this->load->view('admin/supplier/supplierEdit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminSupAdd() {

        if (isPostBack()) {
            $data['supID'] = $this->input->post('supplierId');
            $data['supName'] = $this->input->post('supName');
            $data['supEmail'] = $this->input->post('supEmail');
            $data['supPhone'] = $this->input->post('supPhone');
            $data['supAddress'] = $this->input->post('supAddress');
            $data['colorCode'] = $this->input->post('colorCode');
            if (!empty($this->input->post('image')[0])) {
                $data['supLogo'] = $this->input->post('image')[0];
            }
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertID = $this->Common_model->insert_data('supplier', $data);
            if (!empty($insertID)) {
                unset($_POST);
                message("New Supplier created successfully.");
                redirect(site_url('adminSupList'));
            }
        }
        $data['title'] = 'Setup || Supplier';
        $supID = $this->Common_model->getSupplierIDAdmin(1);
        $data['supplierID'] = $this->Common_model->checkDuplicateSupID($supID, 1);
        $data['colorList'] = $this->Common_model->get_data_list('color', 'colorID', 'ASC');
        $data['mainContent'] = $this->load->view('admin/supplier/supplierAdd', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminSupList() {
        $data['title'] = 'Setup || Supplier';
        $data['supplierList'] = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', 1, 'sup_id', 'DESC');
        $data['mainContent'] = $this->load->view('admin/supplier/supplierList', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminBrandAdd() {
        if (isPostBack()) {
            $data['brandName'] = $this->input->post('brandName');
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertid = $this->Common_model->insert_data('brand', $data);
            if ($insertid) {
                message("Your data successfully inserted into database.");
                redirect(site_url('adminBrandList'));
            }
        }
        $data['title'] = 'Admin Brand Add';
        $data['mainContent'] = $this->load->view('admin/brand/brandAdd', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminBrandUpdate($updateId) {
        if (isPostBack()) {
            $data['brandName'] = $this->input->post('brandName');
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertid = $this->Common_model->update_data('brand', $data, 'brandId', $updateId);
            if ($insertid) {
                message("Your data successfully updated into database.");
                redirect(site_url('adminBrandList'));
            }
        }
        $data['title'] = 'Brand Add';
        $data['brandList'] = $this->Common_model->get_single_data_by_single_column('brand', 'brandId', $updateId);
        $data['mainContent'] = $this->load->view('admin/brand/brandEdit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminBrandList() {
        $data['title'] = 'Brand List';
        $data['brandList'] = $this->Common_model->get_data_list_by_single_column('brand', 'dist_id', 1);
        $data['mainContent'] = $this->load->view('admin/brand/brandList', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminUnitAdd() {
        if (isPostBack()) {
            $data['unitTtile'] = $this->input->post('unitTtile');
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertid = $this->Common_model->insert_data('unit', $data);
            if ($insertid) {
                message("Your data successfully inserted into database.");
                redirect(site_url('adminUnitList'));
            }
        }
        $data['title'] = 'Admin Unit Add';
        $data['mainContent'] = $this->load->view('admin/unit/unitAdd', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminUnitUpdate($updateId) {
        if (isPostBack()) {
            $data['unitTtile'] = $this->input->post('unitTtile');
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertid = $this->Common_model->update_data('unit', $data, 'unit_id', $updateId);
            if ($insertid) {
                message("Your data successfully updated into database.");
                redirect(site_url('adminUnitList'));
            }
        }
        $data['title'] = 'Unit Edit';
        $data['unitList'] = $this->Common_model->get_single_data_by_single_column('unit', 'unit_id', $updateId);
        $data['mainContent'] = $this->load->view('admin/unit/unitEdit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminUnitList() {
        $data['title'] = 'Unit List';
        $data['unitList'] = $this->Common_model->get_data_list_by_single_column('unit', 'dist_id', 1);
        $data['mainContent'] = $this->load->view('admin/unit/unitList', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function adminProuductCatList() {
        $data['title'] = 'Product || Category';
        $data['productCatList'] = $this->Common_model->get_data_list_by_single_column('productcategory', 'dist_id', 1);
        $data['mainContent'] = $this->load->view('admin/productCat/productCatList', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function adminProductCatAdd() {
        if (isPostBack()) {
            $data['title'] = $this->input->post('title');
            $data['dist_id'] = 1;
            $data['updated_by'] = $this->admin_id;
            $insertID = $this->Common_model->insert_data('productcategory', $data);
            if (!empty($insertID)) {
                message("Product Category inserted successfully.");
                unset($_POST);
                redirect(site_url('adminProuductCatList'));
            }
        }
        $data['title'] = 'Add Product Category ';
        $data['mainContent'] = $this->load->view('admin/productCat/productCatAdd', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function adminUpdateProductCat($updated_id) {
        if (isPostBack()) {
            $data['title'] = $this->input->post('title');
            $data['dist_id'] = 1;
            $data['updated_at'] = $this->timestamp;
            $data['updated_by'] = $this->admin_id;
            $updateID = $this->Common_model->update_data('productcategory', $data, 'category_id', $updated_id);
            if (!empty($updateID)) {
                message("Product Category updated successfully.");
                unset($_POST);
                redirect(site_url('adminProuductCatList'));
            }
        }
        $data['updateCatInfo'] = $this->Common_model->get_single_data_by_single_column('productcategory', 'category_id', $updated_id);
        $data['title'] = 'Update Product Category ';
        $data['mainContent'] = $this->load->view('admin/productCat/updateProductCat', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function adminUpdateProduct($productid) {
        if (isPostBack()) {
            $data['category_id'] = $this->input->post('category_id');
            $data['product_code'] = $this->input->post('product_code');
            $data['productName'] = $this->input->post('productName');
            $data['purchases_price'] = $this->input->post('purchases_price');
            $data['salesPrice'] = $this->input->post('salesPrice');
            $data['retailPrice'] = $this->input->post('retailPrice');
            $data['brand_id'] = $this->input->post('brand');
            $data['dist_id'] = $this->dist_id;
            $data['updated_by'] = $this->admin_id;
            $updateid = $this->Common_model->update_data('product', $data, 'product_id', $productid);
            if (!empty($updateid)):
                message("Product update successfully.");
                redirect(site_url('adminProuductList'));
            else:
                message("Product Can't update.");
                redirect(site_url('adminProuductList'));
            endif;
        }

        $data['title'] = 'Update Product';
        $data['productEdit'] = $this->Common_model->get_single_data_by_single_column('product', 'product_id', $productid);
        $data['productCat'] = $this->Common_model->get_data_list_by_single_column('productcategory', 'dist_id', 1, 'title', 'ASC');
        $data['brandList'] = $this->Common_model->get_data_list_by_single_column('brand', 'dist_id', 1);
        $data['mainContent'] = $this->load->view('admin/product/editProduct', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function adminProductAdd() {
        if (isPostBack()) {
            $data['category_id'] = $this->input->post('category_id');
            $data['product_code'] = $this->input->post('product_code');
            $data['productName'] = $this->input->post('productName');
            $data['purchases_price'] = $this->input->post('purchases_price');
            $data['salesPrice'] = $this->input->post('salesPrice');
            $data['retailPrice'] = $this->input->post('retailPrice');
            $data['brand_id'] = $this->input->post('brand');
            $data['dist_id'] = $this->dist_id;
            $data['updated_by'] = $this->admin_id;
            $insertid = $this->Common_model->insert_data('product', $data);
            if (!empty($insertid)):
                message("New product inserted successfully.");
                redirect(site_url('adminProuductList'));
            else:
                message("Product Can't inserted.");
                redirect(site_url('adminProductAdd'));
            endif;
        }
        $productOrgId = $this->db->where('dist_id', $this->dist_id)->count_all_results('product') + 1;
        $data['productid'] = "HPID" . str_pad($productOrgId, 4, "0", STR_PAD_LEFT);
        $data['title'] = 'Add New Product';
        // $data['supplierList'] = $this->Common_model->get_data_list_by_single_column('productcategory', 'dist_id', $this->dist_id, 'title', 'ASC');
        $data['brandList'] = $this->Common_model->get_data_list_by_single_column('brand', 'dist_id', 1);
        $data['productCat'] = $this->Common_model->get_data_list_by_single_column('productcategory', 'dist_id', 1, 'title', 'ASC');
        $data['mainContent'] = $this->load->view('admin/product/addNewProduct', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function adminProuductList() {
        $data = array();
        $data['productList'] = $this->Common_model->get_data_list_by_single_column('product', 'dist_id', 1);
        $data['title'] = 'Product List';
        $data['mainContent'] = $this->load->view('admin/product/productList', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function profile() {
        $data = array();
        $data['adminInfo'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $this->admin_id);

        $data['title'] = 'Profile Update';
        $data['mainContent'] = $this->load->view('admin/users/profile', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    //// Edit Profile


    function change_Admin_password() {

        if (isPostBack()) {

            $oldPassword = md5($this->input->post('oldPassword'));
            $newPassword = md5($this->input->post('newPassword'));
            $confirmPassword = md5($this->input->post('confirmPassword'));

            $adminInfo = array(
                'admin_id' => $this->admin_id,
                'password' => $oldPassword
            );
            $exitsInfo = $this->Common_model->get_single_data_by_many_columns('admin', $adminInfo);
            if (!empty($exitsInfo)) {

                if ($newPassword == $confirmPassword) {

                    $data['password'] = $newPassword;
                    $this->Common_model->update_data('admin', $data, 'admin_id', $this->admin_id);
                    message("Your password successfully change!.");
                    redirect(site_url('profile'));
                } else {
                    notification("Password does't match with confirm password!.");
                    redirect(site_url('change_Admin_password'));
                }
            } else {
                exception("Your Old password not exits in our database.");
                redirect(site_url('change_Admin_password'));
            }
        }

        $data['title'] = 'Change Password';
        $data['adminInfo'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $this->admin_id);
        $data['mainContent'] = $this->load->view('admin/users/changePassword', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function updateProfile() {

        if (isPostBack()) {

            $data['name'] = $this->input->post('name');
            $data['email'] = $this->input->post('email');
            $data['address'] = $this->input->post('address');
            $data['phone'] = $this->input->post('phone');
            $data['lastUpdate'] = date('Y-m-d');
            $password = $this->input->post('password');
            $image = $_POST['image'][0];

            if (!empty($password)) {
                $data['password'] = md5($password);
            }
            if (!empty($image)) {
                $data['image'] = $image;
            }

            $this->Common_model->update_data('admin', $data, 'admin_id', $this->admin_id);
            message("Your Profile successfully updated into database.");
            redirect(site_url('profile'));
        }
        $data = array();
        $data['title'] = 'Update Admin Profile';
        $data['admin_info'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $this->admin_id);
        $data['mainContent'] = $this->load->view('admin/users/edit_profile', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    public function update_profile() {


        $data = array();
        $admin_id = $this->input->post('admin_id', true);
        $data['admin_name'] = $this->input->post('admin_name', true);
        $data['admin_email'] = $this->input->post('admin_email', true);
        $data['admin_password'] = md5($this->input->post('admin_password'));
        $data['admin_address'] = $this->input->post('admin_address');
        $data['admin_phone'] = $this->input->post('admin_phone');


        if ($_FILES['admin_picture']['name'] != NULL) {
            $config['upload_path'] = './files/users/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 2048;
            //$config['max_width']            = 1024;
            //$config['max_height']           = 768;
            $error = '';
            $fdata = array();
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('admin_picture')) {
                $error = $this->upload->display_errors();
                $sdata = array();
                $sdata['exception'] = $error;
                $this->session->set_userdata($sdata);
                redirect('Ael_panel/profile');
            } else {
                $fdata = $this->upload->data();
                $data['admin_picture'] = $config['upload_path'] . $fdata['file_name'];
            }
        }



        $this->Ael_panel_model->update_admin_info($data, $admin_id);
        redirect('Ael_Panel/profile');
    }

    public function change_password($admin_id) {
        $data = array();
        $data['title'] = 'Change Admin Password';
        $data['admin_id'] = $this->session->userdata('admin_id');
        $data['admin_info'] = $this->Ael_panel_model->select_admin_profile($admin_id);


        $data['admin_master'] = $this->load->view('admin/users/chng_pass', $data, true);
        $this->load->view('admin/home', $data);
    }

    public function update_password() {


        $data = array();
        $admin_id = $this->input->post('admin_id', true);

        $admin_password1 = md5($this->input->post('admin_password1'));

        $admin_password2 = md5($this->input->post('admin_password2'));

        if ($admin_password1 != $admin_password2) {
            $sdata['message'] = 'Not Match !';
            $this->session->set_userdata($sdata);
            redirect('change_password/' . $admin_id);
        } else {


            $data['admin_password'] = md5($this->input->post('admin_password1'));

            $this->Ael_panel_model->update_admin_password($data, $admin_id);
            redirect('profile');
        }
    }

    function inbox() {
        $data['inboxList'] = $this->Common_model->get_data_list('message');
        $data['title'] = 'Inbox';
        $data['mainContent'] = $this->load->view('admin/message/inbox', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function inbox_add() {

        if (isPostBack()) {

            $recipient = $this->input->post('recipient');
            $data['msgTo'] = implode("-", $recipient);
            $data['msgSubject'] = $this->input->post('subject');
            $data['msgDescrip'] = $this->input->post('message');
            $data['date'] = date('Y-m-d');
            $insertid = $this->Common_model->insert_data('message', $data);
            if (!empty($insertid)) {
                foreach ($recipient as $eachinfo):
                    $msgUser['msgid'] = $insertid;
                    $msgUser['userid'] = $eachinfo;
                    $msgUser['date'] = date('Y-m-d');
                    $this->Common_model->insert_data('messageuser', $msgUser);
                endforeach;
            }
            message("Your data successfully inserted into database.");
            redirect(site_url('inbox'));
        }

        $data['distributor'] = $this->Common_model->get_data_list('tbl_distributor', 'companyName', 'ASC');
        $data['title'] = 'Inbox Add';
        $data['mainContent'] = $this->load->view('admin/message/inbox_add', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function offer_add() {
        if (isPostBack()) {
            $data = $this->input->post();
            $data['fromDate'] = $this->input->post('fromDate');
            $data['toDate'] = $this->input->post('toDate');
            $data['date'] = date('Y-m-d');
            $data['dateRange'] = $data['fromDate'] . '  =   ' . $data['toDate'];
            unset($data['fromDate']);
            unset($data['toDate']);
            $insertid = $this->Common_model->insert_data('offer', $data);
            if (!empty($insertid)) {
                message("Your data successfully inserted into database.");
                redirect(site_url('offer'));
            }
        }
        $data['title'] = 'Offer Add';
        $data['mainContent'] = $this->load->view('admin/offer/offer_add', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function offer_edit($eidt) {
        if (isPostBack()) {
            $data = $this->input->post();
            // $data['date'] = date('Y-m-d');
            $data['fromDate'] = $this->input->post('fromDate');
            $data['toDate'] = $this->input->post('toDate');
            $data['dateRange'] = $data['fromDate'] . '-' . $data['toDate'];
            unset($data['fromDate']);
            unset($data['toDate']);
            $insertid = $this->Common_model->update_data('offer', $data, 'offerId', $eidt);
            if (!empty($insertid)) {
                message("Your data successfully updated into database.");
                redirect(site_url('offer'));
            }
        }
        $data['offerList'] = $this->Common_model->get_single_data_by_single_column('offer', 'offerId', $eidt);
        $data['title'] = 'offer  Edit';
        $data['mainContent'] = $this->load->view('admin/offer/offer_edit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function offer_() {
        $data['offerList'] = $this->Common_model->get_data_list('offer', 'offerId', 'desc');
        $data['title'] = 'Offer List';
        $data['mainContent'] = $this->load->view('admin/offer/offer', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function zone_add() {
        if (isPostBack()) {
            $data = $this->input->post();
            $insertid = $this->Common_model->insert_data('zone', $data);
            if (!empty($insertid)) {
                message("Your data successfully inserted into database.");
                redirect(site_url('zone'));
            }
        }
        $data['divisionList'] = $this->Common_model->get_data_list('divisions', 'name', 'ASC');
        $data['title'] = 'Zone Add';
        $data['mainContent'] = $this->load->view('admin/zone/zone_add', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function zone_edit($eidt) {
        if (isPostBack()) {

            $data = $this->input->post();
            $insertid = $this->Common_model->update_data('zone', $data, 'zone_id', $eidt);

            if (!empty($insertid)) {
                message("Your data successfully updated into database.");
                redirect(site_url('zone'));
            }
        }
        $data['divisionList'] = $this->Common_model->get_data_list('divisions', 'name', 'ASC');
        $data['zoneList'] = $this->Common_model->get_single_data_by_single_column('zone', 'zone_id', $eidt);
        $data['title'] = 'Zone Edit';
        $data['mainContent'] = $this->load->view('admin/zone/zone_edit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function zone() {
        $data['zoneList'] = $this->Common_model->get_data_list('zone', 'zone_title', 'ASC');
        $data['title'] = 'Zone List';
        $data['mainContent'] = $this->load->view('admin/zone/zone', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function district_add() {
        if (isPostBack()) {
            $data = $this->input->post();
            $insertid = $this->Common_model->insert_data('district', $data);
            if (!empty($insertid)) {
                message("Your data successfully inserted into database.");
                redirect(site_url('district_list'));
            }
        }
        $data['title'] = 'District Add';
        $data['mainContent'] = $this->load->view('admin/district/district_add', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function district_edit($eidt) {
        if (isPostBack()) {
            $data = $this->input->post();
            $insertid = $this->Common_model->update_data('district', $data, 'district_id', $eidt);
            if (!empty($insertid)) {
                message("Your data successfully updated into database.");
                redirect(site_url('district_list'));
            }
        }
        $data['districEdit'] = $this->Common_model->get_single_data_by_single_column('district', 'district_id', $eidt);
        $data['title'] = 'District Edit';
        $data['mainContent'] = $this->load->view('admin/district/district_edit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function district_list() {
        $data['districtList'] = $this->Common_model->get_data_list('district', 'district_title', 'ASC');
        $data['title'] = 'District List';
        $data['mainContent'] = $this->load->view('admin/district/district_list', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function distributor() {
        $this->db->join('admin', 'admin.distributor_id = tbl_distributor.dist_id', 'inner');
        $data['distributorList'] = $this->Common_model->get_data_list('tbl_distributor', 'dist_name', 'ASC');
        $data['title'] = 'Distributor List';
        $data['mainContent'] = $this->load->view('admin/distributor/distributor', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function viewDistributor($distributorId) {
        $data['distributoList'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $distributorId);
        $data['title'] = 'View Distributor';
        $data['mainContent'] = $this->load->view('admin/distributor/viewDistributor', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function distributor_add() {
        if (isPostBack()) {

            // dumpVar($_POST);
            $data['companyName'] = $this->input->post('companyName');
            $data['dist_name'] = $this->input->post('dist_name');
            $data['contactNo'] = $this->input->post('contactNo');
            $data['contactPerson'] = $this->input->post('contactPerson');
            $data['contactPersonCont'] = $this->input->post('contactPersonCont');
            $data['dist_email'] = $this->input->post('dist_email');
            $data['dist_password'] = md5($this->input->post('dist_password'));
            $data['dist_phone'] = $this->input->post('dist_phone');
            $data['dis_website'] = $this->input->post('dis_website');
            $data['zone'] = $this->input->post('zone');
            $data['division'] = $this->input->post('division');
            $data['district'] = $this->input->post('district');
            $data['thanna'] = $this->input->post('thanna');
            $data['dist_address'] = $this->input->post('dist_address');
            $data['status'] = $this->input->post('status');
            if (!empty($_POST['image'][0])):
                $data['dist_picture'] = $_POST['image'][0];
            endif;
            if (empty($data['dist_email']) || empty($data['dist_password'])) {
                message("Distributor Email and Password can't be empty!!");
                redirect(site_url('distributor_add'));
            }
            //check duplicate email
            $exitsEmail = $this->Common_model->get_single_data_by_single_column('admin', 'email', $data['dist_email']);
            if (!empty($exitsEmail)) {
                message("Distributor email must be unique!!");
                redirect(site_url('distributor_add'));
            } else {

                $this->db->trans_start();
                $insertid = $this->Common_model->insert_data('tbl_distributor', $data);

                if (!empty($insertid)) {
                    $admin['email'] = $data['dist_email'];
                    $admin['phone'] = $data['dist_phone'];
                    $admin['name'] = $data['dist_name'];
                    $admin['password'] = $data['dist_password'];
                    $admin['status'] = $data['status'];
                    $admin['type'] = 'Super';
                    $admin['accessType'] = '2';
                    $admin['distributor_id'] = $insertid;
                    $adminId = $this->Common_model->insert_data('admin', $admin);
                    $adminAccess['navigation_id'] = 17;
                    $adminAccess['parent_id'] = 2;
                    $adminAccess['admin_id'] = $adminId;
                    $this->Common_model->insert_data('admin_role', $adminAccess);
                    $this->Common_model->makeGeneralLedger($insertid);
                    
                    
                }
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    message("Data Cnt't inserted into database.");
                    redirect(site_url('distributor'));
                } else {
                    message("Your data successfully inserted into database.");
                    redirect(site_url('distributor'));
                }
            }
        }
        $data['divisionList'] = $this->Common_model->get_data_list('divisions', 'name', 'ASC');
        $data['zoneList'] = $this->Common_model->get_data_list('zone', 'zone_title', 'ASC');


        $data['title'] = 'Distributor Add';
        $data['mainContent'] = $this->load->view('admin/distributor/distributor_add', $data, true);
        $this->load->view('admin/masterDashboard', $data);
    }

    function getDistrictList() {
        $divisionId = $this->input->post('divisionId');
        $districtId = $this->input->post('districtId');
        $districtList = $this->Common_model->get_data_list_by_single_column('districts', 'division_id', $divisionId);
        //  echo $this->db->last_query();die;
        $append = '';
        if (!empty($districtList)):
            foreach ($districtList as $eachInfo):
                $selec = '';
                if (!empty($districtId) && $districtId == $eachInfo->id):
                    $selec = 'selected';
                endif;


                $append .= '<option ' . $selec . ' value="' . $eachInfo->id . '">' . $eachInfo->name . '</option>';
            endforeach;
        else:
            $append .= '<option>Empty!</option>';
        endif;
        echo $append;
    }

    function getThanaList() {
        $districtid = $this->input->post('districtid');
        $thanaId = $this->input->post('thanaId');
        $districtList = $this->Common_model->get_data_list_by_single_column('upazilas', 'district_id', $districtid);
        //  echo $this->db->last_query();die;
        $append = '';
        if (!empty($districtList)):
            foreach ($districtList as $eachInfo):

                $selec = '';
                if (!empty($thanaId) && $thanaId == $eachInfo->id):
                    $selec = 'selected';
                endif;

                $append .= '<option ' . $selec . ' value="' . $eachInfo->id . '">' . $eachInfo->name . '</option>';
            endforeach;
        else:
            $append .= '<option>Empty!</option>';
        endif;
        echo $append;
    }

    function getUnionList() {
        $thanaId = $this->input->post('thanaId');
        $unionId = $this->input->post('unionId');
        $districtList = $this->Common_model->get_data_list_by_single_column('unions', 'upazila_id', $thanaId);

        $append = '';
        if (!empty($districtList)):
            foreach ($districtList as $eachInfo):

                $selec = '';
                if (!empty($unionId) && $unionId == $eachInfo->id):
                    $selec = 'selected';
                endif;


                $append .= '<option ' . $selec . ' value="' . $eachInfo->id . '">' . $eachInfo->bn_name . '</option>';
            endforeach;
        else:
            $append .= '<option>Empty!</option>';
        endif;
        echo $append;
    }

    function checkDuplicateEmailForUser() {



        $email = $this->input->post('email');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateEmailForUserEdit() {



        $email = $this->input->post('email');
        $adminId = $this->input->post('adminId');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
                'admin_id !=' => $adminId,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);

            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function distributor_edit($id) {
        if (isPostBack()) {

            $data['companyName'] = $this->input->post('companyName');
            $data['dist_name'] = $this->input->post('dist_name');
            $data['contactNo'] = $this->input->post('contactNo');
            $data['contactPerson'] = $this->input->post('contactPerson');
            $data['contactPersonCont'] = $this->input->post('contactPersonCont');
            $data['dist_email'] = $this->input->post('dist_email');
            $password = $this->input->post('dist_password');
            if (!empty($password)):
                $data['dist_password'] = md5($this->input->post('dist_password'));
            endif;
            $data['dist_phone'] = $this->input->post('dist_phone');
            $data['dis_website'] = $this->input->post('dis_website');
            $data['zone'] = $this->input->post('zone');
            $data['division'] = $this->input->post('division');
            $data['district'] = $this->input->post('district');
            $data['thanna'] = $this->input->post('thanna');
            $data['dist_address'] = $this->input->post('dist_address');

            if (!empty($_POST['image'][0])):
                $data['dist_picture'] = $_POST['image'][0];
            endif;
            if (empty($data['dist_email'])) {
                message("Distributor Email and Password can't be empty!!");
                redirect(site_url('distributor_add'));
            }
            $insertid = $this->Common_model->update_data('tbl_distributor', $data, 'dist_id', $id);
            $data_admin['status'] = $this->input->post('status');
            $insertidAdmin = $this->Common_model->update_data('admin', $data_admin, 'distributor_id', $id);
            if (!empty($insertid)) {
                echo 'test';
                message("Your data successfully update into database.");
                redirect('distributor');
            }
        }
        $data['divisionList'] = $this->Common_model->get_data_list('divisions', 'name', 'ASC');
        $data['zoneList'] = $this->Common_model->get_data_list('zone', 'zone_title', 'ASC');
        $this->db->join('admin', 'admin.distributor_id = tbl_distributor.dist_id', 'inner');
        $data['distributorList'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $id);
        $data['title'] = 'Distributor Edit';
        $data['mainContent'] = $this->load->view('admin/distributor/distributor_edit', $data, true);
        $this->load->view('admin/masterDashboard', $data);
//        $this->output->enable_profiler(true);
    }

}
