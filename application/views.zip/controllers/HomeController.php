<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;

    public function __construct() {
        parent::__construct();

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->load->model('Dashboard_Model');
        $thisdis = $this->session->userdata('dis_id');
        $admin_id = $this->session->userdata('admin_id');
        if (empty($thisdis) || empty($admin_id)) {
            redirect(site_url('DistributorDashboard'));
        }
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');
    }

    public function dbExport() {
        if (isPostBack()) {
            $format = $this->input->post('format');
            $this->load->dbutil();
            $db_name = 'dipsyl ' . date('F d, Y _ g-i-s A') . '.' . $format;
            $prefs = array('format' => $format, 'filename' => $db_name);
            $backup = & $this->dbutil->backup($prefs);
            $save = 'C:\SoftwareBackup/' . $db_name;
            $this->load->helper('file');
            //write_file($save, $backup); 
            $this->load->helper('download');
            force_download($db_name, $backup);
            $this->session->set_flashdata('success', 'Database has been backed up into' . $save);
            redirect('common/dbExport');
        }
        $data['title'] = 'Database Backup';
        $data['dashboardContent'] = $this->load->view('dbBackup/dbExport', $data, TRUE);
        $this->load->view('dashboard/master_dashboard_panel', $data);
    }

    public function moduleDashboard() {


        $data['purchasesList'] = $this->Common_model->get_purchase_list($this->dist_id);
        $data['saleslist'] = $this->Common_model->get_sales_list($this->dist_id);
        $data['paymentVoucher'] = $this->Common_model->get_payment_list($this->dist_id);
        $data['receiveVoucher'] = $this->Common_model->get_receive_list($this->dist_id);
        $data['journalVoucher'] = $this->Common_model->get_journal_list($this->dist_id);
        $data['topSalesProduct'] = $topSalesProduct = $this->Dashboard_Model->getTopSalesProduct($this->dist_id);
        $data['accountReceiable'] = $accountReceiable = $this->Finane_Model->accountBalance(58);
        $data['accountPayable'] = $accountPayable = $this->Finane_Model->accountBalance(50);
        //dumpVar($data['accountPayable']);
        $data['cashInHand'] = $cashInHand = $this->Finane_Model->accountBalance(54);
        $data['totalSalesAmount'] = $totalSales = $this->Dashboard_Model->getTotalSales();
        // echo $totalSales;die;
        //$data['getInventoryStock'] = $inventoryStock = $this->Dashboard_Model->getInventoryStock($this->dist_id);
        $allProduct = $this->Common_model->getPublicProductWithoutCat($this->dist_id);
        /* Get inventory stock */


        //dumpVar($allProduct);


        $allProductStock = array();
        foreach ($allProduct as $key => $value) {
            $productlist = $this->Dashboard_Model->getInventoryStock($this->dist_id, $value->product_id);
            $allProductStock[] = $productlist . '-' . $value->productName;
        }
        $data['inventoryAllStock'] = $allProductStock;

        $totalProductPrice = '';
        foreach ($allProduct as $key => $value) {
            $productQty = $this->Dashboard_Model->getInventoryStock($this->dist_id, $value->product_id);
            $productAvgPrice = $this->Dashboard_Model->getProductAvgPrice($this->dist_id, $value->product_id);
            if (!empty($productQty)) {
                $totalProductPrice+= $productQty * $productAvgPrice;
            }
        }

        $data['inventoryAmount'] = $totalProductPrice;
        /* get inventory stock */

        // dumpVar($data['inventoryAllStock']);

        $condition = array(
            'parentId' => 55,
            'dist_id' => $this->dist_id
        );
        $cashAtBankList = $this->Common_model->get_data_list_by_many_columns('generaldata', $condition);
        //  dumpVar($cashAtBankList);
        /* Cash at bank */
        $total_balance = '';
        foreach ($cashAtBankList as $key => $row_cma):
            $total_opendebit = $this->Finane_Model->opening_balance_dr($this->dist_id, $row_cma->chartId);
            $total_opencredit = $this->Finane_Model->opening_balance_cr($this->dist_id, $row_cma->chartId);
            $total_debit = '';
            $total_credit = '';
            $this->db->select("*");
            $this->db->from("generalledger");
            $this->db->where('dist_id', $this->dist_id);
            $this->db->where('account', $row_cma->chartId);
            $this->db->where('date <=', date('Y-m-d'));
            $query = $this->db->get()->result_array();
            foreach ($query as $row):
                $total_debit += $row['debit'];
                $total_credit += $row['credit'];
            endforeach;
            $total_debit += $total_opendebit;
            $total_credit += $total_opencredit;
            $total_balance += $total_debit - $total_credit;
        endforeach;
        // dumpVar($total_balance);
        $data['totalCashAtBank'] = $total_balance;
        $data['title'] = 'Admin || Module';
        $data['mainContent'] = $this->load->view('distributor/module', $data, true);
        $this->load->view('distributor/masterTemplate', $data);
    }

    public function dashboard($moduleId = null) {

        if (!empty($moduleId)) {
            $_SESSION['moduleList'] = $moduleId;
        }

        $data['purchasesList'] = $this->Common_model->get_purchase_list($this->dist_id);
        $data['saleslist'] = $this->Common_model->get_sales_list($this->dist_id);
        $data['paymentVoucher'] = $this->Common_model->get_payment_list($this->dist_id);
        $data['receiveVoucher'] = $this->Common_model->get_receive_list($this->dist_id);
        $data['journalVoucher'] = $this->Common_model->get_journal_list($this->dist_id);
        $data['topSalesProduct'] = $topSalesProduct = $this->Dashboard_Model->getTopSalesProduct($this->dist_id);
        $data['accountReceiable'] = $accountReceiable = $this->Finane_Model->accountBalance(58);
        $data['accountPayable'] = $accountPayable = $this->Finane_Model->accountBalance(50);
        //dumpVar($data['accountPayable']);
        $data['cashInHand'] = $cashInHand = $this->Finane_Model->accountBalance(54);
        $data['totalSalesAmount'] = $totalSales = $this->Dashboard_Model->getTotalSales();
        // echo $totalSales;die;
        //$data['getInventoryStock'] = $inventoryStock = $this->Dashboard_Model->getInventoryStock($this->dist_id);
        $allProduct = $this->Common_model->getPublicProductWithoutCat($this->dist_id);

        $totalProductPrice = '';
        foreach ($allProduct as $key => $value) {
            $productQty = $this->Dashboard_Model->getInventoryStock($this->dist_id, $value->product_id);
            $productAvgPrice = $this->Dashboard_Model->getProductAvgPrice($this->dist_id, $value->product_id);
            if (!empty($productQty)) {
                $totalProductPrice+= $productQty * $productAvgPrice;
            }
        }

        $data['inventoryAmount'] = $totalProductPrice;

        /* Get inventory stock */
        $totalStockValue = '';
        $allProductStock = array();
        foreach ($allProduct as $key => $value) {
            $productlist = $this->Dashboard_Model->getInventoryStock($this->dist_id, $value->product_id);
            $totalStockValue +=$productlist;

            $allProductStock[] = $productlist . '-' . $value->productName;
        }
        $data['inventoryAllStock'] = $allProductStock;
        /* get inventory stock */
        //echo $totalStockValue;die;
        $condition = array(
            'parentId' => 55,
            'dist_id' => $this->dist_id
        );
        $cashAtBankList = $this->Common_model->get_data_list_by_many_columns('generaldata', $condition);
        // dumpVar($cashAtBankList);
        /* Cash at bank */
        $total_balance = '';
        foreach ($cashAtBankList as $key => $row_cma):

            // dumpVar($row_cma);


            $total_opendebit = $this->Finane_Model->opening_balance_dr($this->dist_id, $row_cma->chartId);
            $total_opencredit = $this->Finane_Model->opening_balance_cr($this->dist_id, $row_cma->chartId);
            $total_debit = '';
            $total_credit = '';
            $this->db->select("*");
            $this->db->from("generalledger");
            $this->db->where('dist_id', $this->dist_id);
            $this->db->where('account', $row_cma->chartId);
            $this->db->where('date <=', date('Y-m-d'));
            $query = $this->db->get()->result_array();
            foreach ($query as $row):
                $total_debit += $row['debit'];
                $total_credit += $row['credit'];
            endforeach;
            $total_debit += $total_opendebit;
            $total_credit += $total_opencredit;
            $total_balance += $total_debit - $total_credit;
        endforeach;
        // dumpVar($total_balance);

        $data['totalCashAtBank'] = $total_balance;
        /* Cash at continure */

        $totalSales = array();
        for ($i = 1; $i < 32; $i++) {

            if ($i < 10) {
                $date = date('Y-m-0' . $i);
            } else {
                $date = date('Y-m-' . $i);
            }

            $orgDate = date('Y-m-d');
            if ($date <= $orgDate) {
                $amount = $this->Common_model->getDailySalesAmount($date, $this->dist_id);
                $totalSales[] = isset($amount) ? $amount : null;
            }
        }
        $totalPurchases = array();
        for ($i = 1; $i < 32; $i++) {
            if ($i < 10) {
                $date = date('Y-m-0' . $i);
            } else {
                $date = date('Y-m-' . $i);
            }

            $orgDate = date('Y-m-d');
            if ($date <= $orgDate) {
                $amount = $this->Common_model->getDailyPurchasesAmount($date, $this->dist_id);
                $totalPurchases[] = isset($amount) ? $amount : null;
            }
        }
        $data['fullMonthPurchasesList'] = $totalPurchases;
        $data['fullMonthSalesList'] = $totalSales;
        $data['title'] = 'Distributor || Dashboard';
        $data['mainContent'] = $this->load->view('distributor/dashboard', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function adminAccess() {
        $data['title'] = 'Admin || Access';
        $data['mainContent'] = $this->load->view('distributor/dashboard', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function userAccess() {

        $array = array(
            'status' => 1,
            'distributor_id' => $this->dist_id,
            'accessType' => 2,
        );
        $data['title'] = 'User || Access';
        $data['adminList'] = $this->Common_model->get_data_list_by_many_columns('admin', $array);
        $data['mainContent'] = $this->load->view('distributor/userAccess', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function insert_menu_accessList() {

        $user_id = $this->input->post('user_id');
        $navigation = $this->input->post('navigation');
        $this->Common_model->delete_data('admin_role', 'admin_id', $user_id);
        foreach ($navigation as $key => $value):
            $get_parent_id = $this->Common_model->get_single_data_by_single_column('navigation', 'navigation_id', $value);
            $data['admin_id'] = $user_id;
            $data['navigation_id'] = $value;
            $data['parent_id'] = $get_parent_id->parent_id;
            $this->Common_model->insert_data('admin_role', $data);
        endforeach;
        message("Admin Access successfully added.");
        redirect(site_url('userAccess'));
    }

    function get_menu_list() {
        $data['user_id'] = $this->input->post('user_id');
        $module = array(1001, 1002, 1003, 1004, 1005);
        $this->db->select("*");
        $this->db->from("navigation");
        $this->db->where_in('parent_id', $module);
        $result = $this->db->get()->result();


        $data['navigationList'] = $result;
        return $this->load->view('distributor/ajax/menuListShow', $data);
    }

}
