<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class FinaneController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;

    public function __construct() {
        parent::__construct();

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');

        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url());
        }
    }

    public function billInvoice() {
        $condition = array(
            'form_id' => 29,
            'dist_id' => $this->dist_id,
        );
        $data['title'] = 'Bill Voucher';
        $data['billInfo'] = $this->Common_model->get_data_list_by_many_columns('generals', $condition,'generals_id','DESC');
        $data['mainContent'] = $this->load->view('distributor/finance/bill/billInvoice', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function billInvoice_view($invoiceId) {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['title'] = 'Bill Invoice View';
        $data['billInfo'] = $billInfo = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $invoiceId);
        if ($billInfo->customer_id):
            $data['customerInfo'] = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $billInfo->customer_id);
        elseif ($billInfo->supplier_id):
            $data['supplierInfo'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $billInfo->supplier_id);
        else:

        endif;
        $data['ledgerInfo'] = $this->Common_model->get_data_list_by_single_column('generalledger', 'generals_id', $invoiceId);
        $data['mainContent'] = $this->load->view('distributor/finance/bill/billView', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function billInvoicePayment($billId) {

        if (isPostBack()) {


            $this->form_validation->set_rules('date', 'Payment Date', 'required');
            $this->form_validation->set_rules('accountCr', 'Voucher Id', 'required');
            $this->form_validation->set_rules('paymentCr', 'Payment Type', 'required');
            $getVoucherInfo = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $billId);
            if ($this->form_validation->run() == FALSE) {
                exception("Required field can't be empty.");
                redirect(site_url('billInvoicePayment/' . $billId));
            } else {
                $this->db->trans_start();
                $data['form_id'] = 30;
                $data['dist_id'] = $this->dist_id;
                $data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $data['voucher_no'] = $getVoucherInfo->voucher_no;
                if (!empty($getVoucherInfo->customer_id)):
                    $data['customer_id'] = $getVoucherInfo->customer_id;
                    $data['payType'] = 2;
                elseif (!empty($getVoucherInfo->supplier_id)):
                    $data['supplier_id'] = $getVoucherInfo->supplier_id;
                    $data['payType'] = 3;
                else:
                    $data['payType'] = 1;
                    $data['miscellaneous'] = $getVoucherInfo->miscellaneous;
                endif;
                $data['credit'] = $this->input->post('paymentCr');
                $data['updated_by'] = $this->admin_id;
                $general_id = $this->Common_model->insert_data('generals', $data);

                if (!empty($getVoucherInfo->customer_id)):
                    $custLedger = array(
                        'ledger_type' => 1,
                        'paymentType' => 'Bill Payment',
                        'history_id' => $general_id,
                        'trans_type' => $this->input->post('billVoucher'),
                        'client_vendor_id' => $getVoucherInfo->customer_id,
                        'amount' => $this->input->post('paymentCr'),
                        'cr' => $this->input->post('paymentCr'),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $custLedger);
                endif;
                if (!empty($getVoucherInfo->supplier_id)):
                    $supLedger = array(
                        'ledger_type' => 2,
                        'history_id' => $general_id,
                        'paymentType' => 'Bill Payment',
                        'trans_type' => $this->input->post('billVoucher'),
                        'client_vendor_id' => $getVoucherInfo->supplier_id,
                        'amount' => $this->input->post('paymentCr'),
                        'cr' => $this->input->post('paymentCr'),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $supLedger);
                endif;
                $accountDr = $this->input->post('accountDr');
                /* acount payable credit */
                $dr['generals_id'] = $general_id;
                $dr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $dr['account'] = 50;
                $dr['debit'] = $this->input->post('paymentCr');
                $dr['form_id'] = 30;
                $dr['dist_id'] = $this->dist_id;
                $dr['updated_by'] = $this->admin_id;
                $this->Common_model->insert_data('generalledger', $dr);
                //credit account
                $cr['generals_id'] = $general_id;
                $cr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $cr['account'] = $this->input->post('accountCr');
                $cr['credit'] = $this->input->post('paymentCr');
                $cr['form_id'] = 30;
                $cr['dist_id'] = $this->dist_id;
                $cr['updated_by'] = $this->admin_id;
                $this->Common_model->insert_data('generalledger', $cr);
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    notification("Your data can't be inserted");
                    redirect(site_url('billInvoicePayment/' . $billId));
                } else {
                    message("Your data successfully inserted into database.");
                    redirect(site_url('billInvoice_view/'.$billId));
                }
            }
            /* Pay account Credit */
        }
        $data['billInfo'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $billId);
        $data['ledgerInfo'] = $this->Common_model->get_data_list_by_single_column('generalledger', 'generals_id', $billId);
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $data['title'] = 'Bill Invoice Payment';
        $data['mainContent'] = $this->load->view('distributor/finance/bill/billPayment', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function billInvoice_add() {

        if (isPostBack()) {

            
            $billUser = $this->input->post('billUser');
            //set some validation for input fields
            $this->form_validation->set_rules('billDate', 'Payment Date', 'required');
            $this->form_validation->set_rules('billVoucher', 'Voucher Id', 'required');
            $this->form_validation->set_rules('billUser', 'Payment Type', 'required');
            $this->form_validation->set_rules('accountDr[]', 'Account Debit', 'required');
            $this->form_validation->set_rules('amountDr[]', 'Amount Debit', 'required');
            if ($billUser == 1) {
                $this->form_validation->set_rules('miscellaneous', 'Miscellaneous', 'required');
            } else if ($billUser == 2) {
                $this->form_validation->set_rules('customer_id', 'Customer Id', 'required');
            } else {
                $this->form_validation->set_rules('supplier_id', 'Supplier Id', 'required');
            }
            if ($this->form_validation->run() == FALSE) {
                exception("Required field can't be empty.");
                redirect(site_url('billInvoice_add'));
            } else {
                $this->db->trans_start();
                $data['form_id'] = 29;
                $data['dist_id'] = $this->dist_id;
                $data['date'] = date('Y-m-d', strtotime($this->input->post('billDate')));
                $data['voucher_no'] = $this->input->post('billVoucher');
                $data['payType'] = $this->input->post('billUser');
                $cust = $this->input->post('customer_id');
                $supid = $this->input->post('supplier_id');
                $miscellaneous = $this->input->post('miscellaneous');
                if (!empty($cust)):
                    $data['customer_id'] = $cust;
                endif;
                if (!empty($supid)):
                    $data['supplier_id'] = $this->input->post('supplier_id');
                endif;

                if (!empty($miscellaneous)):
                    $data['miscellaneous'] = $this->input->post('miscellaneous');
                endif;
                $data['debit'] = array_sum($this->input->post('amountDr'));
                $data['updated_by'] = $this->admin_id;
                $general_id = $this->Common_model->insert_data('generals', $data);

                if (!empty($cust)):
                    $custLedger = array(
                        'ledger_type' => 1,
                        'paymentType' => 'Bill Voucher',
                        'history_id' => $general_id,
                        'trans_type' => $this->input->post('billVoucher'),
                        'client_vendor_id' => $this->input->post('customer_id'),
                        'amount' => array_sum($this->input->post('amountDr')),
                        'dr' => array_sum($this->input->post('amountDr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('billDate'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $custLedger);
                endif;
                if (!empty($supid)):
                    $supLedger = array(
                        'ledger_type' => 2,
                        'history_id' => $general_id,
                        'paymentType' => 'Bill Voucher',
                        'trans_type' => $this->input->post('billVoucher'),
                        'client_vendor_id' => $this->input->post('supplier_id'),
                        'amount' => array_sum($this->input->post('amountDr')),
                        'dr' => array_sum($this->input->post('amountDr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('billDate'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $supLedger);
                endif;


                $accountDr = $this->input->post('accountDr');
                /* acount payable credit */
                $cr['generals_id'] = $general_id;
                $cr['date'] = date('Y-m-d', strtotime($this->input->post('billDate')));
                $cr['account'] = 50;
                $cr['credit'] = array_sum($this->input->post('amountDr'));
                $cr['form_id'] = 29;
                $cr['dist_id'] = $this->dist_id;
                $cr['updated_by'] = $this->admin_id;
                $this->Common_model->insert_data('generalledger', $cr);

                $allDr = array();
                foreach ($accountDr as $key => $value) {
                    unset($cr);
                    $dr['generals_id'] = $general_id;
                    $dr['date'] = date('Y-m-d', strtotime($this->input->post('billDate')));
                    $dr['account'] = $this->input->post('accountDr')[$key];
                    $dr['debit'] = $this->input->post('amountDr')[$key];
                    $dr['memo'] = $this->input->post('memoDr')[$key];
                    $dr['form_id'] = 29;
                    $dr['dist_id'] = $this->dist_id;
                    $dr['updated_by'] = $this->admin_id;
                    $allDr[] = $dr;
                }
                $this->db->insert_batch('generalledger', $allDr);
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    notification("Your data can't be inserted");
                    redirect(site_url('billInvoice_add'));
                } else {
                    message("Your data successfully inserted into database.");
                    redirect(site_url('billInvoicePayment/' . $general_id));
                }
            }

            /* Pay account Credit */
        }

        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        //echo $this->db->last_query();die;
        $voucherCondition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 29,
        );
        $totalPurchases = $this->Common_model->get_data_list_by_many_columns('generals', $voucherCondition);
        $data['voucherID'] = "BID" . date('y') . date('m') . str_pad(count($totalPurchases) + 1, 4, "0", STR_PAD_LEFT);
        $data['mainContent'] = $this->load->view('distributor/finance/bill/billInvoice_add', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function supplierOpening() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'paymentType' => 'Opening',
            'ledger_type' => '2'
        );
        $data['allBalance'] = $this->Common_model->get_data_list_by_many_columns('client_vendor_ledger', $condition);
        //dumpVar($data['allBalance']);
        $data['title'] = 'Supplier Opening List';
        $data['mainContent'] = $this->load->view('distributor/finance/setup/supOpe', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function customerOpneing() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'paymentType' => 'Opening',
            'ledger_type' => '1'
        );
        $data['allBalance'] = $this->Common_model->get_data_list_by_many_columns('client_vendor_ledger', $condition);
        $data['title'] = 'Customer Opening List';
        $data['mainContent'] = $this->load->view('distributor/finance/setup/cusOpe', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function supplierOpeningAdd() {

        if (isPostBack()) {
            $supID = $this->input->post('suplierID');
            $debit = $this->input->post('debit');
            $credit = $this->input->post('credit');
            foreach ($supID as $key => $eachInfo):
                $condition = array(
                    'ledger_type' => 2,
                    'client_vendor_id' => $supID[$key],
                    'paymentType' => 'Opening',
                );
                $alReadyExits = $this->Common_model->get_single_data_by_single_column('client_vendor_ledger', $condition);
                if (empty($alReadyExits)):
                    if (!empty($debit[$key])):
                        $allAmount = $debit[$key];

                    endif;
                    $data['trans_type'] = $this->input->post('voucherid');
                    $data['date'] = $this->input->post('purchasesDate');
                    $data['ledger_type'] = 2;
                    $data['dist_id'] = $this->dist_id;
                    $data['amount'] = $allAmount;
                    $data['dr'] = $debit[$key];
                    $data['date'] = date('Y-m-d');
                    // $data['cr'] = $credit[$key];
                    $data['paymentType'] = 'Opening';
                    $data['client_vendor_id'] = $supID[$key];
                    $this->Common_model->insert_data('client_vendor_ledger', $data);

                endif;
            endforeach;
            message("Supplier opening balance added successfully");
            redirect(site_url('supplierOpening'));
        }


        $data['supList'] = $this->Common_model->getPublicSupplier($this->dist_id);
        $data['title'] = 'Supplier Opening Add';
        $data['mainContent'] = $this->load->view('distributor/finance/setup/supliOpneAdd', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function customerOpneingAdd() {

        if (isPostBack()) {
            // dumpVar($_POST);
            $supID = $this->input->post('suplierID');
            $debit = $this->input->post('debit');
            // $credit = $this->input->post('credit');
            foreach ($supID as $key => $eachInfo):
                $condition = array(
                    'ledger_type' => 1,
                    'client_vendor_id' => $supID[$key],
                    'paymentType' => 'Opening',
                );
                $alReadyExits = $this->Common_model->get_single_data_by_single_column('client_vendor_ledger', $condition);
                // echo $this->db->last_query();die;
                //  dumpVar($alReadyExits);die;

                if (empty($alReadyExits)):
                    if (!empty($debit[$key])):
                        $allAmount = $debit[$key];

                    endif;
                    $data['trans_type'] = $this->input->post('voucherid');
                    $data['date'] = $this->input->post('purchasesDate');
                    $data['ledger_type'] = 1;
                    $data['dist_id'] = $this->dist_id;
                    $data['amount'] = $allAmount;
                    $data['date'] = date('Y-m-d');
                    $data['dr'] = $debit[$key];
                    //$data['cr'] = $credit[$key];
                    $data['paymentType'] = 'Opening';
                    $data['client_vendor_id'] = $supID[$key];
                    $this->Common_model->insert_data('client_vendor_ledger', $data);
                endif;
            endforeach;
            message("Customer opening balance added successfully");
            redirect(site_url('customerOpneing'));
        }


        $data['cusList'] = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);
        $data['title'] = 'Supplier Opening Add';
        $data['mainContent'] = $this->load->view('distributor/finance/setup/customerOpeAdd', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function customerLedger() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['pageTitle'] = 'Customer Ledger';
        $data['customerList'] = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id, 'customerName', 'ASC');
        $data['title'] = 'Customer Ledger';
        $data['mainContent'] = $this->load->view('distributor/finance/report/customerLedger', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function customerLedger_export_excel() {
        $file = 'Customer Ledger_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $from = $data['fromdate'] = $_SESSION['start_date'];
        $to = $data['todate'] = $_SESSION['end_date'];

        $data['customerList'] = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id, 'customerName', 'ASC');
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);

        $this->load->view('excel_report/customerLedger_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function detailsLedger($parentid) {
        
    }

    public function supplierLedger() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['pageTitle'] = 'Supplier Ledger';
        $data['supplierList'] = $this->Common_model->getPublicSupplier($this->dist_id);
        $data['title'] = 'Supplier Ledger';
        $data['mainContent'] = $this->load->view('distributor/finance/report/supplierLedger', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function supplierLedger_export_excel() {
        $file = 'Supplier Ledger_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $supplierId = $data['supplierId'] = $_SESSION['supplierId'];
        $from = $data['fromdate'] = $_SESSION['start_date'];
        $to = $data['todate'] = $_SESSION['end_date'];

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['supplierList'] = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id, 'supName', 'ASC');

        $this->load->view('excel_report/supplierLedger_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function cashFlow() {

        $data['title'] = 'Cash Flow';
        $data['mainContent'] = $this->load->view('distributor/finance/report/cashflow', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function cashBook() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['title'] = 'Cash Book';
        $data['mainContent'] = $this->load->view('distributor/finance/report/cashBook', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function cashBook_export_excel() {
        $file = 'Cash Book_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $start_date = $data['fromdate'] = $_SESSION['start_date'];
        $end_date = $data['todate'] = $_SESSION['end_date'];

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);

        $this->load->view('excel_report/cashBook_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function bankBook() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['title'] = 'Bank Book';
        $data['mainContent'] = $this->load->view('distributor/finance/report/bankBook', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function bankBook_export_excel() {


        $file = 'Bank Book_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $bankAccount = $data['bankAccount'] = $_SESSION['bankAccount'];
        $start_date = $data['fromdate'] = $_SESSION['start_date'];
        $end_date = $data['todate'] = $_SESSION['end_date'];

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);

        $this->load->view('excel_report/bankBook_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function trialBalance() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['pageTitle'] = 'Trial Balance';
        $data['assetList'] = $this->Common_model->getAccountListByRoodId(1);
        $data['liabilityList'] = $this->Common_model->getAccountListByRoodId(2);
        $data['income'] = $this->Common_model->getAccountListByRoodId(3);
        $data['expense'] = $this->Common_model->getAccountListByRoodId(4);
        //dumpVar($data['expense']);


        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $data['title'] = 'Trial Balance';
        $data['mainContent'] = $this->load->view('distributor/finance/report/newTrialBalance', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function trialBalance_export_excel() {
        $file = 'Trial Balanc_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');



        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['assetList'] = $this->Common_model->getAccountListByRoodId(1);
        $data['liabilityList'] = $this->Common_model->getAccountListByRoodId(2);
        $data['income'] = $this->Common_model->getAccountListByRoodId(3);
        $data['expense'] = $this->Common_model->getAccountListByRoodId(4);
        $data['accountHeadList'] = $this->Common_model->getAccountHead();

        $start_date = $data['fromdate'] = $_SESSION['start_date'];
        $end_date = $data['todate'] = $_SESSION['end_date'];

        $this->load->view('excel_report/trialBalance_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function balanceSheet() {
        $data['assetList'] = $this->Common_model->getAccountListByRoodId(1);
        $data['liabilityList'] = $this->Common_model->getAccountListByRoodId(2);
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['pageTitle'] = 'Balance Sheet';
        $data['expense'] = $this->Common_model->getAccountListByRoodId(4);
        $data['title'] = 'Balance Sheet';
        $data['mainContent'] = $this->load->view('distributor/finance/report/balanceSheet', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function balanceSheet_export_excel() {
        $file = 'Balance Sheet_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $to_date = $data['todate'] = $_SESSION['to_date'];

        $data['assetList'] = $this->Common_model->getAccountListByRoodId(1);
        $data['liabilityList'] = $this->Common_model->getAccountListByRoodId(2);
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);

        $this->load->view('excel_report/balanceSheet_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function incomeStetement() {
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['pageTitle'] = 'Income Statement';
        $data['expense'] = $this->Common_model->getAccountListByRoodId(4);
        $data['title'] = 'Income Statement';
        $data['mainContent'] = $this->load->view('distributor/finance/report/incomeStatement', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function incomeStatement_export_excel() {
        $file = 'Income Statement_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $account = $data['account'] = $_SESSION['account'];
        $start_date = $data['fromdate'] = $_SESSION['start_date'];
        $end_date = $data['todate'] = $_SESSION['end_date'];
        //$dist_id = $data['dist_id'] = $_SESSION['dist_id'];

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);

        $this->load->view('excel_report/incomeStatement_export_excel', $data);
        unset($_SESSION['full_array']);
    }

    public function getPayUserList() {
        $payid = $this->input->post('payid');
        $condition = array(
            'dist_id' => $this->dist_id,
            'status' => 1,
        );
        $data['payType'] = $payid;
        if ($payid == 1) {
            return $this->load->view('distributor/ajax/payList', $data);
        } elseif ($payid == 2) {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('customer', $condition);
            return $this->load->view('distributor/ajax/payList', $data);
        } else {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('supplier', $condition);
            return $this->load->view('distributor/ajax/payList', $data);
        }
    }

    public function getPayUserList2() {
        $payid = $this->input->post('payid');
        $condition = array(
            'dist_id' => $this->dist_id,
            'status' => 1,
        );
        $data['payType'] = $payid;
        if ($payid == 1) {
            return $this->load->view('distributor/ajax/payList2', $data);
        } elseif ($payid == 2) {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('customer', $condition);
            return $this->load->view('distributor/ajax/payList2', $data);
        } else {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('supplier', $condition);
            return $this->load->view('distributor/ajax/payList2', $data);
        }
    }

    public function getPayUserListPosting() {
        $payid = $this->input->post('payid');
        $payUserId = $this->input->post('payUserId');
        $condition = array(
            'dist_id' => $this->dist_id,
            'status' => 1,
        );
        $data['payType'] = $payid;
        $data['userId'] = $payUserId;
        if ($payid == 1) {
            return $this->load->view('distributor/ajax/disable', $data);
        } elseif ($payid == 2) {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('customer', $condition);
            return $this->load->view('distributor/ajax/disable', $data);
        } else {
            $data['payList'] = $this->Common_model->get_data_list_by_many_columns('supplier', $condition);
            return $this->load->view('distributor/ajax/disable', $data);
        }
    }

    public function paymentVoucher() {

        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 2,
        );
        $data['paymentVoucher'] = $this->Common_model->get_data_list_by_many_columns('generals', $condition, 'generals_id', 'DESC');
        $data['title'] = 'Payment Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/payment/paymentVoucher', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function paymentVoucherView($voucherID) {
        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 2,
        );
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['paymentVoucher'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $voucherID);
        $data['paymentJournal'] = $this->Common_model->get_data_list_by_single_column('generalledger', 'generals_id', $voucherID);
        if ($data['paymentVoucher']->customer_id):
            $data['customerInfo'] = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $data['paymentVoucher']->customer_id);
        elseif ($data['paymentVoucher']->supplier_id):
            $data['supplierInfo'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $data['paymentVoucher']->supplier_id);
        else:

        endif;
        $data['title'] = 'Payment Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/payment/paymentVoucherView', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function paymentVoucherAdd($postingId = null) {

        if (isPostBack()) {




            //set some validation for input fields
            $this->form_validation->set_rules('date', 'Payment Date', 'required');
            $this->form_validation->set_rules('voucherid', 'Voucher Id', 'required');
            $this->form_validation->set_rules('payType', 'Payment Type', 'required');
            $this->form_validation->set_rules('accountCr', 'Payment Account', 'required');
            $this->form_validation->set_rules('accountDr[]', 'Account Debit', 'required');
            $this->form_validation->set_rules('amountDr[]', 'Amount Debit', 'required');
            if ($this->form_validation->run() == FALSE) {
                exception("Required field can't be empty.");
                redirect(site_url('paymentVoucherAdd'));
            } else {


                $this->db->trans_start();
                $data['form_id'] = 2;
                $data['dist_id'] = $this->dist_id;
                $data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $data['voucher_no'] = $this->input->post('voucherid');
                $data['payType'] = $this->input->post('payType');
                $data['narration'] = $this->input->post('narration');
                $cust = $this->input->post('customer_id');
                $supid = $this->input->post('supplier_id');
                if (!empty($cust)):
                    $data['customer_id'] = $cust;
                endif;
                if (!empty($supid)):
                    $data['supplier_id'] = $this->input->post('supplier_id');
                endif;
                $miscellaneous = $this->input->post('miscellaneous');
                if (!empty($miscellaneous)):
                    $data['miscellaneous'] = $this->input->post('miscellaneous');
                endif;
                $data['debit'] = array_sum($this->input->post('amountDr'));
                $data['updated_by'] = $this->admin_id;
                $general_id = $this->Common_model->insert_data('generals', $data);

                if (!empty($cust)):
                    $custLedger = array(
                        'ledger_type' => 1,
                        'paymentType' => 'Payment Voucher',
                        'history_id' => $general_id,
                        'trans_type' => $this->input->post('voucherid'),
                        'client_vendor_id' => $this->input->post('customer_id'),
                        'amount' => array_sum($this->input->post('amountDr')),
                        'cr' => array_sum($this->input->post('amountDr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $custLedger);
                endif;
                if (!empty($supid)):

                    $supLedger = array(
                        'ledger_type' => 2,
                        'history_id' => $general_id,
                        'paymentType' => 'Payment Voucher',
                        'trans_type' => $this->input->post('voucherid'),
                        'client_vendor_id' => $this->input->post('supplier_id'),
                        'amount' => array_sum($this->input->post('amountDr')),
                        'cr' => array_sum($this->input->post('amountDr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $supLedger);
                endif;

                $acountCr = $this->input->post('accountCr');
                $accountDr = $this->input->post('accountDr');
                /* Pay account credit */
                $dr['generals_id'] = $general_id;
                $dr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $dr['account'] = $acountCr;
                $dr['credit'] = array_sum($this->input->post('amountDr'));
                $dr['form_id'] = 2;
                $dr['dist_id'] = $this->dist_id;
                $dr['updated_by'] = $this->admin_id;
                $this->Common_model->insert_data('generalledger', $dr);

                $allCr = array();
                foreach ($accountDr as $key => $value) {
                    unset($cr);
                    $cr['generals_id'] = $general_id;
                    $cr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                    $cr['account'] = $this->input->post('accountDr')[$key];
                    $cr['debit'] = $this->input->post('amountDr')[$key];
                    $cr['memo'] = $this->input->post('memoDr')[$key];
                    $cr['form_id'] = 2;
                    $cr['dist_id'] = $this->dist_id;
                    $cr['updated_by'] = $this->admin_id;
                    $allCr[] = $cr;
                }
                $this->db->insert_batch('generalledger', $allCr);
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    notification("Your data can't be inserted");
                    if (!empty($postingId)) {
                        redirect(site_url('paymentVoucherPosting/' . $postingId));
                    } else {
                        redirect(site_url('paymentVoucherAdd'));
                    }
                } else {
                    message("Your data successfully inserted into database.");
                    if (!empty($postingId)) {

                        $dataUpdate['ConfirmStatus'] = 1;
                        $this->Common_model->update_data('purchase_demo', $dataUpdate, 'purchase_demo_id', $postingId);
                        redirect(site_url('financeImport'));
                    } else {
                        redirect(site_url('paymentVoucher'));
                    }
                }
            }


            /* Pay account Credit */
        }
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        //echo $this->db->last_query();die;
        $voucherCondition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 2,
        );
        $totalPurchases = $this->Common_model->get_data_list_by_many_columns('generals', $voucherCondition);
        $data['voucherID'] = "PV" . date('y') . date('m') . str_pad(count($totalPurchases) + 1, 4, "0", STR_PAD_LEFT);
        $data['title'] = 'Add Payment Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/payment/paymentVoucherAdd', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function checkBalancePayment() {
        $account = $this->input->post('account');
        $result2 = $this->Finane_Model->accountBalance($account);
        // $result = '<label style="color:red!important" class="control-label col-sm-4 text-right">Balance.</label>';
        $result .= '<div class="col-sm-12"> ';
        $result .= '<input type="text" class="form-control" id="closeAmount" value="' . $result2 . '" readonly="readonly">';
        $result .= '</div>';
        echo $result;
    }

    public function checkBalance() {
        $account = $this->input->post('account');
        $result2 = $this->Finane_Model->accountBalance($account);
        $result = '<label style="color:red!important" class="control-label col-md-4 text-right">Balance TK.</label>';
        $result .= '<div class="col-md-8"> ';
        $result .= '<input type="text" class="form-control" id="closeAmount" value="' . $result2 . '" readonly="readonly">';
        $result .= '</div>';
        echo $result;
    }

    public function checkBalanceForModal() {
        $account = $this->input->post('account');
        $result2 = $this->Finane_Model->accountBalance($account);
        $result = '<label style="color:red!important" class="control-label col-md-3 text-right">Balance TK.</label>';
        $result .= '<div class="col-md-8"> ';
        $result .= '<input type="text" class="form-control" id="closeAmount" value="' . $result2 . '" readonly="readonly">';
        $result .= '</div>';
        echo $result;
    }

    public function checkBalanceForPayment() {
        $account = $this->input->post('account');
        $result2 = $this->Finane_Model->accountBalance($account);
        $result = '<label style="color:red!important" class="control-label col-md-3 text-right">Balance TK.</label>';
        $result .= '<div class="col-md-6"> ';
        $result .= '<input type="text" class="form-control" id="closeAmount" value="' . $result2 . '" readonly="readonly">';
        $result .= '</div>';
        echo $result;
    }

    public function checkOnlyBalanceForPayment() {
        $account = $this->input->post('account');
        $result2 = $this->Finane_Model->accountBalance($account);
//        $result = '<label style="color:red!important" class="control-label col-md-3 text-right">Balance TK.</label>';
//        $result .= '<div class="col-md-6"> ';
//        $result .= '<input type="text" class="form-control" id="closeAmount" value="' . $result2 . '" readonly="readonly">';
//        $result .= '</div>';
        echo $result2;
    }

    public function receiveVoucher() {

        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 3,
        );
        $data['receiveVoucher'] = $this->Common_model->get_data_list_by_many_columns('generals', $condition, 'generals_id', 'DESC');
        $data['title'] = 'Receive Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/receive/receiveVoucher', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function receiveVoucherView($voucherID) {
        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 3,
        );
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['receiveVoucher'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $voucherID);
        $data['receiveJournal'] = $this->Common_model->get_data_list_by_single_column('generalledger', 'generals_id', $voucherID);
        if ($data['receiveVoucher']->customer_id):
            $data['customerInfo'] = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $data['receiveVoucher']->customer_id);
        elseif ($data['receiveVoucher']->supplier_id):
            $data['supplierInfo'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $data['receiveVoucher']->supplier_id);
        else:

        endif;
        $data['title'] = 'Receive Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/receive/receiveVoucherView', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function receiveVoucherAdd($postingId = null) {

        if (isPostBack()) {

            //validation rules set here.
            $this->form_validation->set_rules('date', 'Payment Date', 'required');
            $this->form_validation->set_rules('voucherid', 'Voucher Id', 'required');
            $this->form_validation->set_rules('payType', 'Payment Type', 'required');
            $this->form_validation->set_rules('accountDr', 'Payment Account', 'required');
            $this->form_validation->set_rules('accountCr[]', 'Account Debit', 'required');
            $this->form_validation->set_rules('amountCr[]', 'Amount Debit', 'required');
            if ($this->form_validation->run() == FALSE) {
                exception("Required field can't be empty.");
                redirect(site_url('receiveVoucherAdd'));
            } else {
                $this->db->trans_start();
                $data['form_id'] = 3;
                $data['dist_id'] = $this->dist_id;
                $data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $data['voucher_no'] = $this->input->post('voucherid');
                $data['payType'] = $this->input->post('payType');
                $data['narration'] = $this->input->post('narration');
                $cust = $this->input->post('customer_id');
                if (!empty($cust)):
                    $data['customer_id'] = $cust;
                endif;
                $miscellaneous = $this->input->post('miscellaneous');
                if (!empty($miscellaneous)):
                    $data['miscellaneous'] = $this->input->post('miscellaneous');
                endif;
                $supid = $this->input->post('supplier_id');
                if (!empty($supid)):
                    $data['supplier_id'] = $supid;
                endif;
                $data['debit'] = array_sum($this->input->post('amountCr'));
                $data['updated_by'] = $this->admin_id;
                $general_id = $this->Common_model->insert_data('generals', $data);

                if (!empty($supid)):
                    $supLedger = array(
                        'ledger_type' => 2,
                        'history_id' => $general_id,
                        'paymentType' => 'Receive Voucher',
                        'trans_type' => $this->input->post('voucherid'),
                        'client_vendor_id' => $supid,
                        'amount' => array_sum($this->input->post('amountCr')),
                        'dr' => array_sum($this->input->post('amountCr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    $this->db->insert('client_vendor_ledger', $supLedger);
                endif;

                if (!empty($cust)):
                    $custLedger = array(
                        'ledger_type' => 1,
                        'history_id' => $general_id,
                        'paymentType' => 'Receive Voucher',
                        'trans_type' => $this->input->post('voucherid'),
                        'client_vendor_id' => $this->input->post('customer_id'),
                        'amount' => array_sum($this->input->post('amountCr')),
                        'dr' => array_sum($this->input->post('amountCr')),
                        'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                        'dist_id' => $this->dist_id,
                    );
                    // dumpVar($_POST);
                    $this->db->insert('client_vendor_ledger', $custLedger);

                endif;
                $acountCr = $this->input->post('accountCr');
                $accountDr = $this->input->post('accountDr');
                /* Pay account credit */
                $dr['generals_id'] = $general_id;
                $dr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $dr['account'] = $accountDr;
                $dr['debit'] = array_sum($this->input->post('amountCr'));
                $dr['form_id'] = 3;
                $dr['dist_id'] = $this->dist_id;
                $dr['updated_by'] = $this->admin_id;
                $this->Common_model->insert_data('generalledger', $dr);

                $alldr = array();
                foreach ($acountCr as $key => $value) {
                    unset($cr);
                    $cr['generals_id'] = $general_id;
                    $cr['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                    $cr['account'] = $this->input->post('accountCr')[$key];
                    $cr['credit'] = $this->input->post('amountCr')[$key];
                    $cr['memo'] = $this->input->post('memoCr')[$key];
                    $cr['form_id'] = 3;
                    $cr['dist_id'] = $this->dist_id;
                    $cr['updated_by'] = $this->admin_id;
                    $allCr[] = $cr;
                }
                $this->db->insert_batch('generalledger', $allCr);
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    notification("Your data can't be inserted");

                    if (!empty($postingId)) {
                        redirect(site_url('receiveVoucherPosting/' . $postingId));
                    } else {
                        redirect(site_url('receiveVoucherAdd'));
                    }
                } else {
                    message("Your data successfully inserted into database.");
                    if (!empty($postingId)) {
                        $updateData['ConfirmStatus'] = 1;
                        $this->Common_model->update_data('purchase_demo', $updateData, 'purchase_demo_id', $postingId);
                        redirect(site_url('financeImport'));
                    } else {
                        redirect(site_url('receiveVoucherView/' . $general_id));
                    }
                }
                /* Pay account Credit */
            }
        }
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $voucherCondition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 3,
        );
        $totalPurchases = $this->Common_model->get_data_list_by_many_columns('generals', $voucherCondition);
        $data['voucherID'] = "RV" . date("y") . date("m") . str_pad(count($totalPurchases) + 1, 4, "0", STR_PAD_LEFT);

        $data['title'] = 'Add Receive Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/receive/receiveVoucherAdd', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function journalVoucher() {

        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 1,
        );
        $data['journalVoucher'] = $this->Common_model->get_data_list_by_many_columns('generals', $condition, 'generals_id', 'DESC');
        $data['title'] = 'Journal Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/journal/journalVoucher', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function journalVoucherView($voucherID) {
        $condition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 1,
        );
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['journalVoucher'] = $this->Common_model->get_single_data_by_single_column('generals', 'generals_id', $voucherID);
        $data['journalJournal'] = $this->Common_model->get_data_list_by_single_column('generalledger', 'generals_id', $voucherID);
        if ($data['journalVoucher']->customer_id):
            $data['customerInfo'] = $this->Common_model->get_single_data_by_single_column('customer', 'customer_id', $data['journalVoucher']->customer_id);
        elseif ($data['journalVoucher']->supplier_id):
            $data['supplierInfo'] = $this->Common_model->get_single_data_by_single_column('supplier', 'sup_id', $data['journalVoucher']->supplier_id);
        else:

        endif;
        $data['title'] = 'Receive Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/journal/journalVoucherView', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function journalVoucherAdd() {

        if (isPostBack()) {

            $this->form_validation->set_rules('date', 'Payment Date', 'required');
            $this->form_validation->set_rules('voucherid', 'Voucher Id', 'required');
            $this->form_validation->set_rules('account[]', 'Payment Type', 'required');
            // $this->form_validation->set_rules('amountDr[]', 'Account Debit', 'required');
            //$this->form_validation->set_rules('amountCr[]', 'Amount Credit', 'required');
            if ($this->form_validation->run() == FALSE) {
                exception("Required field can't be empty.");
                redirect(site_url('journalVoucherAdd'));
            } else {
                $this->db->trans_start();
                $data['form_id'] = 1;
                $data['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                $data['voucher_no'] = $this->input->post('voucherid');
                $data['narration'] = $this->input->post('narration');
                $data['debit'] = array_sum($this->input->post('amountDr'));
                $data['dist_id'] = $this->dist_id;
                $data['updated_by'] = $this->admin_id;
                $general_id = $this->Common_model->insert_data('generals', $data);
                $account = $this->input->post('account');
                /* Pay account credit */
                $alldr = array();
                foreach ($account as $key => $value) {
                    unset($jv);
                    $jv['generals_id'] = $general_id;
                    $jv['date'] = date('Y-m-d', strtotime($this->input->post('date')));
                    $jv['account'] = $value;
                    $jv['debit'] = $this->input->post('amountDr')[$key];
                    $jv['credit'] = $this->input->post('amountCr')[$key];
                    $jv['memo'] = $this->input->post('memo')[$key];
                    $jv['form_id'] = 1;
                    $jv['dist_id'] = $this->dist_id;
                    $jv['updated_by'] = $this->admin_id;
                    $alldr[] = $jv;
                }
                $this->db->insert_batch('generalledger', $alldr);
                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    notification("Your data can't be inserted.");
                    redirect(site_url('journalVoucher'));
                } else {
                    message("Your journal inserted into database.");
                    redirect(site_url('journalVoucherView/' . $general_id));
                }
                /* Pay account Credit */
            }
        }
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $voucherCondition = array(
            'dist_id' => $this->dist_id,
            'form_id' => 1,
        );
        $totalPurchases = $this->Common_model->get_data_list_by_many_columns('generals', $voucherCondition);
        $data['voucherID'] = "JV" . date("y") . date("m") . str_pad(count($totalPurchases) + 1, 4, "0", STR_PAD_LEFT);
        $data['title'] = 'Add Journal Voucher';
        $data['mainContent'] = $this->load->view('distributor/finance/journal/journalVoucherAdd', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function checkDuplicateHead() {
        if ($this->input->is_ajax_request()) {
            $headTitle = $this->input->post('headTitle');
            $rootAccount = $this->input->post('rootAccount');
            $parentAccount = $this->input->post('parentAccount');
            $childAccount = $this->input->post('childAccount');
            $acc_head = $this->Finane_Model->checkDuplicateHead($headTitle, $rootAccount, $parentAccount, $childAccount, $this->dist_id);
            //echo $this->db->last_query();die;
            if (!empty($acc_head)) {
                echo "1";
            } else {
                echo "2";
            }
        }
    }

    public function getChartList() {
        if ($this->input->is_ajax_request()) {
            $headTitle = $this->input->post('headTitle');
            $rootAccount = $this->input->post('rootAccount');
            $parentAccount = $this->input->post('parentAccount');
            $childAccount = $this->input->post('childAccount');
            $chartList = $this->Finane_Model->get_chart_list($headTitle, $rootAccount, $parentAccount, $childAccount, $this->dist_id);
            $disabledHead = array(72, 58, 50, 54, 60, 49, 59, 62);
            $add = '';
            if (!empty($chartList)):
                $add.="<option selected disabled value=''>Search Account Head</option>";
                foreach ($chartList as $key => $value):

                    $disabled = 0;
                    if (in_array($value->chart_id, $disabledHead)) {
                        $disabled = 'disabled';
                    }
                    $add.="<option $disabled  value='" . $value->chart_id . "'>$value->title</option>";
                endforeach;
                echo $add;
                DIE;
            else:
                echo "<option value=''>No Head Available</option>";
                DIE;
            endif;
        }
    }

    public function getHeadCode() {
        if ($this->input->is_ajax_request()) {

            $child = $this->input->post('childID');
            $condition = array(
                'parentId' => $child,
                'dist_id' => $this->dist_id,
            );
            $this->db->select("*");
            $this->db->from("chartofaccount");
            $this->db->where("parentId", $child);
            $this->db->group_start();
            $this->db->where('dist_id', $this->dist_id);
            $this->db->or_where('common', 1);
            $this->db->group_end();
            $totalAccount = $this->db->get()->result();
            // $totalAccount = $this->Common_model->get_data_list_by_many_columns('generaldata', $condition);
            $oldAccountCode = $this->Common_model->get_single_data_by_single_column('chartofaccount', 'chart_id', $child);
            $array = array();
            if (!empty($totalAccount)):
                $totalAccount = count($totalAccount);
                $newCode = $oldAccountCode->accountCode . ' - ' . str_pad($totalAccount + 1, 4, "0", STR_PAD_LEFT);
                echo $newCode;
            else:
                $totalAdded = 0;
                echo $newCode = $oldAccountCode->accountCode . ' - ' . str_pad($totalAdded + 1, 4, "0", STR_PAD_LEFT);
            endif;
        }
    }

    public function getChildCode() {
        if ($this->input->is_ajax_request()) {
            $rootID = $this->input->post('rootID');
            $parent = $this->input->post('parentId');
            $child = $this->input->post('child');
            $condition = array(
                'parentId' => $parent,
                'dist_id' => $this->dist_id,
            );
            $this->db->select("*");
            $this->db->from("chartofaccount");
            $this->db->where("parentId", $parent);
            $this->db->group_start();
            $this->db->where('dist_id', $this->dist_id);
            $this->db->or_where('common', 1);
            $this->db->group_end();
            $totalAccount = $this->db->get()->result();
            //$totalAccount = $this->Common_model->get_data_list_by_many_columns('generaldata', $condition);
            $lastHeadCode = $this->Common_model->get_single_data_by_single_column('chartofaccount', 'chart_id', $parent);
            //$oldAccountCode = $this->Common_model->get_single_data_by_many_columns('chartofaccount', $condition, 'chart_id', 'DESC');
            $array = array();
            if (!empty($totalAccount)):
                $totalAccount = count($totalAccount);
                $newCode = $lastHeadCode->accountCode . ' - ' . str_pad($totalAccount + 1, 3, "0", STR_PAD_LEFT);
                echo $newCode;
            else:
                $totalAdded = 0;
                echo $newCode = $lastHeadCode->accountCode . ' - ' . str_pad($totalAdded + 1, 3, "0", STR_PAD_LEFT);
            endif;
        }
    }

    public function getParentCode() {
        if ($this->input->is_ajax_request()) {
            $rootID = $this->input->post('rootID');
            $parent = $this->input->post('parent');
            $child = $this->input->post('child');
            $condition = array(
                'parentId' => $rootID,
                'dist_id' => $this->dist_id,
            );
            $totalAccount = $this->Common_model->get_data_list_by_many_columns('chartofaccount', $condition);
            $array = array();

            if (!empty($totalAccount)):
                $totalAccount = count($totalAccount);
                $newCode = $rootID . ' - ' . str_pad($totalAccount + 1, 2, "0", STR_PAD_LEFT);
                echo $newCode;
            else:
                $totalAdded = 0;
                echo $newCode = $rootID . ' - ' . str_pad($totalAdded + 1, 2, "0", STR_PAD_LEFT);
            endif;
        }
    }

    public function chartOfAccount() {


        if (isPostBack()) {
            $rootAccount = $this->input->post('rootAccount');
            $parentAccount = $this->input->post('parentAccount');
            $childAccount = $this->input->post('childAccount');
            $accountHead = $this->input->post('accountHead');
            $accountCode = $this->input->post('accountCode');
            if (empty($rootAccount) || empty($accountHead) || empty($accountCode)) :
                exception("Required Field Can't be Empty!!");
                redirect(site_url('chartOfAccount'), 'refresh');
            endif;
            unset($data);
            if (!empty($rootAccount) && empty($parentAccount) && empty($childAccount)):
                //Parent Account Inserted.
                $data['rootId'] = $rootAccount;
                $data['parentId'] = $rootAccount;
                $data['accountCode'] = $accountCode;
                $data['title'] = $accountHead;
                $data['status'] = 1;
                $data['dist_id'] = $this->dist_id;
                $inserted_id = $this->Common_model->insert_data('chartofaccount', $data);
                if (!empty($inserted_id)) {
                    $this->Common_model->makeGeneralLedger();
                }

                if (!empty($inserted_id)) :
                    unset($_POST);
                    message("Your chart of head successfully created.");
                    redirect(site_url('chartOfAccount'));

                endif;
            elseif (!empty($parentAccount) && !empty($rootAccount) && empty($childAccount)) :
                //Child Account Inserted.
                $data['rootId'] = $rootAccount;
                $data['parentId'] = $parentAccount;
                $data['accountCode'] = $accountCode;
                $data['title'] = $accountHead;
                $data['status'] = 1;
                $data['dist_id'] = $this->dist_id;
                $inserted_id = $this->Common_model->insert_data('chartofaccount', $data);
                if (!empty($inserted_id)) {
                    $this->Common_model->makeGeneralLedger();
                }

                if (!empty($inserted_id)) :
                    unset($_POST);
                    message("Your chart of head successfully created.");
                    redirect(site_url('chartOfAccount'));
                endif;
            else:
                // Account Head Inserted.
                $data['rootId'] = $rootAccount;
                $data['parentId'] = $childAccount;
                $data['accountCode'] = $accountCode;
                $data['title'] = $accountHead;
                $data['status'] = 1;
                $data['dist_id'] = $this->dist_id;
                $inserted_id = $this->Common_model->insert_data('chartofaccount', $data);
                if (!empty($inserted_id)) {
                    $this->Common_model->makeGeneralLedger();
                }

                if (!empty($inserted_id)) :
                    unset($_POST);
                    message("Your chart of head successfully created.");
                    redirect(site_url('chartOfAccount'));
                endif;
            endif;
        }
        $data['rootAccount'] = $this->Common_model->get_data_list_by_single_column('chartofaccount', 'parentId', '0');
        $data['title'] = 'Chart of Account';
        $data['mainContent'] = $this->load->view('distributor/finance/setup/chartOfAccount', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function editChartOfAccount($id) {

        if (isPostBack()) {
            $this->db->trans_start();
            $condtion = array(
                'dist_id' => $this->dist_id,
                'chartId' => $id,
            );

            $generalId = $this->Common_model->get_single_data_by_many_columns('generaldata', $condtion);


            $data1['title'] = $this->input->post('accountHead');
            $this->Common_model->update_data('generaldata', $data1, 'generalId', $generalId->generalId);

            $data['title'] = $this->input->post('accountHead');
            $this->Common_model->update_data('chartofaccount', $data, 'chart_id', $id);

            $this->db->trans_complete();
            if ($this->db->trans_status() === FALSE) {
                notification("Your data can't be updated.Somthing is wrong!!");
                redirect(site_url('editChartOfAccount/' . $id));
            } else {
                message("Your chart of account successfully updated into database   .");
                redirect(site_url('listChartOfAccount'));
            }
        }

        $data['title'] = 'Edit Chart of Account';
        $condition = array(
            'dist_id' => $this->dist_id,
            'rootId !=' => 0,
        );
        $data['editChartAccount'] = $rootAccount = $this->Common_model->get_single_data_by_single_column('chartofaccount', 'chart_id', $id);
        $data['mainContent'] = $this->load->view('distributor/finance/setup/editChartAccount', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function listChartOfAccount() {

        $data['title'] = 'Chart of Account';
        $data['chartList'] = $this->Finane_Model->getChartList();
        $data['mainContent'] = $this->load->view('distributor/finance/setup/listChartOfAccount', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function viewChartOfAccount() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'status' => 1,
            'rootId !=' => 0,
        );
        $data['title'] = 'View Chart of Account';
        $data['chartList'] = $this->Common_model->get_data_list_by_many_columns('chartofaccount', $condition);
        $data['mainContent'] = $this->load->view('distributor/finance/setup/ViewChartOfAccount', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function changeChartStatus() {
        $chartid = $this->input->post('chartid');
        $data['status'] = $this->input->post('chartStatus');
        $update_status = $this->Common_model->update_data('chartofaccount', $data, 'chart_id', $chartid);
        $this->Common_model->makeGeneralLedger();
        message("Chart of account status successfully change");
        if (!empty($update_status)):
            echo 1;
        else:
            echo 2;
        endif;
    }

    function getProductList() {
        $cat_id = $this->input->post('cat_id');
        $productList = $this->Common_model->get_data_list_by_single_column('product', 'category_id', $cat_id);
        $add = '';
        if (!empty($productList)):
            $add.="<option value=''></option>";
            foreach ($productList as $key => $value):
                $add.="<option productName='" . $value->productName . "'   value='" . $value->product_id . "'>$value->productName</option>";
            endforeach;
            echo $add;
            DIE;
        else:
            echo "<option value='' selected disabled>No Product Available</option>";
            DIE;
        endif;
    }

    function getProductPrice() {
        $product_id = $this->input->post('product_id');
        $productDetails = $this->Common_model->get_single_data_by_single_column('product', 'product_id', $product_id);
        if (!empty($productDetails)):
            echo $productDetails->purchases_price;
        endif;
    }

    function getProductStock() {

        $product_id = $this->input->post('product_id');
        $productStock = $this->Sales_Model->getProductStock($product_id);
        if (!empty($productStock) && $productStock > 0):
            echo $productStock;
        endif;
    }

    function getProductPriceForSale() {
        $product_id = $this->input->post('product_id');
        $productDetails = $this->Common_model->get_single_data_by_single_column('product', 'product_id', $product_id);
        if (!empty($productDetails->salesPrice)):
            echo $productDetails->salesPrice;
        else:
            echo '';
        endif;
    }

    function openingBalance() {

        if (isPostBack()) {


            $this->Common_model->delete_data('retainEarning', 'dist_id', $this->dist_id);
            $retain['dr'] = $this->input->post('retainEarningDR');
            $retain['cr'] = $this->input->post('retainEarningCR');
            $retain['dist_id'] = $this->dist_id;
            $retain['date'] = date('Y-m-d');
            $this->Common_model->insert_data('retainEarning', $retain);

            $this->Common_model->delete_data('opening_balance', 'dist_id', $this->dist_id);
            //$this->db->empty_table('opening_balance');
            $accountid = $this->input->post('accountid');
            $headDebit = $this->input->post('headDebit');
            $headCredit = $this->input->post('headCredit');
            $insertData = array();
            foreach ($accountid as $key => $value):
                $data['account'] = $value;
                $data['debit'] = $headDebit[$key];
                $data['credit'] = $headCredit[$key];
                $data['date'] = date('Y-m-d');
                $data['dist_id'] = $this->dist_id;
                $data['updated_by'] = $this->admin_id;
                $insertData[] = $data;
            endforeach;
            $this->db->insert_batch('opening_balance', $insertData);
            message("Your opening balance successfully inserted into database.");
            redirect(site_url('openingBalance'));
        }

        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $data['title'] = 'Opening Balance';
        //$data['chartList'] = $this->Common_model->get_data_list_by_many_columns('chartofaccount', $condition);
        $data['mainContent'] = $this->load->view('distributor/finance/setup/opengingBalance', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function generalLedger($account = null) {

        if (!empty($account)) {
            $data['dist_id'] = $this->dist_id;
            $data['account'] = $account;
        } else {
            $data['fromdate'] = 0;
            $data['todate'] = 0;
            $data['account'] = 0;
        }

        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $list = $this->Finane_Model->getExpenseHead();
        $data['title'] = 'General Ledger';
        $data['pageTitle'] = 'General Ledger';
        $data['mainContent'] = $this->load->view('distributor/finance/report/generalLedger', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function generalLedger_export_excel() {
        $file = 'General Ledger_' . date('d.m.Y') . '.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        header('Cache-Control: max-age=0');

        $account = $data['account'] = $_SESSION['account'];
        $start_date = $data['fromdate'] = $_SESSION['start_date'];
        $end_date = $data['todate'] = $_SESSION['end_date'];
        //$dist_id = $data['dist_id'] = $_SESSION['dist_id'];


        if (!empty($account)) {
            $data['dist_id'] = $this->dist_id;
            $data['account'] = $account;
        } else {
            $data['fromdate'] = 0;
            $data['todate'] = 0;
            $data['account'] = 0;
        }
        $data['companyInfo'] = $this->Common_model->get_single_data_by_single_column('tbl_distributor', 'dist_id', $this->dist_id);
        $data['accountHeadList'] = $this->Common_model->getAccountHead();
        $list = $this->Finane_Model->getExpenseHead();

        $this->load->view('excel_report/generalLedger_export_excel', $data);
        unset($_SESSION['full_array']);
    }

}
